Actual matched coding-agent comparator, frozen 2026-10-16.

The agent executed the ORIGINAL prepare_task on each fixed task in protocol role
order, with SHA256(local FREEZE bytes) as binding and exact PROTOCOL packages.
All three refused native suite admission. Therefore no baseline, production
candidate, build, native check, admission repetition, or execution was attempted.
These are UNKNOWN contracts, not unsolved valid tasks and not zero-test success.
Native comparative performance and G4 advantage remain UNKNOWN.

Original receipts and transport logs:
  task-0/admission.json; task-0/AGENT_DONE.json
  task-1/admission.json; task-1/AGENT_DONE.json
  task-2/admission.json; task-2/AGENT_DONE.json
Each source is exactly a shallow predecessor fetch plus its author-test overlay.
No upstream repaired production/head objects or external outcomes were read.

Runner commands actually executed:
  python3.12 comparator.py init
  python3.12 comparator.py prepare --task 0
  [record exact authority refusal in task-0/AGENT_DONE.json]
  python3.12 comparator.py prepare --task 1
  [record exact authority refusal in task-1/AGENT_DONE.json]
  python3.12 comparator.py prepare --task 2
  [record exact authority refusal in task-2/AGENT_DONE.json]
  python3.12 comparator.py summary

To transport a new replay without overwriting these artifacts, use
  python3.12 comparator.py init --run-root ABSOLUTE_NEW_CHILD_DIRECTORY
  python3.12 comparator.py prepare --task 0 --run-root SAME_DIRECTORY
The runner refuses future transport until previous AGENT_DONE.json exists.
For a PREPARED contract only, a baseline can be executed by
  python3.12 comparator.py verify --task N --category baseline
A production replacement JSON can be executed with
  python3.12 comparator.py verify --task N --category search --candidate FILE
Those commands call ORIGINAL verify with exact native_suite_authority. Search
clocks and invocation caps are retained. Optional --wheel points to an ORIGINAL
immutable build-receipt.json; build action uses the frozen generic recipe.
Successful search requires separate --category admission-1, admission-2, execute
checks (and optional restart), all preserved and charged. These commands were
not reached in this run because admission refused all three contracts.

Setup phase costs are original helper measurements. Comparator wall includes
interactive inspection, orchestration and artifact work after RUN initialization.
Conservative full agent wall starts from the parent-supplied pre-dispatch freeze
mtime (2026-10-16T02:37:25.928695Z), which overcharges intervening orchestration.
Token, dollar and engineering cost are UNKNOWN. No full-cost advantage is claimed.
