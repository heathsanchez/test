#!/usr/bin/env python3.12
"""Actual agent-arm frozen transport and native-verifier driver.

Only original immutable authority executes target code. Reasoning-produced
candidates are independent archived JSON files supplied through --candidate.
Run commands with Python 3.12.14; every invocation appends to events.jsonl.
"""
import argparse, datetime, hashlib, json, pathlib, subprocess, sys, time, traceback
SCRIPT_ROOT=pathlib.Path(__file__).resolve().parent
ROOT=SCRIPT_ROOT
REPO=pathlib.Path('/workspace/udm-v54')
FREEZE=pathlib.Path('/workspace/qualification/decisive-local-FREEZE.json')
P=REPO/'research/unified_consequence_runtime/archaeology/decisive-native'
sys.path.insert(0,str(REPO))
sys.dont_write_bytecode=True

def h(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,obj): path.write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
def event(obj):
    with (ROOT/'events.jsonl').open('a') as f: f.write(json.dumps({'utc':now(),'epoch':time.time(),**obj},sort_keys=True)+'\n')
def load(path): return json.loads(path.read_text())
def validate():
    freeze=load(FREEZE)
    if sys.version_info[:3]!=(3,12,14): raise RuntimeError('exact Python 3.12.14 required')
    head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    if head!='a02eb3fb10b7577cc232fc9180b8fe9d3ef2c125': raise RuntimeError('frozen runtime HEAD mismatch')
    for name,digest in freeze['files'].items():
        if h((REPO/name).read_bytes())!=digest: raise RuntimeError('frozen file mismatch: '+name)
    return h(FREEZE.read_bytes()),load(P/'PROTOCOL.json')

def task(index):
    from research.unified_consequence_runtime.decisive_native import task_roles
    rows=task_roles(load(P/'FRESH_TASK_METADATA.json')['selected'])
    return rows[index],ROOT/('task-'+str(index))

def main():
    global ROOT
    a=argparse.ArgumentParser();a.add_argument('action',choices=['init','prepare','verify','build','summary'])
    a.add_argument('--run-root',type=pathlib.Path,help='Fresh/existing run directory inside this comparator directory')
    a.add_argument('--task',type=int,choices=range(3));a.add_argument('--candidate',type=pathlib.Path)
    a.add_argument('--category',choices=['baseline','search','admission-1','admission-2','execute','restart'],default='search')
    a.add_argument('--wheel',type=pathlib.Path)
    args=a.parse_args()
    if args.run_root is not None:
        ROOT=args.run_root.absolute()
        if ROOT.resolve()!=ROOT or not ROOT.is_relative_to(SCRIPT_ROOT): raise RuntimeError('run root must be canonical and within comparator directory')
    ROOT.mkdir(parents=True,exist_ok=True)
    start=time.time(); binding,protocol=validate()
    if args.action=='init':
        if (ROOT/'RUN.json').exists():raise RuntimeError('already initialized')
        save(ROOT/'RUN.json',{'schema':'UDM_ACTUAL_CODING_AGENT_ARM_V1','started_utc':now(),'started_epoch':start,'protocol_binding':binding,'runtime_commit':'a02eb3fb10b7577cc232fc9180b8fe9d3ef2c125','python':sys.version,'python_executable':sys.executable,'python_sha256':h(pathlib.Path(sys.executable).read_bytes()),'protocol_sha256':h((P/'PROTOCOL.json').read_bytes()),'metadata_sha256':h((P/'FRESH_TASK_METADATA.json').read_bytes()),'author_blobs_sha256':h((P/'AUTHOR_TEST_BLOBS.json').read_bytes()),'model_tokens':'UNKNOWN','model_dollars':'UNKNOWN','engineering_cost':'UNKNOWN','pre_entrypoint_protocol_read_wall_seconds':'UNKNOWN','boundaries':{'target_transport':'ORIGINAL prepare_task only','upstream_production_head_read':False,'other_arm_evidence_read':False,'target_execution':'ORIGINAL verify only','candidate_scope':'tracked production Python replacements','test_config_or_verifier_edit':False,'native_seconds':7,'training_search_max_calls':128,'training_search_seconds':600,'future_search_max_calls':8,'future_search_seconds':180}})
        event({'action':'init','seconds':time.time()-start});print('INITIALIZED');return
    if args.action=='summary':
        events=[json.loads(s) for s in (ROOT/'events.jsonl').read_text().splitlines()]
        tasks=[]
        for i in range(3):
            spec,folder=task(i)
            adm=load(folder/'admission.json') if (folder/'admission.json').exists() else None
            runs=[e for e in events if e.get('action')=='verify' and e.get('task')==i]
            costs=[r.get('costs',{}) for r in runs]
            search=[r for r in runs if r.get('category')=='search']
            first=search[0]['epoch']-search[0]['wall_seconds'] if search else None
            last=search[-1]['epoch'] if search else None
            status='NOT_ATTEMPTED' if adm is None else adm['status'] if adm['status']!='PREPARED' else ('PASS_NATIVE' if any(r.get('status')=='PASS_NATIVE' and r.get('category')=='execute' for r in runs) else runs[-1]['status'] if runs else 'PREPARED_UNTESTED')
            tasks.append({'index':i,'repository':spec['repo'],'role':spec['role'],'status':status,'admission_status':adm['status'] if adm else None,'admission_reason':adm.get('reason') if adm else None,'setup_total_wall_seconds':adm.get('total_wall_seconds') if adm else None,'setup_costs':adm.get('costs') if adm else None,'source_boundaries':adm.get('source_boundaries') if adm else None,'contract':adm.get('contract') if adm else None,'native_suite_authority_sha256':h((folder/'native-suite-authority.json').read_bytes()) if (folder/'native-suite-authority.json').exists() else 'UNKNOWN_NOT_ADMITTED','protocol_sha256':h((P/'PROTOCOL.json').read_bytes()),'protocol_binding':binding,'runtime_source_commit':'a02eb3fb10b7577cc232fc9180b8fe9d3ef2c125','admission_helper_sha256':h((REPO/'research/unified_consequence_runtime/decisive_task_admission.py').read_bytes()),'verifier_sha256':h((REPO/'research/unified_consequence_runtime/generic_native_verify.py').read_bytes()),'environment_sha256':(adm.get('contract') or {}).get('environment_sha256','UNKNOWN_NOT_PREPARED'),'environment_identity_created':(folder/'environment.json').exists(),'frozen_author_test_blob_match': all(row['git_blob']==load(P/'AUTHOR_TEST_BLOBS.json')['subjects'][spec['repo']]['test_blobs'][row['path']] for row in (adm or {}).get('source_boundaries',{}).get('author_tests',[])) if adm else None,'closure':load(folder/'AGENT_DONE.json') if (folder/'AGENT_DONE.json').exists() else None,'admission_json_sha256':h((folder/'admission.json').read_bytes()) if adm else None,'actual_native_calls':sum(c.get('native_calls',0) for c in costs),'candidate_native_calls':sum(r.get('costs',{}).get('native_calls',0) for r in search),'candidate_invocations':len(search),'baseline_native_calls':sum(r.get('costs',{}).get('native_calls',0) for r in runs if r['category']=='baseline'),'qualification_execution_native_calls':sum(r.get('costs',{}).get('native_calls',0) for r in runs if r['category'] not in ['baseline','search']),'actual_native_seconds':sum(c.get('native_seconds',0) for c in costs),'verification_wall_seconds':sum(r['wall_seconds'] for r in runs),'candidate_search_wall_seconds':last-first if first is not None else 0,'runs':runs,'builds':[e for e in events if e.get('action')=='build' and e.get('task')==i]})
        run=load(ROOT/'RUN.json');result={**run,'ended_utc':now(),'entrypoint_full_wall_seconds':time.time()-run['started_epoch'],'conservative_full_agent_wall_seconds':time.time()-run['conservative_agent_wall_anchor_epoch'] if 'conservative_agent_wall_anchor_epoch' in run else 'UNKNOWN','tasks':tasks,'all_actual_native_calls':sum(t['actual_native_calls'] for t in tasks),'all_actual_native_seconds':sum(t['actual_native_seconds'] for t in tasks),'setup_total_wall_seconds':sum(t['setup_total_wall_seconds'] or 0 for t in tasks),'maintenance_and_candidate_authoring':'Interactive agent reasoning and file construction; wall included after entrypoint start; token/dollar/engineering measurements UNKNOWN','G4_claim':'UNKNOWN; no measured full-cost advantage claim','all_failed_runs_preserved':True,'native_qualification_status':'UNKNOWN_ALL_ADMISSIONS_REFUSED' if all(t['status']=='UNKNOWN_CONTRACT' for t in tasks) else 'SEE_TASK_STATUSES','comparator_execution_status':'ACTUAL_AGENT_ARM_EXECUTED_ADMISSION; NATIVE_COMPARISON_UNMEASURABLE' if all(t['status']=='UNKNOWN_CONTRACT' for t in tasks) else 'ACTUAL_AGENT_ARM_EXECUTED','target_specific_repairs':0,'verifier_overrides':0,'build_calls':sum(e.get('costs',{}).get('build_calls',0) for e in events if e.get('action')=='build')}
        save(ROOT/'RESULT.json',result);print(json.dumps({k:result[k] for k in ['all_actual_native_calls','all_actual_native_seconds','entrypoint_full_wall_seconds','setup_total_wall_seconds']}));print(json.dumps([{k:t[k] for k in ['repository','role','status','candidate_invocations','actual_native_calls','admission_reason']} for t in tasks]));return
    spec,folder=task(args.task)
    if args.action=='prepare':
        # Preserve prospective sequencing: only transport next after prior final result.
        if args.task and not (ROOT/('task-'+str(args.task-1))/'AGENT_DONE.json').exists(): raise RuntimeError('previous task not closed')
        from research.unified_consequence_runtime.decisive_task_admission import prepare_task
        result=prepare_task(spec,folder,protocol_binding=binding,packages=protocol['packages'])
        event({'action':'prepare','task':args.task,'status':result['status'],'reason':result.get('reason'),'wall_seconds':time.time()-start})
        print(json.dumps({'status':result['status'],'reason':result.get('reason'),'setup_seconds':result['total_wall_seconds']}));return
    adm=load(folder/'admission.json')
    if adm['status']!='PREPARED':raise RuntimeError('admission unsupported; no target execution allowed')
    if args.action=='build':
        from research.unified_consequence_runtime.generic_build_materialization import materialize
        dest=folder/('build-'+str(time.time_ns()))
        result=materialize(adm['contract']['repo_path'],dest,python=adm['contract']['interpreter'],source_commit=adm['contract']['commit'])
        event({'action':'build','task':args.task,'out':str(dest),'costs':result['costs'],'wall_seconds':time.time()-start})
        print(json.dumps({'out':str(dest),'evidence':str(dest/'build-receipt.json'),'costs':result['costs']}));return
    if args.action=='verify':
        from research.unified_consequence_runtime.generic_native_verify import verify,fingerprint
        candidate={'replacements':[]} if args.category=='baseline' else load(args.candidate)
        existing=[json.loads(s) for s in (ROOT/'events.jsonl').read_text().splitlines()]
        search=[r for r in existing if r.get('action')=='verify' and r.get('task')==args.task and r.get('category')=='search']
        if args.category=='search':
            limit=protocol['training_unique_calls'] if args.task==0 else protocol['search_budget']
            if len(search)>=limit:raise RuntimeError('candidate invocation budget exhausted')
            budget=protocol['training_seconds'] if args.task==0 else protocol['per_search_seconds']
            clock=folder/'SEARCH_CLOCK.json'
            if not clock.exists():save(clock,{'started_epoch':start,'started_utc':now(),'seconds':budget,'call_limit':limit})
            if time.time()-load(clock)['started_epoch']>budget:raise RuntimeError('candidate wall budget exhausted')
        out=folder/'runs'/f'{len([r for r in existing if r.get("action")=="verify" and r.get("task")==args.task]):03d}-{args.category}'
        out.mkdir(parents=True,exist_ok=False);save(out/'candidate.json',candidate)
        evidence=load(args.wheel)['generated_wheel_evidence'] if args.wheel else None
        try:
            result=verify(adm['contract'],candidate,out,native_suite_authority=adm['native_suite_authority'],generated_wheel_evidence=evidence)
        except Exception as error:
            save(out/'exception.json',{'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
            result=load(out/'receipt.json') if (out/'receipt.json').exists() else {'status':'UNKNOWN_API_EXCEPTION','costs':{'native_calls':0},'error':str(error)}
        event({'action':'verify','task':args.task,'category':args.category,'candidate_sha256':fingerprint(candidate),'out':str(out),'status':result['status'],'junit':result.get('junit'),'costs':result['costs'],'error':result.get('error'),'wall_seconds':time.time()-start})
        print(json.dumps({'out':str(out),'status':result['status'],'junit':result.get('junit'),'costs':result['costs'],'error':result.get('error')}))

if __name__=='__main__':main()
