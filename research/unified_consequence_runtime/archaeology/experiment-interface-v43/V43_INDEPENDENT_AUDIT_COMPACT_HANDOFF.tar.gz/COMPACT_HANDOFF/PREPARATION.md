# Independent V43 archive audit preparation

The auditor is outside the research repository and executes no archived or source-native code. It does not import qualification producers. It streams ZIP/TAR regular members into a SHA256-keyed cache, inventories symlink targets as data, and refuses hard links and special members. Git access is read-only with `GIT_OPTIONAL_LOCKS=0`; raw root/component indexes are captured before the first read and checked afterward.

The final CI source is `5a449e7d6be3a54d42e2098804904c2e1223ae51`, Actions run `39682460349`; artifact identity and ZIP are still required. No qualification PASS or prospective gate wrapper has been emitted.

## Invocation after the final source and artifact exist

```sh
python -B /workspace/qualification/experiment-interface-v43-ci-independent-audit/audit_v43.py \
  --repo /workspace/udm-v54 \
  --zip /absolute/retained/artifact.zip \
  --source EXACT_FULL_SOURCE_SHA \
  --run EXACT_RUN_ID \
  --artifact EXACT_ARTIFACT_ID \
  --extra-control-count test_controller_setup_preflight_v43.py=6 \
  --out /workspace/qualification/experiment-interface-v43-ci-independent-audit/EXACT_NEW_AUDIT_DIRECTORY
```

The auditor independently queries GitHub run/artifact API metadata, checks exact green workflow/source/branch/event identity and ZIP digest/size, then verifies complete source Git objects/modes and all 2361 baseline files, all 118 frozen pytest controls, 27 inherited controls, 6 reporting diagnostics, native handoff and complete native-context supplement. Both V42 and V43 retained native packets must be present. It independently reconstructs collection/assertion/status, base-versus-augmented Git source and build recipe, wheel-member equality, CAS-native evidence links, Metatron revocation, FLASH fixed-point closure, typed frontier readiness, exact-invocation cuts, live fresh restoration and separate-process native restart.

The compact wrapper is emitted only if every independent check passes. Its schema is `UDM_V43_INDEPENDENT_INTERFACE_ARCHIVE_AUDIT_V1`; the exact native packet scope string is:

> Retained raw collection/assertion/status packets; exact candidate/import bytes additionally closed for the complete native-context supplement. No universal Python refinement claim.

The wrapper's `independent_report_sha256` hashes exact retained `REPORT.json` bytes. `all_native_packets_checked` never comes from the driver's self-reported audit.

## Boundaries

This is bounded native-interface infrastructure qualification. G2–G6 stay UNKNOWN. Complete candidate/import bytes are reconstructed only for the explicitly retained native-context supplement; other contexts preserve raw packets and source-frozen controls. Causal CAS records are bound to audited native receipts and retained actual build verification sidecars. Preflight no-launch checks remain executed frozen control assertions, not signed host action-monitor attestations.

Build receipts are enumerated by distinct actual launch paths, with parent and child scopes kept visible. Native/build counters are measured local instrumentation, not a complete model/tool/engineering/storage lifecycle bill or a comparative G4 result. Same-filesystem cold restart is not cross-environment relocation, and non-bypassable external authority remains UNKNOWN.

Loose archived Git objects can be reconstructed without Git or target execution. If a context uses only packed objects unsupported by the auditor, it returns a precise UNKNOWN rather than silently trusting an inventory.

Eleven stdlib data-only auditor controls pass. They test archive refusal, identity mixing, node-specific protected assertions, native phase accounting and causal closure; they are not UDM native qualifications. Initial raw index snapshots and the parser smoke report are retained beside this document.
