"""Auditor primitive controls only; never native UDM qualification."""
import copy
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

from audit_v43 import Store, safe_name, native_status, live_nodes, sha, fp, receipt_identity_matches, protected_failure_matches, audit_cas_native_links, Checks, interface_gate_files, authenticated_build_launch


class AuditorPrimitiveControls(unittest.TestCase):
    def test_closed_archive_path_grammar(self):
        for value in ('/absolute', '../escape', 'a/../escape', 'a\\escape', 'a//b', './a', '', 'a\0b'):
            self.assertFalse(safe_name(value), value)
        for value in ('a', 'a/b', 'a/b/'):
            self.assertTrue(safe_name(value), value)

    def test_regular_content_cache_never_uses_archive_path(self):
        with tempfile.TemporaryDirectory() as root:
            store = Store(Path(root)/'cache')
            info = tarfile.TarInfo('original/source.py')
            info.size = 4
            store.add(info, io.BytesIO(b'data'))
            self.assertEqual(store.raw(info.name), b'data')
            self.assertEqual(sorted(path.name for path in (Path(root)/'cache').iterdir()), [sha(b'data')])
            self.assertFalse((Path(root)/'original').exists())

    def test_duplicate_regular_member_refused(self):
        with tempfile.TemporaryDirectory() as root:
            store = Store(Path(root)/'cache')
            info = tarfile.TarInfo('same')
            store.add(info, io.BytesIO(b''))
            with self.assertRaises(ValueError):
                store.add(info, io.BytesIO(b'forged'))

    def test_archived_symlink_is_inventory_only(self):
        with tempfile.TemporaryDirectory() as root:
            store = Store(Path(root)/'cache')
            info = tarfile.TarInfo('alias')
            info.type = tarfile.SYMTYPE
            info.linkname = '/outside/unsafe'
            store.add(info)
            self.assertEqual(store.entries['alias']['target'], '/outside/unsafe')
            with self.assertRaises(ValueError):
                store.raw('alias')
            self.assertEqual(list((Path(root)/'cache').iterdir()), [])

    def test_hardlinks_and_special_files_are_refused(self):
        with tempfile.TemporaryDirectory() as root:
            for kind in (tarfile.LNKTYPE, tarfile.CHRTYPE, tarfile.FIFOTYPE):
                store = Store(Path(root)/kind.decode())
                info = tarfile.TarInfo('special')
                info.type = kind
                with self.assertRaises(ValueError):
                    store.add(info)

    def test_native_outcome_is_reconstructed_from_complete_phases(self):
        collection = {'collected_test_nodes': ['a', 'b'], 'selected_test_nodes': ['a', 'b'],
                      'plugin_manifest': [], 'test_items': []}
        rows = [{'nodeid': node, 'when': phase, 'outcome': 'passed', 'wasxfail': ''}
                for node in ('a', 'b') for phase in ('setup', 'call', 'teardown')]
        data = {**collection, 'timeout': False, 'reports': rows, 'process_exit_code': 0}
        counts = dict(tests=2, passed=2, failures=0, errors=0, skipped=0)
        self.assertEqual(native_status(data, counts, collection), 'PASS_NATIVE')
        data['reports'][4]['outcome'] = 'failed'
        data['process_exit_code'] = 1
        self.assertEqual(native_status(data, dict(counts, passed=1, failures=1), collection), 'FAIL_NATIVE')
        data['reports'][4]['wasxfail'] = 'hidden'
        self.assertEqual(native_status(data, dict(counts, passed=1, failures=1), collection), 'UNKNOWN_SKIPPED_OR_XFAIL')
        data['reports'][4]['wasxfail'] = ''
        data['reports'].pop()
        self.assertEqual(native_status(data, dict(counts, passed=1, failures=1), collection), 'UNKNOWN_REQUIRED_ASSERTION_EXECUTION')

    def test_source_mutation_and_changed_collection_fail_closed(self):
        collection = {'collected_test_nodes': ['a'], 'selected_test_nodes': ['a'],
                      'plugin_manifest': [], 'test_items': []}
        counts = dict(tests=1, passed=1, failures=0, errors=0, skipped=0)
        self.assertEqual(native_status({**collection, 'source_mutations': ['source.py']}, counts, collection),
                         'UNKNOWN_SOURCE_OR_IMPORT_IDENTITY')
        self.assertEqual(native_status({**collection, 'selected_test_nodes': []}, counts, collection),
                         'UNKNOWN_EXACT_COLLECTION')

    def test_complete_context_receipt_binding_refuses_wrong_candidate_and_other_task(self):
        environment = {'executable': 'frozen-python', 'pytest': 'frozen-pytest'}
        contract = {'repository': 'fixture/alpha', 'commit': 'c', 'protocol_binding': 'p',
                    'git_tree': 't', 'tracked_tree_sha256': 's', 'file_count': 1,
                    'environment_sha256': fp(environment)}
        authority, policy, candidate = {'required': ['test']}, {'horizon': 1}, {'replacements': []}
        certificate = {'environment': environment, 'plugins': []}
        receipt = {'schema': 'UDM_GENERIC_NATIVE_PYTEST_V43', 'repository': contract['repository'],
            'commit': 'c', 'protocol_binding': 'p',
            'source': {key: contract[key] for key in ('git_tree', 'tracked_tree_sha256', 'file_count')},
            'contract_sha256': fp(contract), 'authority_sha256': fp(authority),
            'policy_sha256': fp(policy), 'certificate_sha256': fp(certificate),
            'candidate_sha256': fp(candidate), 'runner_sha256': 'runner', 'environment': environment,
            'plugins': []}
        args = contract, authority, policy, certificate, candidate, 'runner'
        self.assertTrue(receipt_identity_matches(receipt, *args))
        for key, forged in [('candidate_sha256', 'different'), ('contract_sha256', 'other-task'),
                            ('certificate_sha256', 'stale'), ('runner_sha256', 'altered')]:
            with self.subTest(key=key):
                value = dict(receipt, **{key: forged})
                self.assertFalse(receipt_identity_matches(value, *args))

    def test_protected_assertion_requires_matching_xml_failure_node(self):
        rows = [{'nodeid': 'tests/test_native.py::test_protected', 'when': 'call',
                 'outcome': 'failed', 'wasxfail': ''}]
        good = b'<testsuites><testcase classname="tests.test_native" name="test_protected"><failure message="assert 0 == 1">AssertionError</failure></testcase></testsuites>'
        self.assertTrue(protected_failure_matches(good, rows, ['tests/test_native.py::test_protected']))
        wrong_node = good.replace(b'name="test_protected"', b'name="test_other"')
        self.assertFalse(protected_failure_matches(wrong_node, rows, ['tests/test_native.py::test_protected']))
        irrelevant_output = b'<testsuites><testcase classname="tests.test_native" name="test_protected"><failure>unrelated exception</failure><system-out>assert 0 == 1</system-out></testcase></testsuites>'
        self.assertFalse(protected_failure_matches(irrelevant_output, rows, ['tests/test_native.py::test_protected']))
        self.assertFalse(protected_failure_matches(good, rows, ['tests/test_native.py::different']))
        duplicate = good.replace(b'</testsuites>', good.split(b'<testsuites>')[1])
        self.assertFalse(protected_failure_matches(duplicate, rows, ['tests/test_native.py::test_protected']))

    def test_cas_admission_requires_two_distinct_audited_native_receipts(self):
        environment = {'executable': 'frozen-python'}
        contract = {'repository': 'fixture/alpha', 'commit': 'c', 'protocol_binding': 'p',
            'git_tree': 't', 'tracked_tree_sha256': 's', 'file_count': 1,
            'environment_sha256': fp(environment)}
        authority, policy, candidate = {'required': ['test']}, {'horizon': 1}, {'replacements': []}
        certificate = {'schema': 'UDM_NATIVE_ADMISSION_CERTIFICATE_V43', 'environment': environment, 'plugins': []}
        raw_source = b'frozen-native-worker'
        receipt = {'schema': 'UDM_GENERIC_NATIVE_PYTEST_V43', 'repository': contract['repository'],
            'commit': 'c', 'protocol_binding': 'p',
            'source': {key: contract[key] for key in ('git_tree', 'tracked_tree_sha256', 'file_count')},
            'contract_sha256': fp(contract), 'authority_sha256': fp(authority),
            'policy_sha256': fp(policy), 'certificate_sha256': fp(certificate),
            'candidate_sha256': fp(candidate), 'runner_sha256': sha(raw_source),
            'environment': environment, 'plugins': [], 'status': 'PASS_NATIVE', 'actual_run': 'first'}
        second = dict(receipt, actual_run='second')
        objects = {}
        def put(value):
            key = fp(value)
            objects[key] = value
            return key
        descriptor = {key: contract[key] for key in
            ('repository', 'commit', 'git_tree', 'tracked_tree_sha256', 'protocol_binding', 'environment_sha256')}
        descriptor.update(verifier_sha256=sha(raw_source), contract=put(contract), suite_authority=put(authority),
                          policy=put(policy), certificate=put(certificate))
        program = put(candidate)
        bundle = {'program': program, 'generation': 1, 'runs': [receipt, second]}
        bundle_key = put(bundle)
        observation = {'id': 'observation', 'kind': 'generic_native_observation', 'payload': {
            'candidate': program, 'contract_sha256': fp(contract), 'receipt': put(receipt)}, 'premises': []}
        verification = {'id': 'verification', 'kind': 'generic_native_verification',
                        'payload': {'program': program, 'receipt': bundle_key}, 'premises': []}
        capability = {'id': 'capability', 'kind': 'executable_capability', 'premises': [], 'payload': {
            'operation': 'native.pytest_suite', 'source': descriptor, 'program': program,
            'dependencies': ['support', 'observation'], 'evidence': ['verification'], 'generation': 1,
            'scope': {'materialization': None}, 'observation': put(dict(receipt, observation_id='observation'))}}
        native = {'receipts': [{'sha256': fp(value)} for value in (receipt, second)],
                  'certificates': [{'sha256': fp(certificate)}]}
        class Source:
            def raw(self, name): return raw_source
        checks = Checks()
        rows = [observation, verification, capability]
        audit_cas_native_links(rows, objects, Source(), native, {}, checks, 'data-only-control')
        self.assertTrue(all(row['pass'] for row in checks.rows), checks.rows)
        objects[bundle_key] = dict(bundle, runs=[receipt, receipt])
        checks = Checks()
        audit_cas_native_links(rows, objects, Source(), native, {}, checks, 'data-only-control')
        self.assertTrue(any(not row['pass'] and row['check'].startswith('native_cas_independent_admission_runs:')
                            for row in checks.rows))

    def test_frozen_interface_file_list_literal_suffix_without_execution(self):
        class Source:
            body = b"INTERFACE_GATE_FILES = tuple('root/'+name for name in ('a.py', 'b.py')) + ('.github/workflows/gate.yml',)"
            def raw(self, name): return self.body
        source = Source()
        self.assertEqual(interface_gate_files(source), ['root/a.py', 'root/b.py', '.github/workflows/gate.yml'])
        source.body = b"INTERFACE_GATE_FILES = tuple('root/'+name for name in ('a.py',)) + dangerous()"
        with self.assertRaises((ValueError, TypeError)):
            interface_gate_files(source)
        source.body = b"INTERFACE_GATE_FILES = tuple('root/'+name for name in ('../escape',))"
        with self.assertRaises(ValueError):
            interface_gate_files(source)

    def test_failed_or_incomplete_launch_cannot_warrant_build_verification(self):
        value = {'status': 'BUILT_NOT_SCIENTIFICALLY_VERIFIED', 'builder_sha256': 'builder',
            'recipe_sha256': 'recipe', 'commands': [{'phase': 'base-native-wheel', 'status': 'PASS', 'returncode': 0}],
            'costs': {'build_calls': 1, 'command_calls': 1, 'build_seconds': 0.5}}
        self.assertTrue(authenticated_build_launch(value, 'builder', 'recipe'))
        altered = copy.deepcopy(value); altered['commands'][0]['returncode'] = 1
        self.assertFalse(authenticated_build_launch(altered, 'builder', 'recipe'))
        altered = copy.deepcopy(value); altered['status'] = 'UNKNOWN_BUILD_ERROR'
        self.assertFalse(authenticated_build_launch(altered, 'builder', 'recipe'))
        altered = copy.deepcopy(value); altered['costs']['build_calls'] = 0
        self.assertFalse(authenticated_build_launch(altered, 'builder', 'recipe'))
        self.assertFalse(authenticated_build_launch(value, 'wrong-builder', 'recipe'))
        self.assertFalse(authenticated_build_launch(value, 'builder', 'wrong-recipe'))

    def test_revocation_recloses_transitive_support_without_resurrection(self):
        records = [{'id': 'a', 'kind': 'source_support', 'payload': {}, 'premises': []},
                   {'id': 'b', 'kind': 'verified_consequence', 'payload': {}, 'premises': ['a']},
                   {'id': 'c', 'kind': 'executable_capability', 'payload': {}, 'premises': ['b']},
                   {'id': 'u', 'kind': 'unrelated', 'payload': {}, 'premises': []}]
        self.assertEqual(live_nodes(records), {'a', 'b', 'c', 'u'})
        records.append({'id': 'r', 'kind': 'revoke', 'payload': {'target': 'b'}, 'premises': []})
        self.assertEqual(live_nodes(records), {'a', 'u'})
        records.append({'id': 'new', 'kind': 'source_support', 'payload': {}, 'premises': ['a']})
        self.assertEqual(live_nodes(records), {'a', 'u', 'new'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
