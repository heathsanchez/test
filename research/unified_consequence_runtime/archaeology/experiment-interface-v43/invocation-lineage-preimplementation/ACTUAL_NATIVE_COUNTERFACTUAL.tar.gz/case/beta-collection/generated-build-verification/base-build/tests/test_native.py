from native_beta_v43 import __version__, value
def test_existing():
    assert __version__ == "1.0.0"
