from ._version import __version__
from .subject import value
FLAVOR = 'alpha'
