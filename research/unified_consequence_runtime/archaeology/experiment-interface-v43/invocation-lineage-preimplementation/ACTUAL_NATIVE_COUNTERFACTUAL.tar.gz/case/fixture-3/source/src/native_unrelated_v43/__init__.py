from .subject import value
FLAVOR = 'unrelated'
