from native_unrelated_v43 import value
def test_existing():
    assert isinstance(value(), int)

def test_protected():
    assert value() == 0
