from native_alpha_v43 import __version__, value
def test_existing():
    assert __version__ == "1.0.0"
