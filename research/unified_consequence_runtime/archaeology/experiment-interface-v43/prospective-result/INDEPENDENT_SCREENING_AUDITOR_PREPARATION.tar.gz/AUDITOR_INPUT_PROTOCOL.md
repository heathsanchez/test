The auditor is frozen before the first source-admission CLI. No canonical
SCREENING_AUDIT is produced during preparation. Source-free controls exercise
transport/identity refusal logic only. All real source/native reads stay sealed
inside the independent admission audit; only public envelopes and the canonical
audit are released to role finalization.

Trusted authority: canonical SCREENING_AUTHORITY.json, independently supplied SHA
9dd263a8acfbbca19f838a308ca9b5aaf331e6b4c716727b8af6024df6931847.
Screening source commit: b0d389cf72f802c2b3ad99899644b802d4b41ea5.
The actual prequery commit is supplied independently and checked through the
committed receipt descriptors. Paths/code/plan filenames are generic; the old
failed prequery helper is not substituted or modified.

The trusted screening controller writes an external source snapshot BEFORE its
first screening CLI. Shape:

```json
{"source_commit":"FULL_COMMIT", "files":[
  {"path":"tracked/relative/path", "mode":"100644", "sha256":"EXACT_BYTES_SHA256"}
]}
```

Include every tracked path once, preserving Git modes; symlink hashes cover link
text, not followed contents. Preserve this snapshot and its independently held
descriptor. The controller manifest is written after actual ordered completion:

```json
{"authority_sha256":"TRUSTED_AUTHORITY_SHA256", "source_commit":"FULL_COMMIT",
 "completed":true, "retries_performed":false, "wall_seconds":0.0,
 "source_snapshot":{"path":"/ABS/SOURCE_SNAPSHOT.json","sha256":"PIN"},
 "cases":[{"index":0,"returncode":0,"command":["/LEXICAL/PYTHON","-B","-m","research.unified_consequence_runtime.qualify_native_frontier_v43","--screen-spec","/ABS/REQUEST","--authority","/ABS/AUTHORITY","--authority-sha256","TRUSTED_AUTHORITY_SHA256","--runtimes","/ABS/RUNTIMES","--out","/ABS/screening/case-000"],"started_at_utc":"ACTUAL_ISO_TIMESTAMP","wall_seconds":0.0}]}
```

The zeros and placeholders above are schema examples, never evidence. Record
actual exit codes/times/argv and retain all stdout/stderr/partial outputs. Launch
every pool member once in exact request index order; do not stop after two admit.
CLI failures/interruptions remain retained; incomplete meter accounting cannot
receive canonical PASS. This audit does not invent a completed case or retry it.

After the actual run the original screening actor supplies a bounded attestation:

```json
{"actor_identity":"ACTUAL_ACTOR", "source_commit":"FULL_COMMIT",
 "authority_sha256":"TRUSTED_AUTHORITY_SHA256", "independent_screener":true,
 "search_or_policy_outcomes_accessed":false,"learner_future_source_accessed":false,
 "native_test_reruns_or_case_retries_performed":false}
```

The no-extra-retry attestation excludes the mandatory original independently verified
collection/reexecution protocol; it prohibits extra experimental repeats.
These are actual role/exposure attestations, not claims established by booleans
alone. Preserve the actor's explanation and the controller/process evidence.
The trusted parent independently records controller/attestation SHA256 pins.

After all cases finish and the native source HOLD is released, invoke:

```bash
export GIT_OPTIONAL_LOCKS=0
export PYTHONDONTWRITEBYTECODE=1
/workspace/qualification/native-authority-v42-controller/bin/python -B \
 /workspace/qualification/experiment-interface-v43-screening-audit-preparation/audit_retained.py \
 --repo /workspace/udm-v54 \
 --records /workspace/udm-v54/research/unified_consequence_runtime/archaeology/experiment-interface-v43/prospective \
 --requests /workspace/qualification/native-frontier-v43-operator/requests \
 --sealed /workspace/qualification/native-frontier-v43-operator/screening \
 --authority-sha256 9dd263a8acfbbca19f838a308ca9b5aaf331e6b4c716727b8af6024df6931847 \
 --source-commit b0d389cf72f802c2b3ad99899644b802d4b41ea5 \
 --prequery-commit ACTUAL_FULL_PREQUERY_COMMIT \
 --controller-manifest /ABS/ACTUAL_CONTROLLER_MANIFEST.json \
 --controller-manifest-sha256 TRUSTED_PARENT_PIN \
 --attestation /ABS/ACTUAL_SCREENING_ACTOR_ATTESTATION.json \
 --attestation-sha256 TRUSTED_PARENT_PIN \
 --out /ABS/NEW_PRIVATE_AUDIT_DIRECTORY
```

The requests directory is explicit because only the actual root transport knows
its chosen directory. It is not inferred or fabricated by the auditor. Source
and runtime inspectors hash raw Git/index/filesystem/archive/RECORD/plugin bytes;
the only deferred Git operations are read-only metadata with optional locks and
lazy fetching disabled. No target interpreter, backend, pytest or native verifier
runs. No new network request is made. Missing/invalid identity evidence closes
as UNKNOWN with precise checks; an admitted case needs both concrete native
executions, complete protected collection and exact source/test/import bytes.

If and only if RETAINED_CHECKS.json closes, the independent auditor pins it and
runs finalize_audit.py --dossier /ABS/RETAINED_CHECKS.json --dossier-sha256 PIN
--out /ABS/NEW_SCREENING_AUDIT.json. The finalizer writes new-only and supplies
the exact status/digests/eligibility/exposure fields consumed by the reviewed
prepare_records.py. A passing audit validates retained admission evidence and
negatives; it does not promote UNKNOWN, choose roles, establish G2–G6 or claim
hostile-host non-bypassability. All full-cost gaps remain UNKNOWN; parent/nested
wall intervals are nonadditive.
