"""Synthetic raw-object/file controls; no target, interpreter, network or Git run."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import zlib

import pytest

CODE = Path(__file__).with_name('raw_identity.py')


def load():
    assert CODE.is_file(), 'offline raw identity helper must exist'
    spec = importlib.util.spec_from_file_location('_source_free_raw_identity', CODE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def blob(kind, raw):
    return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()


def put(git, kind, raw):
    key = blob(kind, raw)
    p = git/'objects'/key[:2]/key[2:]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(zlib.compress(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw))
    return key


def fixture(tmp_path):
    repo = tmp_path/'source'
    git = repo/'.git'
    (git/'objects/pack').mkdir(parents=True)
    base_files = {'production.py':b'answer = 42\n', 'test_original.py':b'def test_answer():\n    assert 42 == 42\n'}
    after = dict(base_files, **{'test_original.py':b'def test_answer():\n    assert 42 == 42\n    assert True\n'})
    def commit(files, parent=None):
        entries = []
        rows = []
        for name, raw in sorted(files.items()):
            oid = put(git, 'blob', raw)
            entries.append(b'100644 '+name.encode()+b'\0'+bytes.fromhex(oid))
            rows.append((name, oid))
        tree = put(git, 'tree', b''.join(entries))
        body = b'tree '+tree.encode()+b'\n'+(b'parent '+parent.encode()+b'\n' if parent else b'')+b'author Fixture <fixture@invalid> 1 +0000\ncommitter Fixture <fixture@invalid> 1 +0000\n\nfixture\n'
        return put(git, 'commit', body), rows
    base, _ = commit(base_files)
    aug, rows = commit(after, base)
    (git/'HEAD').write_text(aug+'\n')
    for name, raw in after.items():
        (repo/name).write_bytes(raw)
    idx = b'DIRC'+struct.pack('>II',2,len(rows))
    for name, oid in rows:
        entry = bytearray(62)
        struct.pack_into('>I',entry,24,0o100644)
        entry[40:60] = bytes.fromhex(oid)
        struct.pack_into('>H',entry,60,len(name))
        entry += name.encode()+b'\0'
        entry += b'\0'*((-len(entry))%8)
        idx += entry
    (git/'index').write_bytes(idx+hashlib.sha1(idx).digest())
    return repo, base, aug, base_files, after


def test_raw_git_and_complete_worktree_match(tmp_path):
    m = load(); repo, base, aug, old, after = fixture(tmp_path)
    before = m.raw_snapshot(repo,base)
    result = m.raw_snapshot(repo,aug,filesystem=True)
    assert before['files'] == old
    assert result['files'] == after
    assert result['identity']['git_tree'] != before['identity']['git_tree']
    assert all(x['passed'] for x in result['checks'])


def test_changed_untracked_worktree_file_refused(tmp_path):
    m = load(); repo, _, aug, _, _ = fixture(tmp_path)
    (repo/'hidden.py').write_text('answer=0\n')
    with pytest.raises((ValueError,AssertionError), match='filesystem'):
        m.raw_snapshot(repo,aug,filesystem=True)


def test_corrupt_raw_git_blob_refused(tmp_path):
    m = load(); repo, _, aug, _, _ = fixture(tmp_path)
    object_path = next((repo/'.git/objects').glob('[0-9a-f][0-9a-f]/*'))
    object_path.write_bytes(zlib.compress(b'blob 1\0x'))
    with pytest.raises((ValueError,AssertionError,KeyError)):
        m.raw_snapshot(repo,aug,filesystem=True)


def test_external_object_alternate_refused(tmp_path):
    m = load(); repo, _, aug, _, _ = fixture(tmp_path)
    (repo/'.git/objects/info').mkdir()
    (repo/'.git/objects/info/alternates').write_text('/other/objects\n')
    with pytest.raises((ValueError,AssertionError), match='alternate'):
        m.raw_snapshot(repo,aug)


def test_source_authority_recomputed_over_exact_original_test_delta(tmp_path):
    m = load(); repo, base, aug, _, _ = fixture(tmp_path)
    old = m.raw_snapshot(repo,base); after = m.raw_snapshot(repo,aug)
    authority = m.derive_authority(old,after,base,aug,'a'*64,'fixture/source')
    contract = dict(schema='UDM_GENERIC_NATIVE_PYTEST_V43', repository='fixture/source',repo_path=str(repo),commit=aug,protocol_binding='a'*64,**after['identity'])
    result = m.audit_source(contract,authority,None,tmp_path)
    assert result['status'] == 'PASS_OFFLINE_SOURCE_IDENTITY'
    assert result['files'] == after['files']
    assert result['base_files'] == old['files']
    assert result['rederived_authority'] == authority


def test_consistently_rehashed_production_overlay_refused(tmp_path):
    m = load(); repo, base, aug, _, _ = fixture(tmp_path)
    old = m.raw_snapshot(repo,base); after = m.raw_snapshot(repo,aug)
    after['files']['production.py'] = b'answer = 0\n'
    with pytest.raises(ValueError,match='canonical author Python tests'):
        m.derive_authority(old,after,base,aug,'a'*64,'fixture/source')


def test_production_mode_only_overlay_refused(tmp_path):
    m = load(); repo, base, aug, _, _ = fixture(tmp_path)
    old = m.raw_snapshot(repo,base); after = m.raw_snapshot(repo,aug)
    after['manifest'] = [dict(row,mode='100755') if row['path']=='production.py' else row for row in after['manifest']]
    with pytest.raises(ValueError,match='typed non-test'):
        m.derive_authority(old,after,base,aug,'a'*64,'fixture/source')


def test_no_contract_is_explicitly_incomplete():
    result = load().audit_source(None,None,None,None)
    assert result['status'].startswith('UNKNOWN')
    assert result['coverage_complete'] is False


def test_runtime_requires_actual_retained_environment():
    result = load().audit_runtime({'repo_path':'/not/a/case','interpreter':'/not/python'}, {}, {})
    assert result['status'].startswith('UNKNOWN')
    assert result['coverage_complete'] is False


def test_file_identity_tampering_is_detected(tmp_path):
    m = load(); p=tmp_path/'plugin.py';p.write_text('x=1\n')
    row={'path':str(p),'sha256':m.sha(p.read_bytes())}
    assert m.check_file(row)
    p.write_text('x=2\n')
    assert not m.check_file(row)


def runtime_fixture(tmp_path):
    m=load();venv=tmp_path/'venv';interpreter=venv/'bin/python';interpreter.parent.mkdir(parents=True)
    interpreter.write_bytes(b'NOT_AN_EXECUTABLE_SOURCE_FREE_FIXTURE')
    stdlib=tmp_path/'stdlib';stdlib.mkdir();module=stdlib/'fixture_stdlib.py';module.write_text('x=1\n')
    site=venv/'lib/python3.12/site-packages';package=site/'pytest';package.mkdir(parents=True)
    (package/'__init__.py').write_text('VERSION="8.4.1"\n')
    dist=site/'pytest-8.4.1.dist-info';dist.mkdir()
    (dist/'METADATA').write_text('Metadata-Version: 2.1\nName: pytest\nVersion: 8.4.1\n')
    (dist/'RECORD').write_text('pytest/__init__.py,,\npytest-8.4.1.dist-info/METADATA,,\npytest-8.4.1.dist-info/RECORD,,\n')
    rows=[['pytest','8.4.1',[[name,m.sha((site/name).read_bytes())] for name in ['pytest-8.4.1.dist-info/METADATA','pytest-8.4.1.dist-info/RECORD','pytest/__init__.py']]]]
    std_rows=[[str(module),m.sha(module.read_bytes())]]
    env={'executable':str(interpreter),'executable_sha256':m.sha(interpreter.read_bytes()),'pytest_version':'8.4.1',
        'pytest_import':{'path':str(package/'__init__.py'),'sha256':m.sha((package/'__init__.py').read_bytes())},
        'distributions_sha256':m.fp(rows),'distribution_count':1,'runtime_import_roots':[str(stdlib)],
        'runtime_identity':{'executable_sha256':m.sha(interpreter.read_bytes()),'version_info':[3,12,0,'final',0],
            'implementation':'fixture-claim-only','base_prefix':'/fixture','stdlib_manifest_sha256':m.fp(std_rows)}}
    contract={'interpreter':str(interpreter),'repo_path':str(tmp_path/'source'),'environment_sha256':m.fp(env)}
    return m,contract,env,{'pytest_version':'8.4.1','plugins':[]},module


def test_complete_runtime_byte_inventory_is_read_without_execution(tmp_path):
    m,contract,environment,policy,_=runtime_fixture(tmp_path)
    result=m.audit_runtime(contract,policy,{},environment=environment,plugins=[])
    assert result['status']=='PASS_OFFLINE_RUNTIME_BYTE_IDENTITY'
    assert result['coverage_complete'] is True
    assert 'not independently queried' in result['limitations'][0]


def test_retained_runtime_stdlib_mutation_refused(tmp_path):
    m,contract,environment,policy,module=runtime_fixture(tmp_path)
    module.write_text('x=2\n')
    with pytest.raises(ValueError,match='stdlib'):
        m.audit_runtime(contract,policy,{},environment=environment,plugins=[])
