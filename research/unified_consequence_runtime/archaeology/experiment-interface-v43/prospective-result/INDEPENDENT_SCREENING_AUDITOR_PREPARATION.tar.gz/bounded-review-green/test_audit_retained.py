"""Data-only audit boundary controls; no target, model, build or native oracle."""
import copy
import importlib.util
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent


def module():
    path = HERE / 'audit_retained.py'
    assert path.is_file(), 'frozen V43 screening auditor is not implemented'
    spec = importlib.util.spec_from_file_location('screening_audit_control', path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def record(status='UNKNOWN_SETUP'):
    spec = {'repo': 'fixture/source', 'base_commit': 'a'*40}
    fingerprint = __import__('hashlib').sha256(b'{"base_commit":"'+b'a'*40+b'","repo":"fixture/source"}').hexdigest()
    report = {'schema': 'UDM_ADMISSION_ONLY_CASE_V43', 'repository': spec['repo'],
        'spec_sha256': fingerprint, 'status': status, 'eligible': status in ('PASS_NATIVE', 'FAIL_NATIVE'),
        'screening_mode': 'ADMISSION_ONLY_NO_CATALOG_OR_CANDIDATE_SEARCH',
        'accounting_complete': True, 'controller_attempts': {'native_calls': 0, 'collection_calls': 0, 'subprocess_attempts': 0},
        'partial_native_reports': [], 'total_wall_seconds': 1,
        'build_attempts': {'before': {'verification_attempts': 0, 'builder_attempts': {'build_calls': 0, 'build_seconds': 0, 'records': []}},
                           'after': {'verification_attempts': 0, 'builder_attempts': {'build_calls': 0, 'build_seconds': 0, 'records': []}}}}
    return spec, report


def test_native_pass_and_fail_have_identical_public_eligibility():
    m = module()
    for status in ('PASS_NATIVE', 'FAIL_NATIVE'):
        spec, report = record(status)
        assert m.public_fields(report)['status'] == 'ADMITTED_NATIVE'
        assert m.public_fields(report)['eligible'] is True


def test_unknown_stays_ineligible_without_status_promotion():
    m = module(); _, report = record()
    assert m.public_fields(report)['status'] == 'UNKNOWN_ADMISSION_SCREENING'
    assert m.public_fields(report)['eligible'] is False


@pytest.mark.parametrize('change', [
    {'eligible': True}, {'accounting_complete': False},
    {'controller_attempts': {'native_calls': True, 'collection_calls': 0}},
    {'controller_attempts': {'native_calls': -1, 'collection_calls': 0}},
    {'total_wall_seconds': float('nan')},
])
def test_invalid_public_accounting_refuses(change):
    m = module(); _, report = record(); report.update(change)
    with pytest.raises((ValueError, TypeError)):
        m.public_fields(report)


def test_build_costs_include_refused_launches_and_verification_attempts_separately():
    m = module(); _, report = record()
    report['build_attempts']['after'] = {'verification_attempts': 3,
        'builder_attempts': {'build_calls': 1, 'build_seconds': .25, 'records': ['retained-failed-build.json']}}
    costs = m.build_costs(report)
    assert costs['build_calls'] == 1 and costs['verification_attempts'] == 3
    assert costs['build_seconds'] == .25


@pytest.mark.parametrize('wrong', ['authority', 'index', 'spec'])
def test_request_replay_or_reorder_refuses(wrong):
    m = module(); spec, report = record()
    request = {'pool_index': 0, 'spec': spec, 'protocol_binding': 'b'*64}
    if wrong == 'authority': request['protocol_binding'] = 'c'*64
    if wrong == 'index': request['pool_index'] = 1
    if wrong == 'spec': request['spec'] = dict(spec, repo='fixture/other')
    with pytest.raises(ValueError): m.validate_request(0, spec, request, 'b'*64)


@pytest.mark.parametrize('change', ['missing_unknown', 'reordered', 'pending', 'wrong_authority', 'counts'])
def test_entire_ordered_pool_and_all_unknowns_are_required(change):
    m = module(); spec, report = record(); second = dict(spec, repo='fixture/second')
    rows = [{'index': i, 'spec_sha256': m.fp(s), 'costs': {'native_calls': 0, 'collection_calls': 0, 'subprocess_attempts': 0}, 'accounting_complete': True} for i,s in enumerate([spec,second])]
    meter = {'schema': 'UDM_ORDERED_SCREENING_METER_V43', 'authority_sha256': 'b'*64,
             'cases': rows, 'pending': None, 'accounting_complete': True, 'native_calls': 0, 'collection_calls': 0}
    if change == 'missing_unknown': meter['cases'] = rows[:1]
    if change == 'reordered': meter['cases'] = rows[::-1]
    if change == 'pending': meter['pending'] = {'index': 1}
    if change == 'wrong_authority': meter['authority_sha256'] = 'c'*64
    if change == 'counts': meter['native_calls'] = 1
    with pytest.raises(ValueError): m.validate_meter([spec,second], meter, 'b'*64)


def context():
    raw = b'def test_original():\n    assert False\n'
    files = {'tests/test_original.py': raw, 'package.py': b'VALUE=1\n'}
    h = __import__('hashlib').sha256
    data = {'collected_test_nodes': ['tests/test_original.py::test_original'],
            'selected_test_nodes': ['tests/test_original.py::test_original'],
            'deselected_test_nodes': [], 'collection_errors': [], 'source_mutations': [],
            'unexpected_imports': [], 'external_project_imports': [], 'plugin_violations': [],
            'test_items': [{'nodeid':'tests/test_original.py::test_original', 'path': 'tests/test_original.py', 'sha256': h(raw).hexdigest()}],
            'import_manifest': [{'path': 'package.py', 'sha256': h(files['package.py']).hexdigest()}]}
    return files, data


@pytest.mark.parametrize('change', ['missing_protected', 'changed_test', 'forged_import', 'deselected', 'aliased_import'])
def test_consistent_packet_hashes_cannot_replace_exact_source_and_protected_nodes(change):
    m = module(); files,data = context()
    if change == 'missing_protected': data['collected_test_nodes'] = data['selected_test_nodes'] = ['tests/test_original.py::other']
    if change == 'changed_test': data['test_items'][0]['sha256'] = '0'*64
    if change == 'forged_import': data['import_manifest'][0]['sha256'] = '0'*64
    if change == 'deselected': data['deselected_test_nodes'] = ['tests/test_original.py::test_original']
    if change == 'aliased_import': data['import_manifest'][0]['path'] = '../package.py'
    with pytest.raises(ValueError): m.validate_context_bytes(data, files, ['tests/test_original.py::test_original'])


def test_complete_data_context_uses_exact_original_bytes():
    m = module(); files,data = context()
    m.validate_context_bytes(data, files, ['tests/test_original.py::test_original'])


def test_finalizer_never_emits_canonical_pass_from_incomplete_or_failed_dossier():
    m = module()
    for dossier in ({'status': 'UNKNOWN', 'checks': []},
                    {'status': 'PASS_RETAINED_SCREENING_BINDINGS', 'checks': [{'pass': False}]},
                    {'status': 'PASS_RETAINED_SCREENING_BINDINGS', 'checks': []}):
        with pytest.raises(ValueError): m.require_closed_dossier(dossier)


@pytest.mark.parametrize('change',['missing','empty','wrong_blob','wrong_head'])
def test_exact_complete_author_test_transports_bind_the_frozen_head(change):
    m=module();spec={'repo':'fixture/source','head_commit':'d'*40,'files':[{'filename':'tests/test_x.py','sha':'e'*40,'status':'modified'}]}
    boundaries={'author_test_head_commit':'d'*40,'author_tests':[{'path':'tests/test_x.py','git_blob':'e'*40}]}
    source={'source_boundaries':boundaries,'author_test_transports':[{'record':boundaries['author_tests'][0]}]}
    if change=='missing':source['source_boundaries']=None
    if change=='empty':source['author_test_transports']=[];boundaries['author_tests']=[]
    if change=='wrong_blob':boundaries['author_tests'][0]['git_blob']='f'*40
    if change=='wrong_head':boundaries['author_test_head_commit']='f'*40
    with pytest.raises(ValueError):m.validate_author_tests(spec,source)


@pytest.mark.parametrize('report_status',['UNKNOWN_SETUP','PASS_NATIVE','FAIL_NATIVE'])
def test_completed_native_outcome_cannot_be_masked_or_swapped(report_status):
    m=module();_,report=record(report_status)
    outcome='FAIL_NATIVE' if report_status=='PASS_NATIVE' else 'PASS_NATIVE'
    with pytest.raises(ValueError):m.validate_native_disposition(report,[{'status':outcome},{'status':outcome}])


def test_test_item_inventory_must_cover_every_collected_node():
    m=module();files,data=context();data['collected_test_nodes'].append('tests/test_original.py::second')
    data['selected_test_nodes']=list(data['collected_test_nodes'])
    with pytest.raises(ValueError):m.validate_context_bytes(data,files,['tests/test_original.py::test_original'])


@pytest.mark.parametrize('change',['evidence_hash','preparation','wheel_members'])
def test_generated_build_warrant_closes_original_and_independent_wheels(change):
    m=module();e={'binding':{'base':'fixed'},'generated_sha256':{'pkg/_version.py':'a'*64},'wheel_evidence':{'wheel_path':'original','wheel_sha256':'b'*64}}
    prep={'status':'BUILT_NOT_SCIENTIFICALLY_VERIFIED','binding':e['binding'],'generated_sha256':e['generated_sha256'],'generated_wheel_evidence':e['wheel_evidence']}
    v={'status':'INDEPENDENT_BUILD_AUTHENTICATED_NOT_NATIVE_OUTCOME','binding':e['binding'],'evidence_sha256':m.fp(e),'build':copy.deepcopy(prep)}
    original={'pkg/_version.py':b'v=1','pkg/__init__.py':b'original'};rebuilt=dict(original)
    if change=='evidence_hash':v['evidence_sha256']='0'*64
    if change=='preparation':prep['generated_wheel_evidence']=dict(prep['generated_wheel_evidence'],wheel_sha256='c'*64)
    if change=='wheel_members':rebuilt['pkg/__init__.py']=b'different original member'
    with pytest.raises(ValueError):m.validate_generated_link(e,prep,v,original,rebuilt)


def test_relative_original_source_plugin_uses_exact_decoded_source_bytes():
    m=module();raw=b'ORIGINAL_PLUGIN=1\n';plugin={'kind':'source','path':'conftest.py','sha256':__import__('hashlib').sha256(raw).hexdigest()}
    m.validate_plugin_bytes(plugin,{'conftest.py':raw},lambda _:pytest.fail('source plugin must not be opened as an absolute runtime path'))
