"""Offline supplied-run V43 screening audit. No target interpreter or build runs.

This is an evidence auditor, not an oracle or reference monitor. The command
requires independently supplied authority, controller and actor pins. It writes
only a new external audit directory; a finalizer separately closes its dossier.
"""
import argparse
import ast
import base64
import datetime
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess

HERE = Path(__file__).resolve().parent
MODE = 'ADMISSION_ONLY_NO_CATALOG_OR_CANDIDATE_SEARCH'
COVERAGE = ('V43 builder launches and generated-build verification attempts in this screening interval; '
    'parent wall time includes provisioning, host checks and independent oracle work. '
    'Original native counters and ceilings are unchanged; build seconds are included in parent wall time.')
HEX = re.compile(r'[0-9a-f]{64}')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def fp(value): return sha(canonical(value).encode())


def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def require(ok, reason):
    if not ok: raise ValueError(reason)


def count(value):
    require(type(value) is int and value >= 0, 'invalid integer launch count')
    return value


def build_costs(report):
    before, after = (report['build_attempts'][key] for key in ('before', 'after'))
    result = {'coverage': COVERAGE, 'inclusive_parent_wall_seconds': report['total_wall_seconds']}
    for key in ('build_calls', 'build_seconds'):
        a,b = before['builder_attempts'][key], after['builder_attempts'][key]
        require(number(a) and number(b) and b >= a, 'build counter rollback or invalid count')
        if key == 'build_calls': count(a); count(b)
        result[key] = b-a
    a,b = before['verification_attempts'], after['verification_attempts']
    count(a);count(b);require(b >= a, 'verification counter rollback')
    result['verification_attempts'] = b-a
    require(number(result['inclusive_parent_wall_seconds']), 'invalid parent wall time')
    old,new = before['builder_attempts']['records'], after['builder_attempts']['records']
    require(isinstance(old,list) and isinstance(new,list) and new[:len(old)] == old,
            'build record prefix changed')
    return result


def public_fields(report):
    require(report['schema'] == 'UDM_ADMISSION_ONLY_CASE_V43', 'wrong screening report schema')
    require(report['screening_mode'] == MODE, 'candidate/search information in screening mode')
    require(report.get('accounting_complete') is True, 'incomplete native accounting')
    eligible = report['status'] in ('PASS_NATIVE', 'FAIL_NATIVE')
    require(report.get('eligible') is eligible, 'PASS/FAIL parity or UNKNOWN eligibility differs')
    require(number(report['total_wall_seconds']), 'invalid case wall time')
    costs = {key: count(report['controller_attempts'].get(key,0)) for key in ('native_calls','collection_calls')}
    for row in report.get('partial_native_reports', []):
        for key in costs: count(row.get('costs',{}).get(key,0))
    for key in costs:
        costs[key] = max(costs[key],sum(row.get('costs',{}).get(key,0) for row in report.get('partial_native_reports',[])))
    return {'schema':'UDM_SEALED_ADMISSION_ENVELOPE_V43', 'repository':report['repository'],
        'spec_sha256':report['spec_sha256'], 'status':'ADMITTED_NATIVE' if eligible else 'UNKNOWN_ADMISSION_SCREENING',
        'eligible':eligible, 'screening_mode':MODE, 'costs':costs,
        'build_costs':build_costs(report),'total_wall_seconds':report['total_wall_seconds']}


def validate_request(index, spec, request, authority_sha):
    require(request == {'pool_index':index,'spec':spec,'protocol_binding':authority_sha},
            'request source/order/trusted authority replay')


def validate_meter(pool, meter, authority_sha):
    require(meter['schema']=='UDM_ORDERED_SCREENING_METER_V43' and meter['authority_sha256']==authority_sha,
            'wrong original screening authority meter')
    require(meter.get('pending') is None and meter.get('accounting_complete') is True,
            'interrupted or incomplete screening meter')
    require(len(meter['cases'])==len(pool),'entire pool, including UNKNOWN, must be retained')
    sums={'native_calls':0,'collection_calls':0}
    for i,(spec,row) in enumerate(zip(pool,meter['cases'])):
        require(row['index']==i and row['spec_sha256']==fp(spec) and row['accounting_complete'] is True,
                'reordered, replaced or incomplete screening case')
        require(count(row['costs']['native_calls'])<=2,'per-case native ceiling exceeded')
        for key in sums:sums[key]+=count(row['costs'][key])
    require(all(count(meter[key])==value for key,value in sums.items()),'global native costs differ')


def validate_context_bytes(data, files, required):
    nodes,selected=data.get('collected_test_nodes',[]),data.get('selected_test_nodes',[])
    require(bool(nodes) and len(nodes)==len(set(nodes)) and len(selected)==len(set(selected))
            and set(nodes)==set(selected),'incomplete or duplicate selected suite')
    require(not any(data.get(key) for key in ('deselected_test_nodes','collection_errors','source_mutations',
        'unexpected_imports','external_project_imports','plugin_violations','changed_test_code')),
        'source/import/suite identity violation')
    for prefix in required:
        require(any(n==prefix or n.startswith(prefix+'[') or n.startswith(prefix+'::') for n in nodes),
                'missing complete protected assertion prefix: '+prefix)
    require(bool(data.get('test_items')),'no exact collected test-byte inventory')
    for field in ('test_items','import_manifest'):
        for row in data.get(field,[]):
            require(row.get('path') in files and row.get('sha256')==sha(files[row['path']]),
                    'exact source/test/import bytes differ: '+str(row.get('path')))


def require_closed_dossier(value):
    require(value.get('status')=='PASS_RETAINED_SCREENING_BINDINGS' and value.get('checks')
            and all(row.get('pass') is True for row in value['checks']), 'unclosed audit dossier')


class Audit:
    def __init__(self):self.checks=[];self.inputs={};self.native=[];self.builds=[];self.cases=[]
    def check(self,name,ok,detail=None):
        self.checks.append({'check':name,'pass':bool(ok),**({'detail':detail} if detail is not None else {})})
        return bool(ok)
    def read(self,path):
        path=Path(path);require(path.is_absolute() and path.resolve()==path and path.is_file()
            and not path.is_symlink(),'canonical regular retained file required: '+str(path))
        raw=path.read_bytes();self.inputs[str(path)]={'sha256':sha(raw),'bytes':len(raw)};return raw
    def js(self,path):return json.loads(self.read(path))
    def bound(self,desc,root=None):
        path=Path(desc['path']);path=(Path(root)/path) if not path.is_absolute() and root else path
        require(sha(self.read(path))==desc['sha256'],'retained external/input digest differs: '+str(path))
        return self.js(path)


def load_helper(name):
    p=HERE/name;spec=importlib.util.spec_from_file_location('_v43_screening_'+p.stem,p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def packet(a, value, folder, execution=False):
    raw={key:base64.b64decode(item,validate=True) for key,item in value['packet'].items()}
    require(value['packet_sha256']=={key:sha(item) for key,item in raw.items()},'packet hashes differ')
    required={'stdout.log','stderr.log','report.json','checked-report.json','tracked-source-manifest.json'}
    require(required<=set(raw) and not set(raw)-required-{'native.xml'},'packet membership differs')
    for name,item in raw.items():require(a.read(Path(folder)/name)==item,'packet not exact retained bytes')
    data=json.loads(raw['checked-report.json']);producer=json.loads(raw['report.json'])
    controller={'process_exit_code','timeout','source_mutations','unexpected_imports','costs'}
    require(producer=={k:v for k,v in data.items() if k not in controller},'producer/checked packet differs')
    return data,raw


def generated_files(a, evidence, contract, authority, policy, source, archive, builder, recipe):
    if evidence is None:return {}
    b=evidence['binding'];base=source['base_files'];decl=builder.declared_outputs(base)
    expected={'contract_sha256':fp(dict(contract,generated_build=None)),'authority_sha256':fp(authority),
        'policy_sha256':fp(policy),'repository':contract['repository'],'protocol_binding':contract['protocol_binding'],
        'base_commit':authority['baseline_commit'],'base_source':source['base_identity'],
        'augmented_commit':contract['commit'],'augmented_source':source['identity'],
        'pyproject_sha256':sha(base['pyproject.toml']),'declared_outputs':list(decl),
        'environment':source.get('environment',b['environment']),'scm':source['scm']}
    require(all(b.get(k)==v for k,v in expected.items()),'generated evidence source/environment/SCM binding differs')
    wheel=evidence['wheel_evidence'];raw=a.read(wheel['wheel_path']);members=archive.wheel_members(raw)
    require(sha(raw)==wheel['wheel_sha256'] and fp({k:sha(v) for k,v in sorted(members.items())})==wheel['wheel_content_sha256'],
            'retained generated wheel bytes differ')
    output={p:members[p[4:] if p.startswith('src/') else p] for p in decl}
    require(evidence['generated_sha256']=={k:sha(v) for k,v in sorted(output.items())}
            and not set(output)&set(source['files']),'declared generated bytes overwrite source or differ')
    require(wheel['builder_sha256']==recipe['builder_sha256'] and wheel['build_recipe_sha256']==recipe['recipe_sha256'],
            'wheel builder/recipe differs')
    return output


def audit_native(a, case, setup, source, archive, runner):
    contract,authority,policy=setup['contract'],setup['authority'],setup['policy']
    files=dict(source['files'],**source.get('generated',{}));manifest=source['manifest'];certificates={}
    for p in sorted(case.rglob('admission-certificate.json')):
        cert=a.js(p);require(cert['schema']=='UDM_NATIVE_ADMISSION_CERTIFICATE_V43','wrong certificate schema')
        expected={'contract_sha256':fp(contract),'authority_sha256':fp(authority),'policy_sha256':fp(policy),
            'runner_sha256':runner,'admission_revision':'4.3','status':'ADMITTED_NATIVE_COLLECTION'}
        require(all(cert.get(k)==v for k,v in expected.items()) and fp(cert['environment'])==contract['environment_sha256'],
                'certificate exact task/environment/policy replay')
        data,raw=packet(a,cert,p.parent);validate_context_bytes(data,files,authority['required_test_nodes'])
        require(json.loads(raw['tracked-source-manifest.json'])==manifest,'certificate typed source manifest differs')
        require(data['mode']=='collect' and data['process_exit_code']==data['exit_code']==0 and not data['timeout']
            and data['costs']['native_calls']==0 and data['costs']['collection_calls']==1,'not authentic complete collection')
        require({k:data[k] for k in cert['collection']}==cert['collection'] and data['pytest_import']==cert['environment']['pytest_import'],
                'certificate actual collection or pytest bytes differ')
        certificates[fp(cert)]=cert
    receipts=[]
    for p in sorted(case.rglob('receipt.json')):
        value=a.js(p)
        if value.get('schema')!='UDM_GENERIC_NATIVE_PYTEST_V43':continue
        cert=certificates.get(value['certificate_sha256']);require(cert is not None,'native receipt lacks exact retained certificate')
        require(archive.receipt_identity_matches(value,contract,authority,policy,cert,{'replacements':[]},runner),
                'screening native receipt candidate/source/context differs')
        data,raw=packet(a,value,p.parent/'execution',True);validate_context_bytes(data,files,authority['required_test_nodes'])
        require(json.loads(raw['tracked-source-manifest.json'])==manifest,'run source manifest differs')
        counts=archive.junit(raw.get('native.xml'));status=archive.native_status(data,counts,cert['collection'])
        require(value['execution']==data and value['junit']==counts and value['status']==status,'raw native outcome differs')
        require(data['mode']=='run' and data['costs']['native_calls']==1 and data['costs']['collection_calls']==0,
                'native invocation/counters differ')
        recollect=Path(value['independent_collection']['output']);require(recollect.is_relative_to(case),'external recollection path')
        observed=a.js(recollect/'checked-report.json');validate_context_bytes(observed,files,authority['required_test_nodes'])
        require(observed['mode']=='collect' and observed['process_exit_code']==0
            and {k:observed[k] for k in cert['collection']}==cert['collection'],'independent exact collection differs')
        require(value['costs']['native_calls']==1 and value['costs']['collection_calls']==1
            and number(value['costs']['total_seconds']),'native receipt inclusive cost differs')
        receipts.append({'path':str(p),'status':status,'sha256':fp(value),'junit':counts})
        a.native.append(receipts[-1])
    if setup.get('_eligible'):
        require(len(certificates)==1 and len(receipts)==2,'admitted case needs retained producer and independent execution')
        require(receipts[0]['status']==receipts[1]['status'] in ('PASS_NATIVE','FAIL_NATIVE'),
                'producer/independent native verdict mismatch')
    return certificates,receipts


def audit_builds(a, case, report, archive, recipe):
    before,after=(report['build_attempts'][k] for k in ('before','after'))
    paths=after['builder_attempts']['records'][len(before['builder_attempts']['records']):]
    calls=0;seconds=0;fingerprints=set()
    for name in paths:
        value=a.js(name);cost=value['costs'];calls+=count(cost['build_calls']);require(number(cost['build_seconds']),'invalid build time');seconds+=cost['build_seconds']
        require(cost['command_calls']==len(value['commands']),'build command cost count differs')
        if value['status']=='BUILT_NOT_SCIENTIFICALLY_VERIFIED':
            require(archive.authenticated_build_launch(value,recipe['builder_sha256'],recipe['recipe_sha256']),
                    'failed/forged build cannot warrant independent verification')
            wheel=value['generated_wheel_evidence'];raw=a.read(wheel['wheel_path']);members=archive.wheel_members(raw)
            require(sha(raw)==wheel['wheel_sha256'] and fp({k:sha(v) for k,v in sorted(members.items())})==wheel['wheel_content_sha256'],
                    'successful build wheel digest differs')
            fingerprints.add(fp(value))
        a.builds.append({'path':name,'sha256':fp(value),'status':value['status'],'costs':cost})
    require(calls==after['builder_attempts']['build_calls']-before['builder_attempts']['build_calls']
        and math.isclose(seconds,after['builder_attempts']['build_seconds']-before['builder_attempts']['build_seconds'],abs_tol=1e-8),
        'all successful/refused build launch costs must be retained')
    for p in case.rglob('verification.json'):
        v=a.js(p)
        if v.get('schema')!='UDM_INDEPENDENT_GENERATED_BUILD_VERIFICATION_V43':continue
        if v['status']=='INDEPENDENT_BUILD_AUTHENTICATED_NOT_NATIVE_OUTCOME':
            require(fp(v['build']) in fingerprints,'build verification lacks successful concrete launched build')
            require(v['binding']==v['build']['binding'],'independent build binding differs')


def audit_ledger(a, case, spec, report, authority_sha):
    path=case/'machine-state/metatron-ledger.jsonl';require(path.is_file(),'screening lacks original Machine ledger')
    rows=[json.loads(line) for line in a.read(path).splitlines() if line.strip()];seen=set()
    for row in rows:
        body={k:row[k] for k in ('kind','payload','premises')}
        encoded=json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
        require(sha(encoded)==row['id'] and row['id'] not in seen,'Machine immutable ledger hash/duplicate differs');seen.add(row['id'])
    requests=[r for r in rows if r['kind']=='native_admission_request_v43' and r['payload'].get('spec_sha256')==fp(spec)
        and r['payload'].get('protocol_binding')==authority_sha]
    require(len(requests)==1,'external source obligation missing or duplicated')
    if report.get('setup',{}).get('materialization_binding'):
        binding=report['setup']['materialization_binding'];nodes={r['id']:r for r in rows}
        require(binding['capability_id'] in nodes and binding['consequence_id'] in nodes,'exact materialization witness absent')
    return {'records':len(rows),'admission_request':requests[0]['id']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('repo','records','requests','sealed','controller-manifest','attestation','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('authority-sha256','controller-manifest-sha256','attestation-sha256','source-commit','prequery-commit'):
        parser.add_argument('--'+name,required=True)
    args=parser.parse_args();out=args.out.absolute();out.mkdir(parents=True,exist_ok=False)
    a=Audit();result=None
    try:
        for name,expected in json.loads((HERE/'TRUSTED_SOURCE_PINS.json').read_text()).items():
            require(sha(Path(name).read_bytes())==expected,'frozen audit/control source differs: '+name)
        archive=load_helper('original/archive_audit_v43.py');identity=load_helper('raw_identity.py')
        import sys
        sys.path.insert(0,str(args.repo.resolve()))
        from research.unified_consequence_runtime import native_build_v43 as builder
        runner=sha((args.repo/'research/unified_consequence_runtime/native_execution_v43.py').read_bytes())
        recipe={'builder_sha256':sha(Path(builder.__file__).read_bytes()),'recipe_sha256':fp(builder.BUILD_RECIPE)}
        rec=args.records.resolve();authority_path=rec/'SCREENING_AUTHORITY.json'
        require(HEX.fullmatch(args.authority_sha256) and sha(a.read(authority_path))==args.authority_sha256,'trusted screening authority pin differs')
        authority=a.js(authority_path);protocol=a.js(rec/'FRONTIER_PROTOCOL.json');pool=a.bound(authority['pool'],args.repo);pre=a.bound(authority['prequery'],args.repo)
        require(authority['schema']=='UDM_NATIVE_CLI_AUTHORITY_V43' and authority['operation']=='screen'
            and authority['repo']==str(args.repo.resolve()) and authority['output_root']==str(args.sealed.resolve()),'wrong canonical screening authority')
        require(authority['pool']==protocol['pool'] and authority['prequery']==protocol['prequery'],'authority/protocol input chain differs')
        require(pre['source_commit']==args.prequery_commit,'wrong independently supplied prequery commit')
        for key in ('environment_gate','interface_gate','interface_archive_audit'):
            require(authority[key]==protocol[key]==pre[key],'screening gate chain differs')
        env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
        p=subprocess.run(['git','--no-replace-objects','-C',str(args.repo),'rev-parse','HEAD'],env=env,capture_output=True)
        require(p.returncode==0 and p.stdout.decode().strip()==args.source_commit,'owned screening source commit differs')
        for path in (rec/'SCREENING_AUTHORITY.json',rec/'FRONTIER_PROTOCOL.json',rec/'FROZEN_POOL.json',rec/'PREQUERY_EXECUTION.json'):
            p=subprocess.run(['git','--no-replace-objects','-C',str(args.repo),'show',args.source_commit+':'+path.relative_to(args.repo).as_posix()],env=env,capture_output=True)
            require(p.returncode==0 and p.stdout==a.read(path),'screening input not exact committed bytes')
        controller=a.bound({'path':str(args.controller_manifest.resolve()),'sha256':args.controller_manifest_sha256})
        attestation=a.bound({'path':str(args.attestation.resolve()),'sha256':args.attestation_sha256})
        require(attestation.get('independent_screener') is True and attestation.get('search_or_policy_outcomes_accessed') is False
            and attestation.get('learner_future_source_accessed') is False and attestation.get('native_test_reruns_or_case_retries_performed') is False,
            'bounded original screening actor exposure/once-only attestation missing')
        require(controller['authority_sha256']==args.authority_sha256 and controller['source_commit']==args.source_commit
            and controller['completed'] is True and controller['retries_performed'] is False,'controller transport authority/incomplete/retry differs')
        specs=pool['pool'];meter=a.js(args.sealed/'SCREENING_METER.json');validate_meter(specs,meter,args.authority_sha256)
        require(not(args.sealed/'SCREENING_METER.lock').exists(),'active/abandoned screening lock')
        require(len(controller['cases'])==len(specs),'controller dropped fixed pool members')
        envelopes=[]
        for i,spec in enumerate(specs):
            case=args.sealed/('case-'+format(i,'03d'))
            try:
                request=a.js(args.requests/('request-'+format(i,'03d')+'.json'));validate_request(i,spec,request,args.authority_sha256)
                report=a.js(case/'SCREENING_CASE.json');envelope=a.js(case/'SCREENING_ENVELOPE.json');expected=public_fields(report)
                expected['sealed_report']={'path':str(case/'SCREENING_CASE.json'),'sha256':sha(a.read(case/'SCREENING_CASE.json'))}
                require(envelope==expected,'sealed envelope/cost/status identity differs')
                require(report['repository']==spec['repo'] and report['spec_sha256']==fp(spec),'report task differs')
                require(meter['cases'][i]['report']==expected['sealed_report']
                    and meter['cases'][i]['costs']==report['controller_attempts'],'meter/report differs')
                entry=controller['cases'][i];require(entry['index']==i and entry['returncode']==0,'controller case order/exit differs')
                argv=entry['command'];require('--authority-sha256' in argv and argv[argv.index('--authority-sha256')+1]==args.authority_sha256
                    and '--out' in argv and argv[argv.index('--out')+1]==str(case),'controller launched different authority/output')
                if i:require(datetime.datetime.fromisoformat(entry['started_at_utc']).timestamp()>=datetime.datetime.fromisoformat(controller['cases'][i-1]['started_at_utc']).timestamp()+controller['cases'][i-1]['wall_seconds'],'overlapping/out-of-order screening launches')
                ledger=audit_ledger(a,case,spec,report,args.authority_sha256)
                audit_builds(a,case,report,archive,recipe)
                setup=report.get('setup',{});closed={'source':'NOT_PREPARED','runtime':'NOT_PREPARED'}
                if setup.get('contract'):
                    source=identity.audit_source(setup['contract'],setup['authority'],report.get('certificate'),case)
                    require(source['all_checks_passed'],'raw source identity audit incomplete')
                    runtime=identity.audit_runtime(setup['contract'],setup['policy'],setup['authority'],environment=(report.get('certificate') or {}).get('environment',setup.get('runtime')))
                    require(runtime['all_checks_passed'],'offline runtime identity audit incomplete')
                    source['environment']=runtime['environment']
                    source['generated']=generated_files(a,setup['contract']['generated_build'],setup['contract'],setup['authority'],setup['policy'],source,archive,builder,recipe)
                    certificates,receipts=audit_native(a,case,dict(setup,_eligible=report['eligible']),source,archive,runner)
                    closed={'source':source['summary'],'runtime':runtime['summary'],'certificates':len(certificates),'native_receipts':receipts}
                else:require(not report['eligible'],'admitted native case lacks prepared source contract')
                envelopes.append(envelope);a.cases.append({'index':i,'eligible':report['eligible'],'status':report['status'],'identity':closed,'ledger':ledger})
                a.check('case_complete:'+str(i),True)
            except Exception as error:
                a.check('case_complete:'+str(i),False,type(error).__name__+': '+str(error))
        require(len(envelopes)==len(specs),'one or more fixed screening cases unclosed')
        a.check('all_pool_members_and_unknowns_closed',True)
        result={'status':'PASS_RETAINED_SCREENING_BINDINGS' if all(r['pass'] for r in a.checks) else 'UNKNOWN_RETAINED_SCREENING_BINDINGS',
            'pool_sha256':sha(a.read(args.repo/authority['pool']['path'])),'reports_sha256':fp(envelopes),'reports':envelopes,
            'cases':a.cases,'native':a.native,'builds':a.builds,'source_commit':args.source_commit,
            'authority':{'path':str(authority_path),'sha256':args.authority_sha256},'controller':{'path':str(args.controller_manifest.resolve()),'sha256':args.controller_manifest_sha256},
            'attestation':{'path':str(args.attestation.resolve()),'sha256':args.attestation_sha256},
            'costs':{'native_calls':meter['native_calls'],'collection_calls':meter['collection_calls'],
                'build_calls':sum(e['build_costs']['build_calls'] for e in envelopes),'build_seconds':sum(e['build_costs']['build_seconds'] for e in envelopes),
                'verification_attempts':sum(e['build_costs']['verification_attempts'] for e in envelopes),
                'sum_case_inclusive_wall_seconds':sum(e['total_wall_seconds'] for e in envelopes),'controller_wall_seconds':controller['wall_seconds']}}
    except Exception as error:
        a.check('supplied_run_complete',False,type(error).__name__+': '+str(error));result={'status':'UNKNOWN_RETAINED_SCREENING_BINDINGS'}
    result.update(schema='UDM_V43_OFFLINE_RETAINED_SCREENING_DOSSIER_V1',checks=a.checks,inputs=a.inputs,
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        limitations=['Bounded supplied-run/actor attestation; no global absence-of-unrelated-processes or hostile-host isolation proof.',
            'No target interpreter, backend, pytest or native verifier executed by this audit. Runtime implementation/version claims retain offline evidence limits.',
            'Inclusive parent and nested phase wall intervals are nonadditive. All successful/refused launches retained; unmeasured tool/model/engineering/lifecycle cost remains UNKNOWN.'],
        scientific_verdicts={'G'+str(i):'UNKNOWN' for i in range(2,7)})
    (out/'RETAINED_CHECKS.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(canonical({'status':result['status'],'output':str(out/'RETAINED_CHECKS.json')}))


if __name__=='__main__':main()
