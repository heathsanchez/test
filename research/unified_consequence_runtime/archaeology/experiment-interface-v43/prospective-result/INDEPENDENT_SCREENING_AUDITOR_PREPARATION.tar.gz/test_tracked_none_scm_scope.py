"""Data-only exercise of the actual source-audit call's SCM obligation.

Only the call expression is evaluated, with a static identity double. No main,
target source, runtime, native worker, Git operation or network call executes.
"""
import ast
from pathlib import Path
from types import SimpleNamespace

import pytest


def audit_call(generated, backend):
    tree=ast.parse(Path(__file__).with_name('audit_retained.py').read_text())
    sites=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
           and isinstance(n.func.value,ast.Name) and n.func.value.id=='identity' and n.func.attr=='audit_source']
    assert len(sites)==1
    observed=[]
    def static_source(contract,authority,certificate,case,*,include_scm):
        observed.append(include_scm)
        # Stand-in for the unchanged raw Git/source/authority byte checks.
        assert contract['schema']=='UDM_GENERIC_NATIVE_PYTEST_V43'
        assert authority=={'raw_source_identity':'exact'}
        if include_scm and backend!='hatch-vcs':raise ValueError('original generated Hatch SCM scope unavailable')
        return {'coverage_complete':True,'raw_identity_checked':True,'scm_checked':include_scm}
    values={'identity':SimpleNamespace(audit_source=static_source),
        'setup':{'contract':{'schema':'UDM_GENERIC_NATIVE_PYTEST_V43','generated_build':generated},
                 'authority':{'raw_source_identity':'exact'}},'report':{},'case':Path('/DATA_ONLY_FIXTURE')}
    result=eval(compile(ast.Expression(sites[0]),'<actual-frozen-source-call>','eval'),values)
    return result,observed


@pytest.mark.parametrize('backend',['setuptools-scm',None])
def test_tracked_none_keeps_raw_identity_without_claiming_generated_hatch_scm(backend):
    result,observed=audit_call(None,backend)
    assert result['raw_identity_checked'] is True
    assert result['scm_checked'] is False
    assert observed==[False]


def test_generated_evidence_still_refuses_incompatible_scm():
    with pytest.raises(ValueError,match='generated Hatch SCM'):
        audit_call({'binding':'DATA_ONLY_GENERATED_EVIDENCE'},'setuptools-scm')


def test_generated_evidence_still_requires_actual_hatch_scm_check():
    result,observed=audit_call({'binding':'DATA_ONLY_GENERATED_EVIDENCE'},'hatch-vcs')
    assert result['scm_checked'] is True
    assert observed==[True]
