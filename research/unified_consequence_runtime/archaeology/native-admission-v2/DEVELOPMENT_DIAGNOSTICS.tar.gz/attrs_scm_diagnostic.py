from diagnose import ROOT,phase
import os,shutil
root=ROOT/'task-1';venv=root/'venv-scm-standard';shutil.copytree(root/'venv',venv,symlinks=True)
# One generic declared version for source builds whose shallow history lacks tags;
# this is a diagnostic setup hypothesis, not a prospective authority change.
env={**os.environ,'SETUPTOOLS_SCM_PRETEND_VERSION':'0.0.0','PYTHONDONTWRITEBYTECODE':'1'}
phase('task-1/project-install-scm-standard',[venv/'bin/python','-m','pip','install','--no-input','--disable-pip-version-check','--no-deps','--no-build-isolation','--force-reinstall',root/'base'],env=env)
phase('task-1/pip-freeze-scm-standard',[venv/'bin/python','-m','pip','freeze','--all'])
for kind in ['base','augmented']:
 name=f'task-1/{kind}-execute-scm-standard';storage=ROOT/(name+'-state');storage.mkdir()
 env={**os.environ,'HOME':str(storage),'PATH':str(venv/'bin')+os.pathsep+os.environ.get('PATH','/usr/bin:/bin'),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONHASHSEED':'0','HYPOTHESIS_STORAGE_DIRECTORY':str(storage/'hypothesis'),'FAST':''}
 phase(name,[venv/'bin/python','-I','-B',ROOT/'runner.py',root/kind,ROOT/name],cwd=root/kind,env=env,timeout=600)
