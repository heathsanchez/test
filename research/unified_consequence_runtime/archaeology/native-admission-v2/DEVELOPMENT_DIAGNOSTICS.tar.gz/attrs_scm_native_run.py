from diagnose import ROOT,phase,h
import json,os,pathlib,shutil,sys
root=ROOT/'task-1';repo=root/'base-with-scm';wheelhouse=root/'native-wheels';wheelhouse.mkdir();venv=root/'venv-scm-native';shutil.copytree(root/'venv',venv,symlinks=True)
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
if 'SETUPTOOLS_SCM_PRETEND_VERSION' in env:raise RuntimeError('unexpected synthetic SCM environment')
phase('task-1/native-wheel-build',[venv/'bin/python','-m','pip','wheel','--no-input','--disable-pip-version-check','--no-deps','--no-build-isolation','--wheel-dir',wheelhouse,repo],env=env)
wheels=list(wheelhouse.glob('*.whl'));assert len(wheels)==1
wheel=wheels[0];(root/'native-wheel.json').write_text(json.dumps({'path':str(wheel),'sha256':h(wheel),'bytes':wheel.stat().st_size,'base_commit':'ab7f8b2f4c0f747d5b1575247ce35e5adaad182e','source_tree_preserved':True,'synthetic_version':False,'diagnostic_only':True},sort_keys=True,indent=2)+'\n')
phase('task-1/native-wheel-install',[venv/'bin/python','-m','pip','install','--no-input','--disable-pip-version-check','--no-deps','--force-reinstall',wheel],env=env)
phase('task-1/pip-freeze-scm-native',[venv/'bin/python','-m','pip','freeze','--all'])
phase('task-1/installed-version-scm-native',[venv/'bin/python','-I','-c','import importlib.metadata as m,json;print(json.dumps({d.metadata["Name"]:d.version for d in m.distributions()},sort_keys=True))'])
for kind,world in [('base',repo),('augmented',root/'augmented')]:
 name=f'task-1/{kind}-execute-scm-native';storage=ROOT/(name+'-state');storage.mkdir()
 env={**os.environ,'HOME':str(storage),'PATH':str(venv/'bin')+os.pathsep+os.environ.get('PATH','/usr/bin:/bin'),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONHASHSEED':'0','HYPOTHESIS_STORAGE_DIRECTORY':str(storage/'hypothesis'),'FAST':''}
 phase(name,[venv/'bin/python','-I','-B',ROOT/'runner.py',world,ROOT/name],cwd=world,env=env,timeout=600)
