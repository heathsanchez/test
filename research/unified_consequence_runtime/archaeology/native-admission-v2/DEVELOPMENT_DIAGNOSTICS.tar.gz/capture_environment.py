import hashlib,json,pathlib,sys
sys.path.insert(0,'/workspace/udm-v54')
from research.unified_consequence_runtime.decisive_native_verify import environment_identity
root=pathlib.Path('/workspace/qualification/admission-v2-environment')
for name,interpreter in [('generic',root/'venv/bin/python'),('task-0',root/'task-0/venv/bin/python'),('task-1-original-shallow',root/'task-1/venv/bin/python'),('task-1-native-scm',root/'task-1/venv-scm-native/bin/python'),('task-2',root/'task-2/venv/bin/python')]:
 identity=environment_identity(interpreter);p=root/(name+'-environment.json');p.write_text(json.dumps(identity,sort_keys=True,indent=2)+'\n');print(name,p,hashlib.sha256(p.read_bytes()).hexdigest())
