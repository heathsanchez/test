from diagnose import ROOT,phase,h
import json,os,pathlib,subprocess
root=ROOT/'task-2';source=pathlib.Path('/workspace/qualification/decisive-agent-comparator/task-2/source');bound=json.loads(source.parent.joinpath('source-boundaries.json').read_text());base=bound['base_commit'];repo=root/'base-with-scm';remote='https://github.com/python-attrs/cattrs.git'
phase('task-2/clone-base-with-scm',['git','clone','--local','--no-hardlinks','--no-checkout',source,repo])
phase('task-2/checkout-base-with-scm',['git','-C',repo,'checkout','--detach',base])
phase('task-2/scm-initial-tree',['git','-C',repo,'rev-parse',base+'^{tree}'])
fetch=phase('task-2/base-ancestry-fetch',['git','-C',repo,'fetch','--unshallow','--no-tags',remote,base],timeout=300)
if fetch['exit_code']!=0:raise SystemExit(1)
phase('task-2/base-ancestor-commits',['git','-C',repo,'rev-list',base])
phase('task-2/remote-tag-metadata',['git','ls-remote','--tags',remote])
ancestors=set((root/'base-ancestor-commits.log').read_text().splitlines());raw={}
for line in (root/'remote-tag-metadata.log').read_text().splitlines():
 sha,ref=line.split('\t');raw[ref]=sha
selected=[]
for ref,sha in raw.items():
 if ref.endswith('^{}'):continue
 target=raw.get(ref+'^{}',sha)
 if target in ancestors:selected.append({'ref':ref,'tag_object':sha,'target':target})
(root/'ancestor-tags-selected.json').write_text(json.dumps(selected,sort_keys=True,indent=2)+'\n')
# Fetch only independently proven ancestor-target tags, in one exact-ref request.
phase('task-2/ancestor-tags-fetch',['git','-C',repo,'fetch','--no-tags',remote,*[x['ref']+':'+x['ref'] for x in selected]],timeout=300)
phase('task-2/scm-described-version',['git','-C',repo,'describe','--tags','--long',base])
phase('task-2/scm-final-tree',['git','-C',repo,'rev-parse',base+'^{tree}'])
phase('task-2/scm-tracked-status',['git','-C',repo,'status','--porcelain=v1','--untracked-files=no'])
(root/'scm-provenance.json').write_text(json.dumps({'base_commit':base,'repository':remote,'head_production_fetched':False,'base_ancestry_only':True,'fetched_tags':selected,'initial_tree_log_sha256':h(root/'scm-initial-tree.log'),'final_tree_log_sha256':h(root/'scm-final-tree.log'),'raw_tree_unchanged':(root/'scm-initial-tree.log').read_bytes()==(root/'scm-final-tree.log').read_bytes(),'diagnostic_only':True},sort_keys=True,indent=2)+'\n')
