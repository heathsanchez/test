from diagnose import ROOT,phase
import concurrent.futures,os
root=ROOT/'task-2';venv=root/'venv-scm-native'
def run(kind):
 world=root/('base-with-scm' if kind=='base' else 'augmented');name=f'task-2/{kind}-execute-scm-native';storage=ROOT/(name+'-state');storage.mkdir()
 env={**os.environ,'HOME':str(storage),'PATH':str(venv/'bin')+os.pathsep+os.environ.get('PATH','/usr/bin:/bin'),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONHASHSEED':'0','HYPOTHESIS_STORAGE_DIRECTORY':str(storage/'hypothesis'),'FAST':''}
 phase(name,[venv/'bin/python','-I','-B',ROOT/'runner.py',world,ROOT/name],cwd=world,env=env,timeout=600)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(run,['base','augmented']))
