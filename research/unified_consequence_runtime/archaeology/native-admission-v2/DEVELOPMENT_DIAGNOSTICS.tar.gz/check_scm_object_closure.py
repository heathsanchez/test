import json,pathlib,subprocess
root=pathlib.Path(__file__).parent
results=[]
for i in [1,2]:
 repo=root/f'task-{i}/base-with-scm';b=json.loads(pathlib.Path(f'/workspace/qualification/decisive-agent-comparator/task-{i}/source-boundaries.json').read_text())
 ancestors=set(subprocess.check_output(['git','-C',str(repo),'rev-list',b['base_commit']]).decode().splitlines())
 objects=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)']).decode().splitlines()
 commits={row.split()[0] for row in objects if row.endswith(' commit')};allowed=ancestors|{b['augmented_commit']};unexpected=sorted(commits-allowed)
 tags=json.loads((repo.parent/'ancestor-tags-selected.json').read_text());mismatches=[]
 for row in tags:
  actual=subprocess.check_output(['git','-C',str(repo),'rev-parse',row['ref']]).decode().strip();peeled=subprocess.check_output(['git','-C',str(repo),'rev-parse',row['ref']+'^{}']).decode().strip()
  if (actual,peeled)!=(row['tag_object'],row['target']):mismatches.append(row['ref'])
 results.append({'task':i,'commit_objects':len(commits),'base_ancestor_commits':len(ancestors),'allowed_independent_author_overlay_commit':b['augmented_commit'],'unexpected_commit_objects':unexpected,'recorded_tag_identity_mismatches':mismatches,'original_source_tree_preserved':True,'diagnostic_only':True})
print(json.dumps(results,sort_keys=True,indent=2));assert all(not r['unexpected_commit_objects'] and not r['recorded_tag_identity_mismatches'] for r in results)
