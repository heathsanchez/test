from __future__ import annotations
import argparse, hashlib, json, os, pathlib, subprocess, sys, time
ROOT=pathlib.Path(__file__).parent.resolve()
def h(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def phase(name,argv,cwd=None,env=None,timeout=1200):
    stem=ROOT/name; stem.parent.mkdir(parents=True,exist_ok=True)
    if stem.with_suffix('.json').exists(): raise RuntimeError('refusing overwrite '+name)
    log=stem.with_suffix('.log'); started=time.monotonic()
    with log.open('wb') as stream:
      try:
        p=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
        code=p.returncode; timeout_hit=False
      except subprocess.TimeoutExpired:
        code=None;timeout_hit=True
    result={'name':name,'argv':[str(x) for x in argv],'cwd':str(cwd or pathlib.Path.cwd()),'seconds':time.monotonic()-started,'exit_code':code,'timed_out':timeout_hit,'horizon_seconds':timeout,'log':str(log),'log_sha256':h(log),'diagnostic_only':True}
    stem.with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--cwd');p.add_argument('--timeout',type=int,default=1200);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args();phase(a.name,a.argv[1:] if a.argv[:1]==['--'] else a.argv,cwd=a.cwd,timeout=a.timeout)
