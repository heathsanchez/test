import json,pathlib,sys,time
sys.path.insert(0,'/workspace/udm-v54')
from research.unified_consequence_runtime import native_execution_v2 as worker,native_admission_v2 as admission,decisive_native_verify as original
r=pathlib.Path('/workspace/qualification/admission-v2-environment');source=r/'task-0/augmented';bounds=json.loads(pathlib.Path('/workspace/qualification/decisive-agent-comparator/task-0/source-boundaries.json').read_text());policy=json.loads((r/'final-policy.json').read_text());interpreter=r/'task-0/venv/bin/python';identity=original.environment_identity(interpreter)
contract={'schema':worker.SCHEMA,'repository':'more-itertools/more-itertools','repo_path':str(source),'commit':bounds['augmented_commit'],**original.source_identity(source,bounds['augmented_commit']),'interpreter':str(interpreter),'environment_sha256':original.fingerprint(identity),'protocol_binding':'d'*64,'horizon_seconds':600}
authority=admission.derive_suite_contract(source,bounds['base_commit'],bounds['augmented_commit'],'d'*64,repository=contract['repository'])
started=time.monotonic()
try:
 certificate=worker.collect(contract,authority,r/'final-policy-task0-collect',policy=policy)
 receipt=worker.verify(contract,{'replacements':[]},r/'final-policy-task0-verify',authority=authority,admission_certificate=certificate,policy=policy)
 result={'diagnostic_only':True,'status':receipt['status'],'seconds':time.monotonic()-started,'receipt':receipt}
except Exception as e:result={'diagnostic_only':True,'status':'ERROR','error':repr(e),'seconds':time.monotonic()-started}
(r/'final-policy-probe.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='receipt'}))
