import json,pathlib,sys,time
sys.path.insert(0,'/workspace/udm-v54')
from research.unified_consequence_runtime import native_execution_v2 as worker,native_admission_v2 as admission,decisive_native_verify as original
r=pathlib.Path('/workspace/qualification/admission-v2-environment');source=r/'task-0/augmented';bounds=json.loads(pathlib.Path('/workspace/qualification/decisive-agent-comparator/task-0/source-boundaries.json').read_text());policy=json.loads((r/'final-policy.json').read_text());interpreter=r/'task-0/venv/bin/python';identity=original.environment_identity(interpreter)
contract={'schema':worker.SCHEMA,'repository':'more-itertools/more-itertools','repo_path':str(source),'commit':bounds['augmented_commit'],**original.source_identity(source,bounds['augmented_commit']),'interpreter':str(interpreter),'environment_sha256':original.fingerprint(identity),'protocol_binding':'d'*64,'horizon_seconds':600}
authority=admission.derive_suite_contract(source,bounds['base_commit'],bounds['augmented_commit'],'d'*64,repository=contract['repository']);candidate={'replacements':[]}
started=time.monotonic();stages={}
try:
 certificate=worker.collect(contract,authority,r/'final-policy-task0-collect-v3',policy=policy)
 stages['collection']={'status':certificate['status'],'nodes':len(certificate['collection']['collected_test_nodes']),'required_prefixes':len(authority['required_test_nodes']),'costs':certificate['costs']}
 receipt=worker.verify(contract,candidate,r/'final-policy-task0-verify-v3',authority=authority,admission_certificate=certificate,policy=policy)
 stages['verification']={'status':receipt['status'],'junit':receipt['junit'],'costs':receipt['costs'],'failed_nodes':[x['nodeid'] for x in receipt['execution']['reports'] if x['outcome']=='failed']}
 validated=worker.validate_receipt(contract,candidate,authority,certificate,receipt,policy=policy,output_dir=r/'final-policy-task0-independent-validation-v3')
 stages['independent_validation']={'status':validated['status'],'costs':validated['independent_reexecution']['costs']}
 (r/'final-policy-task0-validated-receipt-v3.json').write_text(json.dumps(validated,sort_keys=True,indent=2)+'\n')
 result={'diagnostic_only':True,'status':receipt['status'],'seconds':time.monotonic()-started,'stages':stages,'calls':{'collection_calls':certificate['costs']['collection_calls']+receipt['costs']['collection_calls']+validated['independent_reexecution']['costs']['collection_calls'],'native_calls':receipt['costs']['native_calls']+validated['independent_reexecution']['costs']['native_calls']},'policy_sha256':worker.fingerprint(policy),'worker_sha256':worker._runner_hash()}
except Exception as e:result={'diagnostic_only':True,'status':'ERROR','error':repr(e),'seconds':time.monotonic()-started,'stages':stages}
(r/'final-policy-probe-v3.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
