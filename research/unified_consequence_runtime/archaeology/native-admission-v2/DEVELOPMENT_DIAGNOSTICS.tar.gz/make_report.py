import collections,hashlib,json,pathlib,subprocess
r=pathlib.Path(__file__).parent.resolve()
chosen={0:'execute',1:'execute-scm-native',2:'execute-scm-native'}
modules={0:'tests/test_more.py',1:'tests/test_validators.py',2:'tests/test_tuples.py'}
report={'diagnostic_only':True,'prospective_acquisition_evidence':False,'policy_recommendation':{'collection_seconds':60,'execution_seconds':600,'pytest_version':'8.4.1','plugins':['hypothesis.extra.pytestplugin','pytest_benchmark.plugin','pytester'],'canonical_hypothesis_plugin_equivalent':'_hypothesis_pytestplugin','autoload':False,'hypothesis_overrides':None},'packages_file':'pip-freeze.log','direct_packages_file':'generic-direct-pins-v2.txt','source_status':{},'tasks':{},'negative_controls':'CONTROL_CLASSIFICATION.json'}
for i,mode in chosen.items():
 task={}
 for kind in ['base','augmented']:
  stem=r/f'task-{i}'/f'{kind}-{mode}';phase=json.loads(stem.with_suffix('.json').read_text());data=json.loads(stem.with_suffix('.monitor.json').read_text())
  task[kind]={'phase_receipt':str(stem.with_suffix('.json')),'monitor_receipt':str(stem.with_suffix('.monitor.json')),'exit_code':phase['exit_code'],'seconds':phase['seconds'],'collected':len(data['collected']),'protected_module':modules[i],'protected_module_count':sum(x.startswith(modules[i]+'::') for x in data['collected']),'outcomes':dict(collections.Counter(x['outcome'] for x in data['reports'] if x['when']=='call')),'failures':[x['nodeid'] for x in data['reports'] if x['outcome']=='failed'],'native_optional_outcomes':[{'nodeid':x['nodeid'],'when':x['when'],'wasxfail':x['wasxfail'],'longrepr':x['longrepr']} for x in data['reports'] if x['outcome']=='skipped'],'deselected':data['deselected'],'collection_errors':data['collection_reports'],'hypothesis':data['hypothesis']}
 report['tasks'][str(i)]=task
 source=pathlib.Path(f'/workspace/qualification/decisive-agent-comparator/task-{i}/source')
 original=json.loads((r/f'static/task-{i}/manifest.json').read_text());changes=[]
 for row in original:
  p=source/row['path']
  if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:changes.append(row['path'])
 report['source_status'][str(i)]={'original_tracked_files_changed':changes,'git_status':subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1','--untracked-files=all']).decode()}
for i in [1,2]:
 p=r/f'task-{i}/native-wheel.json';report['tasks'][str(i)]['native_wheel']=json.loads(p.read_text())
(r/'REPORT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
lines=['Native admission v2 environment diagnostics; development only, no prospective wins.','', 'Fixed common environment: CPython3.12.14, pytest8.4.1, Hypothesis6.151.9; complete38-distribution pin closure in pip-freeze.log.','Autoload disabled; explicitly loaded Hypothesis official wrapper, pytest_benchmark.plugin, builtin pytester.','Original config addopts retained; source profiles unchanged (attrs patience100/400ms, cattrs tests100/no deadline).','Full root discovery: more-itertools767->768; attrs1382->1383; cattrs1026->1027 including54bench cases.','Base/augmented production preserved; source-backed test overlay only; all exposed original tracked files unchanged.','']
for i,task in report['tasks'].items():
 for kind in ['base','augmented']:
  x=task[kind];lines.append(f'Task{i} {kind}: exit{x["exit_code"]}, {x["collected"]} collected, {x["seconds"]:.3f}s, call outcomes{x["outcomes"]}, protected module cases{x["protected_module_count"]}.')
  if x['failures']:lines.append('Protected failures: '+', '.join(x['failures']))
lines.extend(['','attrs native excludes8 cases on this environment (Python/platform5, missing optional pyright3) and has1 original expected xfail; forward-references module ignored before3.14. cattrs has15 source-authored expected xfails for parametrized include_subclasses-negative scenarios, no skips. No protected author assertions skipped or deselected.','All native optional outcomes require separate source-bound authority if a future worker otherwise forbids skips/xfails; native pytest exit0 itself grants no v2 admission.','Actual source-version metadata: attrs25.4.1.dev49 from25.4.0+49ancestor commits; cattrs26.1.1.dev2 from26.1.0+2. Wheels and ancestral Git receipts archived. No pretend version is qualified.','SCM diagnostic initial scripts fetched proven ancestral ref names then recorded metadata; production provisioner improves this to immutable tag-object OID fetch plus direct/peeled identity checks to close remote-tag races.','Original source archives here were preserved untouched. New provisioner emits raw tracked-byte tar with export-subst disabled; fixture proves literal Format bytes survive.','Longest native fullsuite217.367s; independently freezing60s collection/600s execution gives2.76x execution headroom. Fixed bounds are new v2 authority; old7s verifier unchanged.','All failed dependency/setup/control attempts, logs, statuses, wall costs, source manifests, wheels and digests remain available.'])
(r/'REPORT.txt').write_text('\n'.join(lines)+'\n')
