import base64,hashlib,json,pathlib,subprocess,sys
from unittest.mock import patch
sys.path.insert(0,'/workspace/udm-v54')
from research.unified_consequence_runtime import native_environment_v2 as env
r=pathlib.Path('/workspace/qualification/admission-v2-environment/provisioner-fixture-v2');r.mkdir();source=r/'original';source.mkdir()
def git(*args):return subprocess.check_output(['git','-C',str(source),*args],stderr=subprocess.PIPE).decode().strip()
git('init','-q');(source/'subject').mkdir();(source/'subject/__init__.py').write_text('def value():\n    return 0\n')
(source/'test_subject.py').write_text('from subject import value\ndef test_value():\n    assert value() == 0\n')
(source/'pyproject.toml').write_text('[build-system]\nrequires=["flit_core>=4,<5"]\nbuild-backend="flit_core.buildapi"\n[project]\nname="fixture-subject"\nversion="1.0.0"\ndescription="offline native environment fixture"\n[tool.flit.module]\nname="subject"\n')
(source/'stamp.txt').write_text('$Format:%H$\n');(source/'.gitattributes').write_text('stamp.txt export-subst\n')
git('add','.');git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-qm','base');base=git('rev-parse','HEAD')
author=b'from subject import value\ndef test_value():\n    assert value() == 1\n'
original_command=env._command
calls=[]
def command(argv,out,**kwargs):
 args=[str(x) for x in argv];calls.append(args)
 if args[:2]==['gh','api']:
  packet={'path':'test_subject.py','type':'file','encoding':'base64','content':base64.b64encode(author).decode(),'sha':hashlib.sha1(b'blob '+str(len(author)).encode()+b'\0'+author).hexdigest(),'size':len(author)}
  pathlib.Path(out).write_text(json.dumps(packet)+'\n');return {'status':'PASS','exit_code':0,'seconds':0,'log':str(out),'log_sha256':hashlib.sha256(pathlib.Path(out).read_bytes()).hexdigest()}
 args=[str(source) if x=='https://github.com/fixture/source.git' else x for x in args]
 return original_command(args,out,**kwargs)
pins=pathlib.Path('/workspace/qualification/admission-v2-environment/pip-freeze.log').read_text().splitlines()
policy={'schema':'UDM_NATIVE_EXECUTION_POLICY_V2','collection_seconds':60,'execution_seconds':600,'pytest_version':'8.4.1','plugins':[]}
spec={'repo':'fixture/source','base_commit':base,'head_commit':'b'*40,'files':[{'filename':'test_subject.py','status':'modified'}]}
with patch.object(env,'_command',side_effect=command):result=env.provision(spec,r/'prepared','c'*64,policy=policy,packages=pins)
(r/'fixture-command-requests.json').write_text(json.dumps(calls,indent=2)+'\n')
print(json.dumps({'status':result['status'],'reason':result.get('reason'),'seconds':result['total_wall_seconds'],'contract':result['contract']},sort_keys=True))
assert result['status']=='PREPARED',result.get('reason')
assert all('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb' not in x for a in calls if a and a[0]=='git' for x in a)
assert result['source_boundaries']['production_preserved']
