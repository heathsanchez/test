from diagnose import ROOT,phase
import concurrent.futures,json,os,pathlib,shutil,sys

def task(i):
 root=ROOT/f'task-{i}';venv=root/'venv';shutil.copytree(ROOT/'venv',venv,symlinks=True)
 result=phase(f'task-{i}/project-install',[venv/'bin/python','-m','pip','install','--disable-pip-version-check','--no-input','--no-deps','--no-build-isolation',root/'base'])
 phase(f'task-{i}/pip-freeze',[venv/'bin/python','-m','pip','freeze','--all'])
 if result['exit_code']!=0:return
 for kind in ['base','augmented']:
  world=root/kind
  for mode in ['collect','execute']:
   name=f'task-{i}/{kind}-{mode}';out=ROOT/name
   storage=ROOT/f'{name}-state';storage.mkdir()
   env={**os.environ,'HOME':str(storage),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONHASHSEED':'0','HYPOTHESIS_STORAGE_DIRECTORY':str(storage/'hypothesis'),'FAST':''}
   phase(name,[venv/'bin/python','-I','-B',ROOT/'runner.py',world,out,*(['--collect-only'] if mode=='collect' else [])],cwd=world,env=env,timeout=600 if mode=='execute' else 60)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(task,range(3)))
