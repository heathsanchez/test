import hashlib,importlib.metadata as md,json,pathlib,sys
world=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve()
import pytest
sys.path[:0]=[str(world/'src'),str(world)]
class Monitor:
 def __init__(self):self.reports=[];self.deselected=[];self.collected=[];self.collection_reports=[];self.plugins=[]
 def pytest_collection_finish(self,session):self.collected=[x.nodeid for x in session.items]
 def pytest_collectreport(self,report):
  if report.outcome!='passed':self.collection_reports.append({'nodeid':report.nodeid,'outcome':report.outcome,'longrepr':str(report.longrepr)})
 def pytest_runtest_logreport(self,report):
  self.reports.append({'nodeid':report.nodeid,'when':report.when,'outcome':report.outcome,'duration':report.duration,'longrepr':str(report.longrepr) if report.outcome!='passed' else None,'wasxfail':getattr(report,'wasxfail',None)})
 def pytest_deselected(self,items):self.deselected.extend(x.nodeid for x in items)
 def pytest_sessionfinish(self,session):self.plugins=[{'name':str(n),'path':str(getattr(p,'__file__',None))} for n,p in session.config.pluginmanager.list_name_plugin()]
monitor=Monitor()
args=['-q','-p','no:cacheprovider','-p','hypothesis.extra.pytestplugin','-p','pytest_benchmark.plugin','-p','pytester','--junitxml='+str(out)+'.xml',*sys.argv[3:]]
code=pytest.main(args,plugins=[monitor])
imports=[]
for name,module in sorted(tuple(sys.modules.items())):
 location=getattr(module,'__file__',None)
 if location and isinstance(location,str):
  path=pathlib.Path(location).resolve()
  if path.is_file() and (path.is_relative_to(world) or name.split('.')[0] in {'attr','attrs','cattr','cattrs','more_itertools','pytest','hypothesis','pytest_benchmark'}):
   imports.append({'module':name,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
try:
 from hypothesis import settings
 hypothesis={'profile':settings.get_current_profile_name(),'max_examples':settings.default.max_examples,'deadline':str(settings.default.deadline)}
except Exception as e:hypothesis={'error':str(e)}
value={'exit_code':int(code),'pytest_args':args,'collected':monitor.collected,'reports':monitor.reports,'deselected':monitor.deselected,'collection_reports':monitor.collection_reports,'plugins':monitor.plugins,'imports':imports,'hypothesis':hypothesis,'versions':{n:md.version(n) for n in ['pytest','hypothesis','pytest-benchmark','pytest-xdist']},'diagnostic_only':True}
out.with_suffix('.monitor.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
raise SystemExit(code)
