from diagnose import ROOT,phase
import json,os,pathlib,subprocess
for i in range(3):
 source=pathlib.Path(f'/workspace/qualification/decisive-agent-comparator/task-{i}/source')
 b=json.loads(source.parent.joinpath('source-boundaries.json').read_text())
 for kind,commit in [('base',b['base_commit']),('augmented',b['augmented_commit'])]:
  world=ROOT/f'task-{i}'/kind
  phase(f'task-{i}/clone-{kind}',['git','clone','--local','--no-hardlinks','--no-checkout',source,world])
  phase(f'task-{i}/checkout-{kind}',['git','-C',world,'checkout','--detach',commit])
phase('pip-freeze',[ROOT/'venv/bin/python','-m','pip','freeze','--all'])
