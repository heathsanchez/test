import hashlib,json,marshal,sys,types

def untouched_test():
    return 'A literal containing spaces @ punctuation, not an identifier.'

code=untouched_test.__code__
def current_hash(c):
 def clean(x):
  consts=tuple(clean(v) if isinstance(v,types.CodeType) else v for v in x.co_consts)
  return x.replace(co_filename='constant-fixture-path.py',co_consts=consts)
 return hashlib.sha256(marshal.dumps(clean(c))).hexdigest()
before=current_hash(code);literal=code.co_consts[1];interned=sys.intern(literal);after=current_hash(code)
print(json.dumps({'diagnostic_only':True,'pytest_calls':0,'native_calls':0,'same_code_object':code is untouched_test.__code__,'same_literal_object':literal is interned,'bytecode_sha256':hashlib.sha256(code.co_code).hexdigest(),'hash_before':before,'hash_after':after,'current_serializer_reports_changed':before!=after},sort_keys=True))
