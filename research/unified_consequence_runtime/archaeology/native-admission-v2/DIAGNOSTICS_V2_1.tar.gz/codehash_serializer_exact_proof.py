import hashlib,json,marshal,struct,sys,types
FIELDS=('co_argcount','co_posonlyargcount','co_kwonlyargcount','co_nlocals','co_stacksize','co_flags','co_code','co_consts','co_names','co_varnames','co_filename','co_name','co_qualname','co_firstlineno','co_linetable','co_exceptiontable','co_freevars','co_cellvars','co_lnotab')
def value(x):
 if isinstance(x,types.CodeType):return ['code',[[k,value(getattr(x,k))] for k in FIELDS]]
 if isinstance(x,tuple):return ['tuple',[value(v) for v in x]]
 if isinstance(x,frozenset):return ['frozenset',sorted((value(v) for v in x),key=lambda v:json.dumps(v,sort_keys=True))]
 if isinstance(x,bytes):return ['bytes',x.hex()]
 if isinstance(x,float):return ['float',struct.pack('!d',x).hex()]
 if isinstance(x,complex):return ['complex',struct.pack('!dd',x.real,x.imag).hex()]
 if x is Ellipsis:return ['ellipsis']
 if x is None:return ['none']
 if type(x) in (bool,int,str):return [type(x).__name__,x]
 raise TypeError(type(x).__name__)
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def serialized(c):
 def clean(x):return x.replace(co_filename='constant-fixture-path.py',co_consts=tuple(clean(v) if isinstance(v,types.CodeType) else v for v in x.co_consts))
 return marshal.dumps(clean(c))
def untouched_test():
 return 'A literal containing spaces @ punctuation, not an identifier.'
code=untouched_test.__code__;literal=code.co_consts[1];before_fields=value(code);before=serialized(code);before_again=serialized(code)
interned=sys.intern(literal);after=serialized(code);after_again=serialized(code);after_fields=value(code)
changed_offsets=[{'offset':i,'before':a,'after':b} for i,(a,b) in enumerate(zip(before,after)) if a!=b]
result={'diagnostic_only':True,'pytest_calls':0,'native_calls':0,'same_code_object':code is untouched_test.__code__,'same_literal_object':literal is interned,'all_public_code_data_fields_equal':before_fields==after_fields,'field_names':list(FIELDS),'structural_fields_hash_before':digest(before_fields),'structural_fields_hash_after':digest(after_fields),'marshal_hash_before':hashlib.sha256(before).hexdigest(),'marshal_hash_after':hashlib.sha256(after).hexdigest(),'marshal_stable_before_intern':before==before_again,'marshal_stable_after_intern':after==after_again,'marshal_length_before':len(before),'marshal_length_after':len(after),'different_byte_offsets':changed_offsets}
print(json.dumps(result,sort_keys=True,indent=2));assert before_fields==after_fields and before!=after and code is untouched_test.__code__ and literal is interned
