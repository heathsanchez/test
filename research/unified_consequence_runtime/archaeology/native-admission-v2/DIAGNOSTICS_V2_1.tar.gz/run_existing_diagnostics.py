from __future__ import annotations
import concurrent.futures,hashlib,json,pathlib,sys,time,traceback
sys.path.insert(0,'/workspace/udm-v54')
from research.unified_consequence_runtime import native_execution_v2 as worker,native_admission_v2 as admission,decisive_native_verify as original
ROOT=pathlib.Path(__file__).parent.resolve();EXISTING=pathlib.Path('/workspace/qualification/admission-v2-environment')
POLICY=json.loads((EXISTING/'final-policy.json').read_text());CANDIDATE={'replacements':[]}
assert worker.ADMISSION_REVISION=='2.1'
WORKER_SHA=worker._runner_hash();POLICY_SHA=worker.fingerprint(POLICY)
(ROOT/'policy.json').write_text(json.dumps(POLICY,sort_keys=True,indent=2)+'\n')
(ROOT/'source-binding.json').write_text(json.dumps({'worker_admission_revision':worker.ADMISSION_REVISION,'worker_sha256':WORKER_SHA,'ast_sha256':original.sha256(pathlib.Path(admission.__file__).read_bytes()),'policy_sha256':POLICY_SHA,'diagnostic_only':True,'new_future_tasks_inspected':False,'committed_original_bundle_modified':False},sort_keys=True,indent=2)+'\n')

def save(path,data):path.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')

def prepare(i):
 started=time.monotonic();root=ROOT/f'task-{i}';root.mkdir();source=EXISTING/f'task-{i}/augmented';bounds=json.loads(pathlib.Path(f'/workspace/qualification/decisive-agent-comparator/task-{i}/source-boundaries.json').read_text());interpreter=EXISTING/f'task-{i}/venv-scm-native/bin/python';environment=original.environment_identity(interpreter);repository=bounds['repository']
 contract={'schema':worker.SCHEMA,'repository':repository,'repo_path':str(source),'commit':bounds['augmented_commit'],**original.source_identity(source,bounds['augmented_commit']),'interpreter':str(interpreter),'environment_sha256':original.fingerprint(environment),'protocol_binding':'e'*64,'horizon_seconds':POLICY['execution_seconds']}
 authority=admission.derive_suite_contract(source,bounds['base_commit'],bounds['augmented_commit'],'e'*64,repository=repository)
 save(root/'contract.json',contract);save(root/'authority.json',authority);save(root/'environment.json',environment)
 certificate=worker.collect(contract,authority,root/'collection',policy=POLICY)
 collected=certificate['collection']['collected_test_nodes'];selected=certificate['collection']['selected_test_nodes'];assert len(collected)==len(selected) and set(collected)==set(selected)
 summary={'task':i,'repository':repository,'diagnostic_only':True,'collection_status':certificate['status'],'collected_count':len(collected),'selected_count':len(selected),'same_node_set':set(collected)==set(selected),'same_sequence':collected==selected,'reordered_positions':sum(a!=b for a,b in zip(collected,selected)),'benchmark_cases':sum(n.startswith('bench/') for n in selected),'collection_costs':certificate['costs'],'prepare_wall_seconds':time.monotonic()-started,'worker_sha256':WORKER_SHA,'policy_sha256':POLICY_SHA,'admission_revision':worker.ADMISSION_REVISION}
 save(root/'collection-summary.json',summary);print(json.dumps(summary,sort_keys=True),flush=True)
 return i,root,contract,authority,certificate,summary

def execute(prepared):
 i,root,contract,authority,certificate,summary=prepared;started=time.monotonic()
 receipt=worker.verify(contract,CANDIDATE,root/'verification',authority=authority,admission_certificate=certificate,policy=POLICY)
 worker.validate_receipt(contract,CANDIDATE,authority,certificate,receipt,policy=POLICY,independent=False)
 reports=receipt['execution']['reports'];selected=certificate['collection']['selected_test_nodes'];calls=[r for r in reports if r['when']=='call'];failures=[r['nodeid'] for r in calls if r['outcome']=='failed'];skips=[r for r in reports if r['outcome']=='skipped'];xfails=[r for r in reports if r['wasxfail']]
 expected='tests/test_validators.py::TestDisableValidators::test_disabled_ctx_nested' if i==1 else 'tests/test_tuples.py::test_dict_namedtuples_detailed_validation'
 summary.update({'status':receipt['status'],'junit':receipt['junit'],'failure_nodes':failures,'sole_protected_failure':failures==[expected],'selected_sequence_preserved':receipt['execution']['selected_test_nodes']==selected,'collected_sequence_preserved':receipt['execution']['collected_test_nodes']==certificate['collection']['collected_test_nodes'],'native_skipped_reports':len(skips),'native_xfail_reports':len(xfails),'deselected_nodes':receipt['execution']['deselected_test_nodes'],'source_mutations':receipt['execution']['source_mutations'],'plugin_violations':receipt['execution']['plugin_violations'],'execution_costs':receipt['costs'],'execution_envelope_seconds':time.monotonic()-started,'case_outcomes':{'native_skip_or_xfail':[{'nodeid':r['nodeid'],'when':r['when'],'wasxfail':r['wasxfail']} for r in reports if r['outcome']=='skipped' or r['wasxfail']]},'receipt_validation':'STRUCTURAL_TRUSTED_RUNNER_PACKET_VALIDATED','independent_native_repeat':False})
 save(root/'SUMMARY.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='case_outcomes'},sort_keys=True),flush=True)
 assert receipt['status']=='UNKNOWN_SKIPPED_OR_XFAIL',receipt['status'];assert summary['sole_protected_failure'];assert not summary['source_mutations'] and not summary['plugin_violations'] and not summary['deselected_nodes']
 return summary

def guarded(fn,*args):
 try:return fn(*args)
 except Exception as error:
  failure={'status':'ERROR','error':repr(error),'traceback':traceback.format_exc(),'diagnostic_only':True};print(json.dumps(failure),flush=True);save(ROOT/(f'error-{time.monotonic_ns()}.json'),failure);raise

started=time.monotonic()
attrs=guarded(prepare,1)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 attrs_future=pool.submit(guarded,execute,attrs)
 def cattrs():return guarded(execute,guarded(prepare,2))
 cattrs_future=pool.submit(cattrs)
 results=[attrs_future.result(),cattrs_future.result()]
summary={'schema':'UDM_NATIVE_ADMISSION_REVISION_2_1_DEVELOPMENT_DIAGNOSTICS','diagnostic_only':True,'three_exposed_original_diagnostics_only':True,'tasks':results,'costs':{'collection_calls':sum(1+x['execution_costs']['collection_calls'] for x in results),'native_calls':sum(x['execution_costs']['native_calls'] for x in results),'wall_seconds':time.monotonic()-started},'worker_sha256':WORKER_SHA,'policy_sha256':POLICY_SHA,'source_binding':'source-binding.json','original_bundle_modified':False}
save(ROOT/'SUMMARY.json',summary);print(json.dumps({'complete':True,'costs':summary['costs'],'statuses':[x['status'] for x in results]},sort_keys=True),flush=True)
