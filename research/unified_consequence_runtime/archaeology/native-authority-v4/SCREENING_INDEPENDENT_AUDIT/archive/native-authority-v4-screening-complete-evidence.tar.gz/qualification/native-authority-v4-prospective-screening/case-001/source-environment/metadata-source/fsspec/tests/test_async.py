import asyncio
import inspect
import io
import os
import subprocess
import sys
import textwrap
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import pytest

import fsspec
import fsspec.asyn
from fsspec.asyn import _run_coros_in_chunks


def test_get_lock_is_thread_safe(monkeypatch):
    barrier = threading.Barrier(2)
    real_threading = fsspec.asyn.threading

    def make_lock():
        candidate = threading.Lock()
        barrier.wait()
        return candidate

    fsspec.asyn.reset_lock()
    try:
        monkeypatch.setattr(fsspec.asyn, "threading", SimpleNamespace(Lock=make_lock))
        with ThreadPoolExecutor(max_workers=2) as executor:
            locks = list(executor.map(lambda _: fsspec.asyn.get_lock(), range(2)))
    finally:
        monkeypatch.setattr(fsspec.asyn, "threading", real_threading)
        fsspec.asyn.reset_lock()

    assert locks[0] is locks[1]


@pytest.mark.parametrize("finalizing", [False, True])
def test_sync_stopped_io_thread(monkeypatch, finalizing):
    stopped_loop = asyncio.new_event_loop()
    try:
        monkeypatch.setattr(fsspec.asyn, "loop", [stopped_loop])
        monkeypatch.setattr(
            fsspec.asyn, "iothread", [SimpleNamespace(is_alive=lambda: False)]
        )
        monkeypatch.setattr(fsspec.asyn.sys, "is_finalizing", lambda: finalizing)

        def must_not_create_coroutine():
            pytest.fail("sync attempted to schedule work on a stopped IO thread")

        with pytest.raises(RuntimeError, match="IO thread has already stopped"):
            fsspec.asyn.sync(stopped_loop, must_not_create_coroutine)
    finally:
        stopped_loop.close()


def test_sync_supplied_loop_on_stopped_io_thread(monkeypatch):
    supplied_loop = asyncio.new_event_loop()
    try:
        monkeypatch.setattr(fsspec.asyn, "loop", [object()])
        monkeypatch.setattr(
            fsspec.asyn,
            "iothread",
            [SimpleNamespace(is_alive=lambda: False, ident=424242)],
        )
        # the supplied loop was being run by the fsspec IO thread
        supplied_loop._thread_id = 424242

        def must_not_create_coroutine():
            pytest.fail("sync attempted to schedule work on a stopped IO thread")

        with pytest.raises(RuntimeError, match="IO thread has already stopped"):
            fsspec.asyn.sync(supplied_loop, must_not_create_coroutine)
    finally:
        supplied_loop._thread_id = None
        supplied_loop.close()


@pytest.mark.parametrize("finalizing", [False, True])
def test_sync_custom_loop_ignores_stopped_io_thread(monkeypatch, finalizing):
    custom_loop = asyncio.new_event_loop()
    thread = threading.Thread(target=custom_loop.run_forever)
    thread.start()
    try:
        monkeypatch.setattr(fsspec.asyn, "loop", [object()])
        monkeypatch.setattr(
            fsspec.asyn,
            "iothread",
            [SimpleNamespace(is_alive=lambda: False, ident=12345)],
        )
        monkeypatch.setattr(fsspec.asyn.sys, "is_finalizing", lambda: finalizing)

        async def work():
            return 42

        assert fsspec.asyn.sync(custom_loop, work, timeout=1) == 42
    finally:
        custom_loop.call_soon_threadsafe(custom_loop.stop)
        thread.join(timeout=5)
        custom_loop.close()


@pytest.mark.parametrize("finalizing", [False, True])
def test_sync_live_io_thread(monkeypatch, finalizing):
    live_loop = fsspec.asyn.get_loop()
    monkeypatch.setattr(fsspec.asyn.sys, "is_finalizing", lambda: finalizing)

    async def work():
        return 42

    assert fsspec.asyn.sync(live_loop, work, timeout=1) == 42


def _run_python(script, **kwargs):
    env = {**os.environ, "PYTHONPATH": os.pathsep.join(sys.path)}
    return subprocess.Popen(
        [sys.executable, "-c", textwrap.dedent(script)], env=env, **kwargs
    )


def test_io_loop_stopped_before_interpreter_shutdown():
    script = """
        import atexit
        import sys

        # Registered before fsspec is imported, so it runs after fsspec's hook.
        def report():
            print("alive", sys.modules["fsspec.asyn"].iothread[0].is_alive())

        atexit.register(report)

        import fsspec.asyn

        fsspec.asyn.get_loop()
    """
    proc = _run_python(script, stdout=subprocess.PIPE, text=True)
    out, _ = proc.communicate(timeout=60)
    assert proc.returncode == 0
    assert out.strip() == "alive False"


def test_io_loop_blocked_at_exit_warns_and_waits():
    script = """
        import atexit
        import sys
        import threading
        import time

        # Registered before fsspec is imported, so it runs after fsspec's hook.
        def report():
            print("alive", sys.modules["fsspec.asyn"].iothread[0].is_alive())

        atexit.register(report)

        import fsspec.asyn

        fsspec.asyn._STOP_IO_LOOP_WARN_SECONDS = 0.2
        loop = fsspec.asyn.get_loop()
        blocking = threading.Event()

        def block():
            blocking.set()
            time.sleep(1)

        loop.call_soon_threadsafe(block)
        blocking.wait(10)
    """
    proc = _run_python(
        script, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    out, err = proc.communicate(timeout=60)
    assert proc.returncode == 0
    assert "fsspec IO loop is still running" in err
    assert out.strip() == "alive False"


@pytest.mark.skipif(sys.platform == "win32", reason="uses __cxa_atexit")
def test_late_uvloop_timer_does_not_crash_at_exit():
    pytest.importorskip("uvloop")
    # A C exit handler blocked in getchar() holds the process after
    # Py_Finalize; a timer on a still-running uvloop IO loop firing there
    # re-enters the finalized interpreter and segfaults (#2241).
    script = """
        import asyncio
        import ctypes
        import threading

        import uvloop

        import fsspec.asyn

        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        loop = fsspec.asyn.get_loop()
        process = ctypes.CDLL(None)
        process.__cxa_atexit(process.getchar, None, None)
        armed = threading.Event()

        def arm():
            loop.call_later(0.3, lambda: None)
            armed.set()

        loop.call_soon_threadsafe(arm)
        armed.wait(10)
        print("exiting", flush=True)
    """
    proc = _run_python(script, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    assert proc.stdout.readline() == b"exiting\n"
    time.sleep(1.5)  # well past the timer
    try:
        proc.stdin.write(b"\n")
        proc.stdin.close()
    except BrokenPipeError:
        pass  # the child already crashed
    assert proc.wait(timeout=60) == 0


def test_sync_methods():
    inst = fsspec.asyn.AsyncFileSystem()
    assert inspect.iscoroutinefunction(inst._info)
    assert hasattr(inst, "info")
    assert inst.info.__qualname__ == "AsyncFileSystem._info"
    assert not inspect.iscoroutinefunction(inst.info)


def test_async_gen():
    inst = fsspec.asyn.AsyncFileSystem()
    assert inst.walk is not fsspec.AbstractFileSystem.walk
    gen = inst.walk("path")  # does not raise yet
    with pytest.raises(NotImplementedError):
        list(gen)


def test_when_sync_methods_are_disabled():
    class TestFS(fsspec.asyn.AsyncFileSystem):
        mirror_sync_methods = False

    inst = TestFS()
    assert inspect.iscoroutinefunction(inst._info)
    assert not inspect.iscoroutinefunction(inst.info)
    assert inst.info.__qualname__ == "AbstractFileSystem.info"


def test_interrupt():
    loop = fsspec.asyn.get_loop()

    async def f():
        await asyncio.sleep(1000000)
        return True

    fut = asyncio.run_coroutine_threadsafe(f(), loop)
    time.sleep(0.01)  # task launches
    out = fsspec.asyn._dump_running_tasks(with_task=True)
    task = out[0]["task"]
    assert task.done() and fut.done()
    assert isinstance(fut.exception(), fsspec.asyn.FSSpecCoroutineCancel)


class _DummyAsyncKlass:
    def __init__(self):
        self.loop = fsspec.asyn.get_loop()

    async def _dummy_async_func(self):
        # Sleep 1 second function to test timeout
        await asyncio.sleep(1)
        return True

    async def _bad_multiple_sync(self):
        fsspec.asyn.sync_wrapper(_DummyAsyncKlass._dummy_async_func)(self)
        return True

    dummy_func = fsspec.asyn.sync_wrapper(_dummy_async_func)
    bad_multiple_sync_func = fsspec.asyn.sync_wrapper(_bad_multiple_sync)


def test_sync_wrapper_timeout_on_less_than_expected_wait_time_not_finish_function():
    test_obj = _DummyAsyncKlass()
    with pytest.raises(fsspec.FSTimeoutError):
        test_obj.dummy_func(timeout=0.1)


def test_sync_wrapper_timeout_on_more_than_expected_wait_time_will_finish_function():
    test_obj = _DummyAsyncKlass()
    assert test_obj.dummy_func(timeout=5)


def test_sync_wrapper_timeout_none_will_wait_func_finished():
    test_obj = _DummyAsyncKlass()
    assert test_obj.dummy_func(timeout=None)


def test_sync_wrapper_treat_timeout_0_as_none():
    test_obj = _DummyAsyncKlass()
    assert test_obj.dummy_func(timeout=0)


def test_sync_wrapper_bad_multiple_sync():
    test_obj = _DummyAsyncKlass()
    with pytest.raises(NotImplementedError):
        test_obj.bad_multiple_sync_func(timeout=5)


def test_run_coros_in_chunks(monkeypatch):
    total_running = 0

    async def runner():
        nonlocal total_running

        total_running += 1
        await asyncio.sleep(0)
        if total_running > 4:
            raise ValueError("More than 4 coroutines are running together")
        total_running -= 1
        return 1

    async def main(**kwargs):
        nonlocal total_running

        total_running = 0
        coros = [runner() for _ in range(32)]
        results = await _run_coros_in_chunks(coros, **kwargs)
        for result in results:
            if isinstance(result, Exception):
                raise result
        return results

    assert sum(asyncio.run(main(batch_size=4))) == 32

    with pytest.raises(ValueError):
        asyncio.run(main(batch_size=5))

    with pytest.raises(ValueError):
        asyncio.run(main(batch_size=-1))

    assert sum(asyncio.run(main(batch_size=4))) == 32

    monkeypatch.setitem(fsspec.config.conf, "gather_batch_size", 5)
    with pytest.raises(ValueError):
        asyncio.run(main())
    assert sum(asyncio.run(main(batch_size=4))) == 32  # override

    monkeypatch.setitem(fsspec.config.conf, "gather_batch_size", 4)
    assert sum(asyncio.run(main())) == 32  # override


def test_running_async():
    assert not fsspec.asyn.running_async()

    async def go():
        assert fsspec.asyn.running_async()

    asyncio.run(go())


class DummyAsyncFS(fsspec.asyn.AsyncFileSystem):
    _file_class = fsspec.asyn.AbstractAsyncStreamedFile

    async def _info(self, path, **kwargs):
        return {"name": "misc/foo.txt", "type": "file", "size": 100}

    async def open_async(
        self,
        path,
        mode="rb",
        block_size=None,
        autocommit=True,
        cache_options=None,
        **kwargs,
    ):
        return DummyAsyncStreamedFile(
            self,
            path,
            mode,
            block_size,
            autocommit,
            cache_options=cache_options,
            **kwargs,
        )


class DummyAsyncStreamedFile(fsspec.asyn.AbstractAsyncStreamedFile):
    def __init__(self, fs, path, mode, block_size, autocommit, **kwargs):
        super().__init__(fs, path, mode, block_size, autocommit, **kwargs)
        self.temp_buffer = io.BytesIO(b"foo-bar" * 20)

    async def _fetch_range(self, start, end):
        return self.temp_buffer.read(end - start)

    async def _initiate_upload(self):
        # Reinitialize for new uploads.
        self.temp_buffer = io.BytesIO()

    async def _upload_chunk(self, final=False):
        self.temp_buffer.write(self.buffer.getbuffer())

    async def get_data(self):
        return self.temp_buffer.getbuffer().tobytes()


@pytest.mark.asyncio
async def test_async_streamed_file_write():
    test_fs = DummyAsyncFS()
    streamed_file = await test_fs.open_async("misc/foo.txt", mode="wb")
    inp_data = b"foo-bar" * streamed_file.blocksize * 2
    await streamed_file.write(inp_data)
    assert streamed_file.loc == len(inp_data)
    await streamed_file.close()
    out_data = await streamed_file.get_data()
    assert out_data.count(b"foo-bar") == streamed_file.blocksize * 2


@pytest.mark.asyncio
async def test_async_streamed_file_read():
    test_fs = DummyAsyncFS()
    streamed_file = await test_fs.open_async("misc/foo.txt", mode="rb")
    assert (
        await streamed_file.read(7 * 3) + await streamed_file.read(7 * 18)
        == b"foo-bar" * 20
    )
    await streamed_file.close()


def test_rm_file_with_rm_implementation():
    class AsyncFSWithRm(fsspec.asyn.AsyncFileSystem):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.removed_paths = []

        async def _rm(self, path, recursive=False, batch_size=None, **kwargs):
            if isinstance(path, str):
                path = [path]
            for p in path:
                self.removed_paths.append(p)
            return None

    fs = AsyncFSWithRm()
    fs.rm_file("test/file.txt")
    assert "test/file.txt" in fs.removed_paths


def test_rm_file_with_rm_file_implementation():
    class AsyncFSWithRmFile(fsspec.asyn.AsyncFileSystem):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.removed_paths = []

        async def _rm_file(self, path, **kwargs):
            self.removed_paths.append(path)
            return None

    fs = AsyncFSWithRmFile()
    fs.rm_file("test/file.txt")
    assert "test/file.txt" in fs.removed_paths


def test_rm_file_without_implementation():
    fs = fsspec.asyn.AsyncFileSystem()
    with pytest.raises(NotImplementedError):
        fs.rm_file("test/file.txt")


class _MaxDepthFS(fsspec.asyn.AsyncFileSystem):
    # Mirrors the gcsfs/s3fs pattern: implements the primitives, inherits _rm.
    def __init__(self, files, **kwargs):
        super().__init__(**kwargs)
        self.files = set(files)
        self.removed_paths = []

    async def _ls(self, path, detail=True, **kwargs):
        path = path.rstrip("/")
        kids = {}
        for f in self.files:
            if not f.startswith(path + "/"):
                continue
            head = f[len(path) + 1 :].split("/")[0]
            full = f"{path}/{head}"
            kids[full] = {
                "name": full,
                "size": 0,
                "type": "file" if full in self.files else "directory",
            }
        return list(kids.values()) if detail else sorted(kids)

    async def _info(self, path, **kwargs):
        path = path.rstrip("/")
        typ = "file" if path in self.files else "directory"
        return {"name": path, "size": 0, "type": typ}

    async def _rm_file(self, path, **kwargs):
        self.removed_paths.append(path)
        self.files.discard(path)


def test_rm_honours_maxdepth():
    tree = ["/root/a.txt", "/root/d1/b.txt", "/root/d1/d2/c.txt"]
    fs = _MaxDepthFS(tree)
    fs.rm("/root", recursive=True, maxdepth=1)
    assert "/root/d1/b.txt" not in fs.removed_paths
    assert "/root/d1/d2/c.txt" not in fs.removed_paths


class _CatRangesFS(fsspec.asyn.AsyncFileSystem):
    # Mirrors the gcsfs/s3fs pattern: overrides _cat_file, inherits _cat_ranges.
    cachable = False
    store = {"ok": b"0123456789"}

    async def _cat_file(self, path, start=None, end=None, **kwargs):
        if path not in self.store:
            raise FileNotFoundError(path)
        return self.store[path][start:end]


def test_cat_ranges_on_error_return_keeps_exceptions_inline():
    # Default on_error="return": a failed range comes back as an exception value,
    # positionally aligned with the inputs (matches AbstractFileSystem.cat_ranges).
    fs = _CatRangesFS()
    out = fs.cat_ranges(["ok", "missing"], [0, 0], [4, 4])
    assert out[0] == b"0123"
    assert isinstance(out[1], FileNotFoundError)


def test_cat_ranges_on_error_raise_propagates():
    # on_error="raise" must raise the first error instead of returning it inline.
    fs = _CatRangesFS()
    with pytest.raises(FileNotFoundError):
        fs.cat_ranges(["ok", "missing"], [0, 0], [4, 4], on_error="raise")


# ---------------------------------------------------------------------------
# Tests for the prefix= hint that _glob passes to _find
# ---------------------------------------------------------------------------

_GLOB_PREFIX_FILES = [
    "data/2024/results.csv",
    "data/2024/report.txt",
    "data/2023/results.csv",
    "top_results.csv",
    "top_other.txt",
    "other/results.csv",
]


class _PrefixCapturingFS(fsspec.asyn.AsyncFileSystem):
    """Minimal AsyncFileSystem that records every _find call's kwargs.

    _find ignores the prefix hint and returns all files under *root* so that
    the client-side glob pattern-matching in _glob still works correctly.
    This simulates a "naive" backend that silently absorbs unknown kwargs.
    """

    protocol = "prefixmock"

    def __init__(self, fs_files=None, **kwargs):
        super().__init__(**kwargs)
        self.find_calls = []
        self.fs_files = fs_files if fs_files is not None else _GLOB_PREFIX_FILES

    async def _find(self, path, maxdepth=None, withdirs=False, detail=False, **kwargs):
        self.find_calls.append({"path": path, "kwargs": dict(kwargs)})
        root = (path.rstrip("/") + "/") if path else ""
        results = {
            f: {"name": f, "type": "file", "size": 0}
            for f in self.fs_files
            if f.startswith(root)
        }
        return results if detail else list(results)

    async def _info(self, path, **kwargs):
        for f in self.fs_files:
            if f == path:
                return {"name": f, "type": "file", "size": 0}
        raise FileNotFoundError(path)


@pytest.fixture
def prefix_fs():
    return _PrefixCapturingFS(skip_instance_cache=True)


@pytest.mark.parametrize(
    "pattern, expected_results, expected_prefix",
    [
        # root/stem* -> prefix="stem"
        (
            "data/2024/res*",
            ["data/2024/results.csv"],
            "res",
        ),
        # root/stem*.ext -> prefix="stem"
        (
            "data/2024/re*.txt",
            ["data/2024/report.txt"],
            "re",
        ),
        # stem* (no slash) -> prefix="stem"
        (
            "top_*",
            ["top_other.txt", "top_results.csv"],
            "top_",
        ),
        # ? wildcard: prefix is everything before the first ?
        (
            "top_r?sults.csv",
            ["top_results.csv"],
            "top_r",
        ),
        # [ wildcard: prefix is everything before the first [
        # re[rp]* translates to re[rp][^/]* so only report.txt matches (not results.csv)
        (
            "data/2024/re[rp]*",
            ["data/2024/report.txt"],
            "re",
        ),
        # root/* (wildcard immediately after /) -> empty prefix, NOT forwarded
        (
            "data/2024/*",
            ["data/2024/report.txt", "data/2024/results.csv"],
            None,
        ),
        # bare * (no prefix at all) -> NOT forwarded
        # * translates to [^/]+ so paths containing / are excluded
        (
            "*",
            ["top_other.txt", "top_results.csv"],
            None,
        ),
    ],
)
def test_glob_prefix_hint(prefix_fs, pattern, expected_results, expected_prefix):
    """_glob should extract the literal stem before the first wildcard and
    forward it as ``prefix=`` to ``_find``.  When the stem is empty the kwarg
    must not be forwarded at all so that backends that reject unknown kwargs
    are not broken.  The glob results must be correct regardless."""
    results = prefix_fs.glob(pattern)
    assert sorted(results) == sorted(expected_results)

    assert len(prefix_fs.find_calls) == 1
    forwarded = prefix_fs.find_calls[0]["kwargs"]

    if expected_prefix is None:
        assert "prefix" not in forwarded, (
            f"prefix= should not be forwarded for pattern {pattern!r}, "
            f"but got prefix={forwarded.get('prefix')!r}"
        )
    else:
        assert forwarded.get("prefix") == expected_prefix, (
            f"expected prefix={expected_prefix!r} for pattern {pattern!r}, "
            f"got {forwarded.get('prefix')!r}"
        )


@pytest.mark.asyncio
async def test_expand_path_special_characters_async():
    fs_files = [
        "bucket",
        "bucket/file[1].txt",
        "bucket/file?.txt",
        "bucket/normal.txt",
    ]
    fs = _PrefixCapturingFS(fs_files=fs_files)
    paths = await fs._expand_path("bucket", recursive=True)
    expected = [
        "bucket",
        "bucket/file[1].txt",
        "bucket/file?.txt",
        "bucket/normal.txt",
    ]
    assert sorted(paths) == sorted(expected)


@pytest.mark.asyncio
async def test_expand_path_with_magic_input_async():
    fs_files = [
        "bucket",
        "bucket/file[1].txt",
        "bucket/file?.txt",
        "bucket/normal.txt",
    ]
    fs = _PrefixCapturingFS(fs_files=fs_files)
    paths = await fs._expand_path("bucket/file*.txt", recursive=True)
    expected = [
        "bucket/file[1].txt",
        "bucket/file?.txt",
    ]
    assert sorted(paths) == sorted(expected)


@pytest.mark.asyncio
async def test_isfile_does_not_swallow_cancellation():
    # `_isdir` catches OSError; `_isfile` must not be broader than that to the point
    # of swallowing CancelledError, which does not derive from Exception.
    class CancellingFS(fsspec.asyn.AsyncFileSystem):
        async def _info(self, path, **kwargs):
            raise asyncio.CancelledError()

    fs = CancellingFS()
    with pytest.raises(asyncio.CancelledError):
        await fs._isdir("path")
    with pytest.raises(asyncio.CancelledError):
        await fs._isfile("path")


class UnreadableAsyncSubdirFS(fsspec.asyn.AsyncFileSystem):
    """The async counterpart of the unreadable-subdirectory tree."""

    protocol = "unreadableasyncsub"
    cachable = False
    mirror_sync_methods = False

    tree = {
        "": ["top"],
        "top": ["top/readable", "top/locked"],
        "top/readable": [],
    }

    async def _ls(self, path, detail=True, **kwargs):
        path = self._strip_protocol(path).rstrip("/")
        if path == "top/locked":
            raise PermissionError("no access to top/locked")
        entries = [
            {"name": name, "type": "directory", "size": 0} for name in self.tree[path]
        ]
        return entries if detail else [entry["name"] for entry in entries]


@pytest.mark.asyncio
async def test_async_walk_on_error_reaches_subdirectories():
    # _walk documents the same on_error contract as walk(), and had the same
    # omission in the recursive call.
    fs = UnreadableAsyncSubdirFS()
    # _walk yields the path it could not list, where walk() omits it. That
    # difference predates this and is left alone here; what matters is that the
    # last entry only appears at all when on_error is left at the default.
    omitted = [
        ("", ["top"], []),
        ("top", ["readable", "locked"], []),
        ("top/readable", [], []),
    ]
    yielded = omitted + [("top/locked", [], [])]

    assert [entry async for entry in fs._walk("")] == yielded

    with pytest.raises(PermissionError, match="no access to top/locked"):
        [entry async for entry in fs._walk("", on_error="raise")]

    handled = []
    assert [entry async for entry in fs._walk("", on_error=handled.append)] == yielded
    assert [str(exc) for exc in handled] == ["no access to top/locked"]
