.. _traversal:

Traversal
=========

.. toctree::
   :maxdepth: 2



Depth First Search
------------------
.. automodule:: networkx.algorithms.traversal.depth_first_search
.. autosummary::
   :toctree: generated/

   dfs_edges
   dfs_tree
   dfs_predecessors
   dfs_successors
   dfs_preorder_nodes
   dfs_postorder_nodes
   dfs_labeled_edges

Breadth First Search
--------------------
.. automodule:: networkx.algorithms.traversal.breadth_first_search
.. autosummary::
   :toctree: generated/

   bfs_edges
   bfs_layers
   bfs_tree
   bfs_predecessors
   bfs_successors
   descendants_at_distance
   bfs_labeled_edges
   generic_bfs_edges

Beam search
-----------
.. automodule:: networkx.algorithms.traversal.beamsearch
.. autosummary::
   :toctree: generated/

   bfs_beam_edges


Depth First Search on Edges
---------------------------
.. automodule:: networkx.algorithms.traversal.edgedfs
.. autosummary::
   :toctree: generated/

   edge_dfs

Breadth First Search on Edges
-----------------------------
.. automodule:: networkx.algorithms.traversal.edgebfs
.. autosummary::
   :toctree: generated/

   edge_bfs
