import datetime, hashlib, json, os, pathlib, resource, shutil, subprocess, sys, time

REPO = pathlib.Path('/workspace/udm-v54')
ROOT = pathlib.Path('/workspace/qualification/native-authority-v42-screening-sealed')
CONTROLLER = pathlib.Path('/workspace/qualification/native-authority-v42-screening-controller')
REQUESTS = pathlib.Path('/workspace/qualification/native-authority-v42-screening-requests')
PYTHON = '/workspace/qualification/native-authority-v42-controller/bin/python'
AUTHORITY = REPO/'research/unified_consequence_runtime/archaeology/native-authority-v42/SCREENING_AUTHORITY.json'
AUTHORITY_SHA = '1e03a16d2eb201a6bbe15325804051c2652dd9820c8a235eed8f46bd091540cd'
RUNTIMES = '/workspace/qualification/native-authority-v41-profile-preparation/RUNTIMES.json'
HEAD = 'c56d29fae856cceaa0a00000b1c3b782ea1df346'
INDEX = pathlib.Path((CONTROLLER/'git-index-path.txt').read_text().strip())
INDEX_SHA = (CONTROLLER/'git-index-before.sha256').read_text().strip()
ENV = dict(os.environ, PYTHONPATH=str(REPO), PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
LOGS = ROOT/'controller-command-logs'
LOGS.mkdir(mode=0o700)


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')


def usage(kind):
    value = resource.getrusage(kind)
    return {name: getattr(value, name) for name in ('ru_utime', 'ru_stime', 'ru_maxrss', 'ru_ixrss', 'ru_idrss', 'ru_isrss', 'ru_minflt', 'ru_majflt', 'ru_nswap', 'ru_inblock', 'ru_oublock', 'ru_msgsnd', 'ru_msgrcv', 'ru_nsignals', 'ru_nvcsw', 'ru_nivcsw')}


def identity():
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, env=ENV, text=True).strip(),
            'index_sha256': hashlib.sha256(INDEX.read_bytes()).hexdigest(),
            'authority_sha256': hashlib.sha256(AUTHORITY.read_bytes()).hexdigest()}


def emit(value):
    print(json.dumps(value, sort_keys=True), flush=True)


started = time.monotonic()
receipt = {'schema':'UDM_INDEPENDENT_V42_SCREENING_CONTROLLER_RECEIPT_V1', 'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'controller':PYTHON, 'source_commit':HEAD, 'authority_sha256':AUTHORITY_SHA,
    'usage_self_before':usage(resource.RUSAGE_SELF), 'usage_children_before':usage(resource.RUSAGE_CHILDREN),
    'cases':[], 'completed':False}
write(CONTROLLER/'CONTROLLER_RECEIPT.json', receipt)
try:
    if not all((REQUESTS/f'request-{i:03d}.json').is_file() for i in range(6)):
        raise RuntimeError('ALL_SIX_REQUESTS_REQUIRED_BEFORE_START')
    for i in range(6):
        ident = identity()
        if ident != {'head':HEAD,'index_sha256':INDEX_SHA,'authority_sha256':AUTHORITY_SHA}:
            raise RuntimeError('OWNED_SOURCE_IDENTITY_CHANGED')
        marker = CONTROLLER/f'case-{i:03d}.ATTEMPTED.json'
        if marker.exists(): raise RuntimeError('CONTROLLER_CASE_ALREADY_ATTEMPTED')
        command = [PYTHON, '-B', '-m', 'research.unified_consequence_runtime.qualify_native_frontier_v42',
            '--screen-spec', str(REQUESTS/f'request-{i:03d}.json'), '--authority', str(AUTHORITY),
            '--authority-sha256', AUTHORITY_SHA, '--runtimes', RUNTIMES, '--out', str(ROOT/f'case-{i:03d}')]
        row = {'index':i, 'command':command, 'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'usage_self_before':usage(resource.RUSAGE_SELF), 'usage_children_before':usage(resource.RUSAGE_CHILDREN),
            'stdout':str(CONTROLLER/f'case-{i:03d}.stdout'), 'stderr':str(CONTROLLER/f'case-{i:03d}.stderr')}
        write(marker,row)
        case_started = time.monotonic()
        for stream in ('stdout','stderr'):
            (CONTROLLER/f'case-{i:03d}.{stream}').symlink_to(LOGS/f'case-{i:03d}.{stream}')
        emit({'event':'case_started','index':i})
        with (LOGS/f'case-{i:03d}.stdout').open('wb') as stdout, (LOGS/f'case-{i:03d}.stderr').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=REPO, env=ENV, stdout=stdout, stderr=stderr)
            next_status = time.monotonic()+45
            while process.poll() is None:
                time.sleep(1)
                if time.monotonic() >= next_status:
                    emit({'event':'case_running','index':i,'controller_wall_seconds':round(time.monotonic()-case_started,3)})
                    next_status = time.monotonic()+45
            row['returncode'] = process.returncode
        row.update(wall_seconds=time.monotonic()-case_started, usage_self_after=usage(resource.RUSAGE_SELF),
            usage_children_after=usage(resource.RUSAGE_CHILDREN))
        write(CONTROLLER/f'case-{i:03d}.CONTROLLER_RECEIPT.json', row)
        receipt['cases'].append(row)
        write(CONTROLLER/'CONTROLLER_RECEIPT.json', receipt)
        envelope_path = ROOT/f'case-{i:03d}'/'SCREENING_ENVELOPE.json'
        meter_path = ROOT/'SCREENING_METER.json'
        if not envelope_path.is_file() or not meter_path.is_file():
            raise RuntimeError('SCREENING_PUBLIC_ENVELOPE_OR_METER_MISSING')
        envelope = json.loads(envelope_path.read_text())
        meter = json.loads(meter_path.read_text())
        if (row['returncode'] != 0 or meter.get('accounting_complete') is not True or meter.get('pending') is not None
                or len(meter.get('cases',[])) != i+1 or meter['cases'][-1].get('index') != i
                or meter['cases'][-1].get('accounting_complete') is not True
                or meter['cases'][-1].get('costs',{}).get('native_calls',0) > 2
                or meter.get('native_calls',0) > 12):
            raise RuntimeError('SCREENING_INSTRUMENTATION_OR_ACCOUNTING_FAILURE')
        sealed_report = json.loads((ROOT/f'case-{i:03d}'/'SCREENING_CASE.json').read_text())
        public = {'index':i,'envelope':envelope,'refusal_category':None if envelope['eligible'] else sealed_report['status'],
            'controller_wall_seconds':row['wall_seconds'],
            'meter':{key:meter[key] for key in ('native_calls','collection_calls','accounting_complete','pending')},
            'meter_completed_cases':len(meter['cases'])}
        write(CONTROLLER/f'case-{i:03d}.PUBLIC.json',public)
        emit({'event':'case_completed',**public})
    receipt['completed'] = True
except BaseException as error:
    receipt['controller_obstruction_category'] = str(error) if isinstance(error,RuntimeError) else type(error).__name__
    emit({'event':'controller_stopped','obstruction_category':receipt['controller_obstruction_category']})
    raise
finally:
    receipt.update(wall_seconds=time.monotonic()-started,usage_self_after=usage(resource.RUSAGE_SELF),
        usage_children_after=usage(resource.RUSAGE_CHILDREN),finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    raw_index = INDEX.read_bytes()
    (CONTROLLER/'git-index-after.raw').write_bytes(raw_index)
    (CONTROLLER/'git-index-after.sha256').write_text(hashlib.sha256(raw_index).hexdigest()+'\n')
    receipt['final_source_identity'] = identity()
    receipt['raw_git_index_unchanged'] = raw_index == (CONTROLLER/'git-index-before.raw').read_bytes()
    write(CONTROLLER/'CONTROLLER_RECEIPT.json',receipt)
    emit({'event':'controller_final','completed':receipt['completed'],'wall_seconds':receipt['wall_seconds'],
        'raw_git_index_unchanged':receipt['raw_git_index_unchanged'],'final_source_identity':receipt['final_source_identity']})
