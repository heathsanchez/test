"""Read-only V42 supplied-run audit. Executes no project or target source."""
import datetime
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import subprocess

ROOT=Path('/workspace/qualification/native-authority-v42-screening-audit')
REPO=Path('/workspace/udm-v54')
REC=REPO/'research/unified_consequence_runtime/archaeology/native-authority-v42'
SEALED=Path('/workspace/qualification/native-authority-v42-screening-sealed')
CTRL=Path('/workspace/qualification/native-authority-v42-screening-controller')
REQUESTS=Path('/workspace/qualification/native-authority-v42-screening-requests')
HEAD='c56d29fae856cceaa0a00000b1c3b782ea1df346'
PRE='f05a708023e609df17ad53934f32893dd4235e46'
GATE='f1779c7443ae6035dee502a201d95d778056c05d'
ENV=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
CHECKS=[]
INPUTS={}
def h(raw):return hashlib.sha256(raw).hexdigest()
def oid(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def fp(value):return h(canon(value).encode())
def read(p):
 p=Path(p);raw=p.read_bytes();INPUTS[str(p)]={'sha256':h(raw),'bytes':len(raw)};return raw
def js(p):return json.loads(read(p))
def write(p,value):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
def check(name,value,detail=None):CHECKS.append({'check':name,'passed':bool(value),**({'detail':detail} if detail is not None else {})})
def git(*args):
 p=subprocess.run(['git','--no-replace-objects',*args],cwd=REPO,env=ENV,capture_output=True)
 check('git_read:'+repr(args),p.returncode==0,{'stderr':p.stderr.decode(errors='replace')})
 if p.returncode:raise RuntimeError(args)
 return p.stdout
def bound(desc):
 p=Path(desc['path']);check('bound:'+str(p),p.is_file() and not p.is_symlink() and h(read(p))==desc['sha256']);return js(p)

pool=js(REC/'FROZEN_POOL.json');plan=js(REC/'PREQUERY.json');pre=js(REC/'PREQUERY_EXECUTION.json')
authority=js(REC/'SCREENING_AUTHORITY.json');protocol=js(REC/'FRONTIER_PROTOCOL.json');meta=js(REC/'METADATA_CURATION.json')
authority_sha=h(read(REC/'SCREENING_AUTHORITY.json'));pool_sha=h(read(REC/'FROZEN_POOL.json'))
meter=js(SEALED/'SCREENING_METER.json');controller=js(CTRL/'CONTROLLER_RECEIPT.json');public=js(CTRL/'PUBLIC_SCREENING_SUMMARY.json')
check('owned_head_exact',git('rev-parse','HEAD').decode().strip()==HEAD)
check('prequery_is_ancestor',subprocess.run(['git','--no-replace-objects','merge-base','--is-ancestor',PRE,HEAD],cwd=REPO,env=ENV).returncode==0)
check('qualified_gate_is_ancestor',subprocess.run(['git','--no-replace-objects','merge-base','--is-ancestor',GATE,PRE],cwd=REPO,env=ENV).returncode==0)
# Independently bind every HEAD blob to raw Git objects, path mode, index and filesystem.
tree_raw=git('ls-tree','-rz','--full-tree',HEAD)
rows=[]
for item in tree_raw.split(b'\0'):
 if not item:continue
 left,name=item.split(b'\t',1);mode,kind,blob=left.decode().split();rows.append({'path':name.decode(),'mode':mode,'kind':kind,'blob':blob})
batch=git('cat-file','--batch') if False else subprocess.run(['git','--no-replace-objects','cat-file','--batch'],cwd=REPO,env=ENV,input=('\n'.join(r['blob'] for r in rows)+'\n').encode(),capture_output=True)
check('owned_batch_read_success',batch.returncode==0);offset=0;source=[];mismatches=[];blobs={}
for r in rows:
 end=batch.stdout.index(b'\n',offset);header=batch.stdout[offset:end].decode().split();offset=end+1
 size=int(header[2]);raw=batch.stdout[offset:offset+size];offset+=size+1
 path=REPO/r['path'];exists=path.exists() or path.is_symlink()
 actual=os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes() if path.is_file() else None
 mode='120000' if path.is_symlink() else '100755' if path.is_file() and path.stat().st_mode&0o111 else '100644' if path.is_file() else None
 valid=header[0]==r['blob'] and header[1]==r['kind']=='blob' and oid('blob',raw)==r['blob'] and actual==raw and mode==r['mode']
 if not valid:mismatches.append(r['path'])
 source.append({**r,'sha256':h(raw),'bytes':size,'filesystem_exact':valid});blobs[r['path']]=raw
check('all_owned_tracked_bytes_modes_git_objects_exact',not mismatches,{'files':len(rows),'mismatches':mismatches})
untracked=git('ls-files','--others','--exclude-standard','-z').split(b'\0');check('owned_no_untracked_nonignored',[p for p in untracked if p]==[])
index_path=Path(js(ROOT/'INDEX_BEFORE.json')['gitdir'])/'index';idx=read(index_path)
check('owned_index_header_checksum',idx[:4]==b'DIRC' and struct.unpack_from('>I',idx,4)[0] in (2,3) and hashlib.sha1(idx[:-20]).digest()==idx[-20:])
idxrows=[];pos=12
for _ in range(struct.unpack_from('>I',idx,8)[0]):
 start=pos;mode=struct.unpack_from('>I',idx,pos+24)[0];blob=idx[pos+40:pos+60].hex();flags=struct.unpack_from('>H',idx,pos+60)[0];pos+=62
 if flags&0x4000:pos+=2
 end=idx.index(b'\0',pos);name=idx[pos:end].decode();pos=start+((end+1-start+7)//8)*8;idxrows.append({'path':name,'mode':format(mode,'o'),'blob':blob})
check('owned_index_equals_head_paths_modes_blobs',idxrows==[{k:r[k] for k in ('path','mode','blob')} for r in rows])
write(ROOT/'OWNED_SOURCE_IDENTITY.json',{'source_commit':HEAD,'files':source,'index_entries':idxrows,'all_exact':not mismatches})
# Copy exact frozen committed inputs, never alter originals.
for n in ['PREQUERY.json','PREQUERY_EXECUTION.json','FROZEN_POOL.json','SCREENING_AUTHORITY.json','FRONTIER_PROTOCOL.json','METADATA_CURATION.json','DECLARED_UNIVERSE.json','QUALIFIED_GATE.json','curate_frontier.py','prepare_records.py']:
 p=REC/n;rel=p.relative_to(REPO).as_posix();raw=git('cat-file','blob',HEAD+':'+rel)
 check('frozen_head_bytes:'+n,raw==read(p));target=ROOT/'committed'/n;target.parent.mkdir(exist_ok=True);target.write_bytes(raw)
for key in ('plan','code','gate_descriptor'):
 row=pre[key];raw=git('cat-file','blob',PRE+':'+row['path']);check('prequery_committed_'+key,row['source_commit']==PRE and h(raw)==row['sha256'] and raw==read(REPO/row['path']))
check('frozen_digest_chain',pool['metadata_curation_sha256']==h(read(REC/'METADATA_CURATION.json')) and pool['prequery_execution_sha256']==meta['prequery_execution_sha256']==h(read(REC/'PREQUERY_EXECUTION.json')) and meta['prequery_plan_sha256']==h(read(REC/'PREQUERY.json')) and authority['pool']==protocol['pool']=={'path':(REC/'FROZEN_POOL.json').relative_to(REPO).as_posix(),'sha256':pool_sha} and authority['prequery']==protocol['prequery']=={'path':(REC/'PREQUERY_EXECUTION.json').relative_to(REPO).as_posix(),'sha256':h(read(REC/'PREQUERY_EXECUTION.json'))})
universe=js(REC/'DECLARED_UNIVERSE.json')['repositories']
check('exact_eight_new_repositories',universe==pre['repository_universe_fixed_before_github_queries']==plan['repository_universe_fixed_before_github_queries'] and len(universe)==8 and universe==sorted(set(universe)) and not set(universe)&set(plan['historically_touched_repository_exclusions']))
check('budget_and_pool_identity',pool['pool']==meta['pool'] and len(pool['pool'])==6 and pool['screening_budget']==pre['screening_budget']==plan['screening_budget'] and pool['screening_budget']['maximum_cases']==9 and pool['screening_budget']['maximum_native_executions_per_case']==2 and pool['selection_rule']=='First two source-distinct independent native admissions; PASS and FAIL identical; do not replace a passing training task.')
# Recompute every candidate decision over complete retained projected metadata.
def is_test(name):
 p=PurePosixPath(name);return name.endswith('.py') and (any(x in {'test','tests','testing'} for x in p.parts) or p.name.startswith('test_') or p.name.endswith('_test.py') or p.name=='conftest.py')
queries=[];chosen=[];candidate_count=0
for r in meta['repositories']:
 check('repository_retained:'+r['repo'],len(r['candidates'])==r['closed_pr_count']<=100 and r['closed_pr_window']=={'direction':'desc','page':1,'per_page':100,'scope':'Latest at most 100 closed PRs; older pages outside the fixed universe.','sort':'updated'})
 qualifiers=[]
 for rank,c in enumerate(r['candidates'],1):
  candidate_count+=1;reasons=[]
  if not c['merged_at']:reasons.append('NOT_MERGED')
  if not(re.match(r'^fix',c['title'],re.I) or any('bug' in v.lower() for v in c['labels'])):reasons.append('TITLE_NOT_FIX_AND_NO_BUG_LABEL')
  if not reasons:
   files=c['files'];pagination=c['file_pagination'];check('files_complete:'+r['repo']+':'+str(c['number']),pagination['closed'] and pagination['entries_returned']==len(files) and pagination['pages_requested']==len(files)//100+1)
   if any(f['status'] in {'renamed','removed'} for f in files):reasons.append('RENAMED_OR_REMOVED_CHANGED_FILE')
   tests=[f for f in files if is_test(f['filename'])];production=[f for f in files if f['filename'].endswith('.py') and not is_test(f['filename'])];adds=sum(f['additions'] for f in production);dels=sum(f['deletions'] for f in production)
   check('metadata_stats:'+r['repo']+':'+str(c['number']),c['metadata_stats']=={'test_py_files':len(tests),'production_py_files':len(production),'production_additions':adds,'production_deletions':dels})
   if not tests:reasons.append('NO_CHANGED_TEST_PY')
   if not production:reasons.append('NO_CHANGED_PRODUCTION_PY')
   if not 1<=dels<=4:reasons.append('PRODUCTION_DELETIONS_OUTSIDE_1_TO_4')
   if adds>6:reasons.append('PRODUCTION_ADDITIONS_ABOVE_6')
   if not reasons and any(f['status']!='modified' for f in production):reasons.append('PRODUCTION_PY_NOT_ALL_PREEXISTING_MODIFIED')
  check('candidate_decision:'+r['repo']+':'+str(c['number']),c['rank_within_repository']==rank and c['reasons']==reasons and c['status']==('REJECTED_METADATA_PREDICATES' if reasons else 'QUALIFIES_METADATA_ONLY'))
  if not reasons:qualifiers.append(c)
 check('first_fixed_qualifier:'+r['repo'],r['qualifying_prs']==[c['number'] for c in qualifiers] and r['status']==('QUALIFYING_METADATA_CANDIDATE' if qualifiers else 'NO_QUALIFYING_CANDIDATE') and r.get('first_qualifying_pr')==(qualifiers[0]['number'] if qualifiers else None))
 if qualifiers:chosen.append((r['repo'],qualifiers[0]))
 queries+=r['query_coverage']
check('fixed_universe_query_order',[r['repo'] for r in meta['repositories']]==universe)
for spec,(repo,c) in zip(pool['pool'],chosen):
 check('chosen_spec:'+repo,spec['repo']==repo and spec['pr']==c['number'] and spec['base_commit']==c['base']['sha'] and spec['head_commit']==c['head']['sha'] and spec['files']==c['files'] and spec['metadata_stats']==c['metadata_stats'])
 queries+=spec['tree_query_coverage']
check('all_chosen_retained',len(chosen)==len(pool['pool']))
allowed=[(re.compile(r'repos/[^/]+/[^/]+/pulls\?state=closed&sort=updated&direction=desc&per_page=100&page=1'),plan['api_allowlist']['closed_pr_list']),(re.compile(r'repos/[^/]+/[^/]+/pulls/[1-9][0-9]*/files\?per_page=100&page=[1-9][0-9]*'),plan['api_allowlist']['changed_file_pages']),(re.compile(r'repos/[^/]+/[^/]+/git/commits/[0-9a-f]{40}'),plan['api_allowlist']['git_commit_metadata']),(re.compile(r'repos/[^/]+/[^/]+/git/trees/[0-9a-f]{40}\?recursive=1'),plan['api_allowlist']['git_tree_metadata'])]
for q in queries:check('metadata_query_allowlist:'+q['endpoint'],q['status']=='OK' and q['returncode']==0 and '/'.join(q['endpoint'].split('/')[1:3]) in universe and any(p.fullmatch(q['endpoint']) and q['projection']==v for p,v in allowed) and q['requested_at_utc']>pre['committed_bytes_verified_at_utc'])
check('metadata_costs',len(queries)==meta['costs']['metadata_api_calls']==106 and meta['costs']['collection_calls']==meta['costs']['native_calls']==0 and 0<=meta['costs']['metadata_wall_seconds']<=meta['costs']['total_curation_wall_seconds']<meta['costs']['metadata_budget_seconds']==900)
reflog=read(Path(js(ROOT/'INDEX_BEFORE.json')['common_gitdir'])/'logs/refs/remotes/origin/research/udm-native-authority-v42-20261021').decode();pushes=[]
for line in reflog.splitlines():
 fields=line.split();new=fields[1];match=re.search(r' (\d+) [+-]\d{4}\tupdate by push$',line)
 if match and new in (PRE,HEAD):pushes.append({'commit':new,'pushed_at_unix':int(match.group(1)),'raw_line':line})
check('pushes_before_queries_and_screening',len(pushes)==2 and next(v['pushed_at_unix'] for v in pushes if v['commit']==PRE)<min(datetime.datetime.fromisoformat(q['requested_at_utc']).timestamp() for q in queries) and next(v['pushed_at_unix'] for v in pushes if v['commit']==HEAD)<datetime.datetime.fromisoformat(controller['started_at_utc']).timestamp())
write(ROOT/'PUSH_ORDER_LOCAL_REFLOG.json',pushes)
gate=js(REC/'CI_39582982718_RESULT.json');gate_audit=js(REC/'CI_39582982718_INDEPENDENT_AUDIT.json');desc=authority['environment_gate']
check('independent_gate_exact',desc==protocol['environment_gate']==pre['environment_gate'] and desc['source_commit']==gate['source_commit']==gate_audit['source_commit']==GATE and gate['status']==desc['status']=='ADMISSION_ONLY_QUALIFIED' and h(read(REPO/desc['result_path']))==desc['qualification_result_sha256'] and gate_audit['status']=='PASS_INDEPENDENT_BOUNDED_ADMISSION_GATE' and gate_audit['archive_and_raw_checks_total']==1375 and not gate_audit['obstructions'] and h(read(Path(gate_audit['artifact_zip']['path'])))==desc['artifact_sha256']==gate_audit['artifact_zip']['sha256'])
check('qualified_source_files_preserved',all(p in blobs and h(blobs[p])==digest for p,digest in gate['freeze']['files'].items()),{'files':len(gate['freeze']['files'])})
# Exact six requests, once-only controller and retained public envelopes.
check('six_requests_and_case_directories',set(REQUESTS.glob('request-*.json'))=={REQUESTS/f'request-{i:03d}.json' for i in range(6)} and {p.name for p in SEALED.glob('case-*') if p.is_dir()}=={f'case-{i:03d}' for i in range(6)})
check('authority_and_meter',authority['operation']=='screen' and authority['repo']==str(REPO) and authority['output_root']==str(SEALED) and meter['authority_sha256']==controller['authority_sha256']==public['authority_sha256']==authority_sha and meter['source_commit']==controller['source_commit']==public['source_commit']==HEAD and meter['pending'] is None and meter['accounting_complete'] is True and len(meter['cases'])==6 and not (SEALED/'SCREENING_METER.lock').exists())
check('controller_complete',controller['completed'] is True and len(controller['cases'])==6 and public['case_count']==6 and public['all_cases_completed_once_in_order'] and public['all_cli_returncodes_zero'] and public['retries_performed'] is False and public['source_and_native_test_changes_performed'] is False)
envelopes=[];costs=[];refusals=[]
for i,spec in enumerate(pool['pool']):
 tag=f'case-{i:03d}';d=SEALED/tag;report=js(d/'SCREENING_CASE.json');envelope=js(d/'SCREENING_ENVELOPE.json');case=meter['cases'][i];setup=report['setup'];receipt=js(CTRL/(tag+'.CONTROLLER_RECEIPT.json'));pub=js(CTRL/(tag+'.PUBLIC.json'));attempt=js(CTRL/(tag+'.ATTEMPTED.json'))
 check(tag+':request_exact',js(REQUESTS/f'request-{i:03d}.json')=={'pool_index':i,'spec':spec,'protocol_binding':authority_sha})
 check(tag+':identity',report['repository']==envelope['repository']==spec['repo'] and report['spec_sha256']==envelope['spec_sha256']==case['spec_sha256']==fp(spec) and case['index']==receipt['index']==pub['index']==i)
 check(tag+':report_binding',case['report']==envelope['sealed_report'] and bound(case['report'])==report and pub['envelope']==envelope and public['cases'][i]['envelope']==envelope)
 expected={'schema':'UDM_SEALED_ADMISSION_ENVELOPE_V3','repository':spec['repo'],'spec_sha256':fp(spec),'status':'UNKNOWN_ADMISSION_SCREENING','eligible':False,'screening_mode':'ADMISSION_ONLY_NO_CATALOG_OR_CANDIDATE_SEARCH','sealed_report':case['report'],'costs':{'native_calls':0,'collection_calls':1 if i==0 else 0},'total_wall_seconds':report['total_wall_seconds']}
 check(tag+':exact_public_envelope',envelope==expected)
 check(tag+':exact_complete_attempt',case['accounting_complete'] is report['accounting_complete'] is True and case['costs']==report['controller_attempts']=={'native_calls':0,'collection_calls':1 if i==0 else 0,'subprocess_attempts':1 if i==0 else 0} and report['eligible'] is False and report['costs']==[])
 check(tag+':controller_once_order',receipt==controller['cases'][i] and attempt=={k:v for k,v in receipt.items() if k not in ['returncode','wall_seconds','usage_children_after','usage_self_after']} and receipt['returncode']==0 and receipt['command'][0]==controller['controller'] and receipt['command'][1:4]==['-B','-m','research.unified_consequence_runtime.qualify_native_frontier_v42'] and receipt['command'][4:]==['--screen-spec',str(REQUESTS/f'request-{i:03d}.json'),'--authority',str(REC/'SCREENING_AUTHORITY.json'),'--authority-sha256',authority_sha,'--runtimes','/workspace/qualification/native-authority-v41-profile-preparation/RUNTIMES.json','--out',str(d)] and (i==0 or datetime.datetime.fromisoformat(receipt['started_at_utc']).timestamp()>=datetime.datetime.fromisoformat(controller['cases'][i-1]['started_at_utc']).timestamp()+controller['cases'][i-1]['wall_seconds']))
 check(tag+':controller_logs',js(CTRL/(tag+'.stdout'))=={'status':envelope['status'],'verdicts':{}} and read(CTRL/(tag+'.stderr'))==b'' and all((CTRL/(tag+'.'+stream)).is_symlink() and (CTRL/(tag+'.'+stream)).resolve()==SEALED/'controller-command-logs'/(tag+'.'+stream) for stream in ('stdout','stderr')))
 check(tag+':setup_saved_exact',setup==js(d/'source-environment/admission-v3.json')==js(d/'source-environment/admission-v42.json'))
 phases=setup['costs']
 for j,row in enumerate(phases):
  check(tag+':phase_seconds:'+str(j),isinstance(row['seconds'],(int,float)) and math.isfinite(row['seconds']) and 0<=row['seconds']<=report['total_wall_seconds'])
  if 'log' in row:check(tag+':phase_log:'+str(j),h(read(row['log']))==row['log_sha256'])
 check(tag+':cost_nesting',sum(row['seconds'] for row in phases)<=setup['total_wall_seconds']<=report['total_wall_seconds']<=receipt['wall_seconds'])
 check(tag+':no_learner_or_native_reexecution',not any((d/name).exists() for name in ('independent-collection','baseline','independent-baseline','catalog','candidate','training','agent','coding-agent','learner')))
 for partial in report['partial_native_reports']:bound(partial)
 costs.append({'index':i,'repository':spec['repo'],'setup_phase_costs':phases,'sum_setup_phase_seconds':sum(row['seconds'] for row in phases),'setup_wall_seconds':setup['total_wall_seconds'],'case_wall_seconds':report['total_wall_seconds'],'controller_wall_seconds':receipt['wall_seconds'],'native_calls':case['costs']['native_calls'],'collection_calls':case['costs']['collection_calls'],'subprocess_attempts':case['costs']['subprocess_attempts']})
 refusals.append({'index':i,'repository':spec['repo'],'public_status':envelope['status'],'eligible':envelope['eligible'],'status':report['status'],'reason':report.get('reason',setup.get('reason')),'setup_status':setup['status'],'setup_reason':setup.get('reason')})
 envelopes.append(envelope)
check('native_and_collection_totals',meter['native_calls']==sum(c['native_calls'] for c in costs)==0 and meter['collection_calls']==sum(c['collection_calls'] for c in costs)==1 and sum(c['subprocess_attempts'] for c in costs)==1)
check('public_meter_and_cost_totals',public['global_screening_meter']==meter and public['eligible_count']==0 and public['screening_case_wall_seconds_sum']==sum(c['case_wall_seconds'] for c in costs) and public['controller_costs']['wall_seconds']==controller['wall_seconds']==85.05430250600057 and sum(c['controller_wall_seconds'] for c in costs)<=controller['wall_seconds']<pool['screening_budget']['total_screening_wall_seconds'])
index_before=read(CTRL/'git-index-before.raw');check('controller_active_index_closed',index_before==read(CTRL/'git-index-after.raw')==read(CTRL/'git-index-after-all-reads.raw')==idx and h(index_before)==(CTRL/'git-index-before.sha256').read_text().strip()==(CTRL/'git-index-after.sha256').read_text().strip()==(CTRL/'git-index-after-all-reads.sha256').read_text().strip() and controller['raw_git_index_unchanged'] and public['raw_git_index_unchanged'])
write(ROOT/'SCREENING_ENVELOPES_EXACT.json',envelopes);write(ROOT/'REFUSALS_EXACT.json',refusals)
totals={'metadata_api_calls':106,'metadata_total_curation_wall_seconds':meta['costs']['total_curation_wall_seconds'],'native_calls':0,'collection_calls':1,'worker_subprocess_attempts':1,'sum_setup_phase_seconds':sum(c['sum_setup_phase_seconds'] for c in costs),'sum_setup_wall_seconds':sum(c['setup_wall_seconds'] for c in costs),'sum_case_wall_seconds':sum(c['case_wall_seconds'] for c in costs),'sum_controller_case_wall_seconds':sum(c['controller_wall_seconds'] for c in costs),'whole_screening_controller_wall_seconds':controller['wall_seconds'],'controller_cpu_self_seconds':sum(controller['usage_self_after'][k]-controller['usage_self_before'][k] for k in ('ru_utime','ru_stime')),'controller_cpu_children_seconds':sum(controller['usage_children_after'][k]-controller['usage_children_before'][k] for k in ('ru_utime','ru_stime'))}
write(ROOT/'COSTS_BY_CASE.json',{'cases':costs,'totals':totals,'scope':'Nested setup/case/controller wall measurements are nonadditive. Native counters cover worker calls, not metadata transport/preflight subprocesses. Full engineering/model/tool lifecycle costs UNKNOWN.'})
write(ROOT/'RETAINED_CHECKS.json',{'status':'PASS_RETAINED_SCREENING_BINDINGS' if all(c['passed'] for c in CHECKS) else 'UNKNOWN_RETAINED_SCREENING_BINDINGS','checks':CHECKS,'check_count':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']],'pool_sha256':pool_sha,'reports_sha256':fp(envelopes),'reports':envelopes,'candidate_metadata_rows':candidate_count,'metadata_query_count':len(queries),'costs':totals,'inputs':INPUTS})
print(json.dumps({'checks':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']],'pool_sha256':pool_sha,'reports_sha256':fp(envelopes),'costs':totals},indent=2))
