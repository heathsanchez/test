"""Close independent retained-evidence audit and immutable owned-index interval."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess

B=Path('/workspace/qualification/native-authority-v42-screening-audit')
REPO=Path('/workspace/udm-v54')
HEAD='c56d29fae856cceaa0a00000b1c3b782ea1df346'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def fp(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def load(p):return json.loads(Path(p).read_text())
def desc(p):
 p=Path(p);raw=p.read_bytes();return {'path':str(p),'sha256':sha(raw),'bytes':len(raw)}
def write(p,value):Path(p).write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
checks=[]
def check(name,condition,detail=None):checks.append({'check':name,'passed':bool(condition),**({'detail':detail} if detail is not None else {})})
retained=load(B/'RETAINED_CHECKS.json');source=load(B/'source-identity/SOURCE_IDENTITY_AUDIT.json');ss=load(B/'source-identity/SUMMARY.json');build=load(B/'source-identity/BUILD_SOURCE_AUDIT.json');runtime=load(B/'runtime-identity/RUNTIME_AUDIT.json');diagnostic=load(B/'runtime-identity/CASE_RUNTIME_AND_OBSTRUCTION_AUDIT.json');initial=load(B/'ROOT_INITIAL_READ_INTERVAL_AUDIT.json')
CTRL=Path('/workspace/qualification/native-authority-v42-screening-controller');attestation=load(CTRL/'ORIGINAL_SCREENING_ACTOR_BOUNDARY_ATTESTATION.json')
check('main_retained_checks_closed',retained['status']=='PASS_RETAINED_SCREENING_BINDINGS' and retained['check_count']==1254 and not retained['failures'] and all(c['passed'] for c in retained['checks']))
check('six_raw_source_cases_closed',source['all_checks_passed'] and ss['status']=='PASS' and len(source['cases'])==ss['cases']==6 and all(c['all_git_objects_hash_validated'] and c['full_filesystem_exact'] and c['metadata_archive']['exact_expected_manifest'] for c in source['cases']))
n=source['cases'][0]['native']
check('original_author_test_only_overlay_and_base_preserved',n['all_git_objects_hash_validated'] and n['full_filesystem_exact'] and n['base_archive']['exact_expected_manifest'] and n['contract_archive']['exact_expected_manifest'] and n['head_commit_absent'] and n['head_changed_production_blobs_absent'] and n['only_test_paths_changed'] and n['production_paths_preserved'])
check('build_generated_file_evidence_closed',build['status']=='PASS' and build['tracked_production_and_all_original_build_files_unchanged'] and build['untracked_generated_build_files']==['src/chardet/_version.py'] and build['generated_version']['absent_raw_contract_source'] and build['generated_version']['present_in_base_build'] and build['generated_version']['present_in_built_wheel'] and build['generated_version']['declared_hatch_vcs_hook'])
check('full_runtime_and_raw_log_checks_closed',runtime['checks_count']==runtime['checks_verified']==279 and runtime['failed_checks']==[] and diagnostic['checks_count']==diagnostic['checks_verified']==62 and diagnostic['failed_checks']==[])
raw=ss['raw_audit'];hasher=hashlib.sha256();size=0
with gzip.open(raw['path'],'rb') as f:
 for block in iter(lambda:f.read(2**20),b''):hasher.update(block);size+=len(block)
check('lossless_complete_raw_source_audit',hasher.hexdigest()==raw['uncompressed_sha256'] and size==raw['uncompressed_bytes'] and desc(raw['path'])['sha256']==raw['sha256'] and desc(B/'source-identity/SOURCE_IDENTITY_AUDIT.json')['sha256']==ss['summary_sha256'])
check('root_earliest_git_read_interval_closed',initial['closed'])
check('original_screening_actor_bounded_attestation',attestation['actor_identity']=='/root/v42_independent_native_screening' and attestation['independent_screener'] is True and attestation['search_or_policy_outcomes_accessed'] is False and attestation['learner_future_source_accessed'] is False and attestation['native_test_reruns_or_case_retries_performed'] is False and attestation['new_task_search_performed'] is False and attestation['source_repairs_performed'] is False and attestation['candidate_or_catalog_generation_invoked'] is False and attestation['learner_or_coding_agent_arm_accessed'] is False and attestation['scope']['source_commit']==HEAD and desc(attestation['scope']['public_summary']['path'])['sha256']==attestation['scope']['public_summary']['sha256'])
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
# Last Git read. The actual post copies below occur after it, with no restoration.
p=subprocess.run(['git','--no-replace-objects','rev-parse','HEAD'],cwd=REPO,env=env,capture_output=True)
check('last_git_read_head_exact',p.returncode==0 and p.stdout.decode().strip()==HEAD,{'stderr':p.stderr.decode(errors='replace')})
before=load(B/'INDEX_BEFORE.json');after=[];cap=B/'index-after';cap.mkdir(exist_ok=True)
gitdir=Path(before['gitdir']);common=Path(before['common_gitdir']);paths={common/'index',gitdir/'index'}
for wt in (common/'worktrees').iterdir():
 if wt.is_dir():paths.add(wt/'index')
check('same_index_path_inventory',{str(x) for x in paths}=={r['path'] for r in before['indexes']})
for i,path in enumerate(sorted(paths)):
 row={'path':str(path),'exists':path.exists()}
 if path.exists():
  rawbytes=path.read_bytes();target=cap/(str(i)+'-index.bin');target.write_bytes(rawbytes);row.update(sha256=sha(rawbytes),size=len(rawbytes),captured_path=str(target),mtime_ns=path.stat().st_mtime_ns)
 old=next((r for r in before['indexes'] if r['path']==str(path)),None)
 same=old is not None and row['exists']==old['exists'] and (not row['exists'] or rawbytes==Path(old['captured_path']).read_bytes())
 row['actual_bytes_or_absence_unchanged']=same;check('actual_pre_post_index:'+str(path),same);after.append(row)
index={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':before,'after':after,'all_actual_index_bytes_and_absences_unchanged':all(r['actual_bytes_or_absence_unchanged'] for r in after),'head':HEAD,'last_git_read_returncode':p.returncode,'git_optional_locks':'0','index_restoration_performed':False,'owned_source_writes_performed':False}
write(B/'INDEX_AFTER.json',index)
helper={'findings':load(B/'source-identity/AUDITOR_NEGATIVE_FINDINGS.json')['findings']+[{'kind':'AUDIT_INFRASTRUCTURE_ASSUMPTION','attempt':1,'detail':'Main audit initially assumed admission-v3.json == admission-v42.json == report.setup. All six equality checks failed. Complete first check report and exact first script retained under audit-helper-attempts. Static wrapper inspection established V42 adds only versioned schema and typed_source_operation source digests. The corrected audit independently verifies that exact wrapper over unchanged V3 receipt; all 1,254 checks then pass. No frozen input or experiment was changed.'}],'frozen_experiment_retries':0,'frozen_experiment_changes':0}
write(B/'AUDITOR_HELPER_NEGATIVES.json',helper)
negative=diagnostic['first_actual_collection_obstruction'];reports=retained['reports']
check('exact_six_public_reports',reports==load(B/'SCREENING_ENVELOPES_EXACT.json') and len(reports)==6 and retained['reports_sha256']==fp(reports) and all(r['eligible'] is False and r['status']=='UNKNOWN_ADMISSION_SCREENING' for r in reports))
refs=[B/'RETAINED_CHECKS.json',B/'OWNED_SOURCE_IDENTITY.json',B/'SCREENING_ENVELOPES_EXACT.json',B/'REFUSALS_EXACT.json',B/'COSTS_BY_CASE.json',B/'RETAINED_RAW_MANIFEST.json',B/'ROOT_INITIAL_READ_INTERVAL_AUDIT.json',B/'INDEX_BEFORE.json',B/'INDEX_AFTER.json',B/'AUDITOR_HELPER_NEGATIVES.json',B/'source-identity/SUMMARY.json',B/'source-identity/SOURCE_IDENTITY_AUDIT.json',B/'source-identity/SOURCE_IDENTITY_AUDIT.full.json.gz',B/'source-identity/BUILD_SOURCE_AUDIT.json',B/'runtime-identity/RUNTIME_AUDIT.json',B/'runtime-identity/CASE_RUNTIME_AND_OBSTRUCTION_AUDIT.json',B/'runtime-identity/RAW_CONFIG_ENV_REFUSAL_LOG_MANIFEST.json',CTRL/'PUBLIC_SCREENING_SUMMARY.json',CTRL/'ORIGINAL_SCREENING_ACTOR_BOUNDARY_ATTESTATION.json']
controller_current=B/'runtime-identity/CONTROLLER_CURRENT_FILESYSTEM_IDENTITY.json'
if controller_current.exists():refs.append(controller_current)
result={'schema':'UDM_V42_INDEPENDENT_ADMISSION_ONLY_SCREENING_AUDIT_V1','status':'PASS_ADMISSION_ONLY_SCREENING_AUDIT' if all(c['passed'] for c in checks) else 'UNKNOWN_ADMISSION_ONLY_SCREENING_AUDIT','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditor':'/root/v42_screening_audit','audit_delegates':['/root/v42_screening_audit/source_identity','/root/v42_screening_audit/runtime_identity'],'source_commit':HEAD,'pool_sha256':retained['pool_sha256'],'reports_sha256':retained['reports_sha256'],'reports':reports,'eligibility_rule':'PASS_NATIVE_OR_FAIL_NATIVE_IDENTICAL','all_screened_cases_and_costs_retained':True,'independent_screener':True,'search_or_policy_outcomes_accessed':False,'learner_future_source_accessed':False,'exposure_scope':'The three exposure/role fields describe the original independent screening boundary, supported by the actor bounded retrospective first-person attestation and inspected controller control flow/retained artifacts. Postexperiment diagnostic reads by the independent auditors occurred only after all six cases were ineligible and no learner/future role would run. These diagnostics do not retroactively expose any learner future source.','scientific_scope':'Completed admission-only screening negatives; failed admission frontier with zero eligible cases. No learner, candidate catalog, policy, or coding-agent arm was executed. No replacement/new task search; no production repair, author-test rewrite, or native retry.','scientific_verdicts':{k:'UNKNOWN' for k in ['G2','G3','G4','G5','G6']},'counts':{'declared_repositories':8,'metadata_selected_cases':6,'screened_cases':6,'eligible_cases':0,'metadata_candidate_rows':retained['candidate_metadata_rows'],'metadata_queries':retained['metadata_query_count'],'owned_tracked_source_files':2264,'native_collection_calls':1,'native_execution_calls':0,'worker_subprocess_attempts':1,'retained_binding_checks':1254,'runtime_filesystem_checks':279,'prepared_runtime_and_raw_diagnostic_checks':62,'source_decoder_assertions':source['check_count'],'source_decoder_count_note':source['check_count_note']},'costs':retained['costs'],'first_obstruction':negative,'other_retained_negatives':diagnostic['other_retained_negative_findings'],'audit_helper_negatives':helper,'index_boundary':{'all_common_current_and_linked_actual_bytes_unchanged':index['all_actual_index_bytes_and_absences_unchanged'],'captured_before_first_auditor_git_read':True,'root_earliest_read_interval_closed':initial['closed'],'screener_snapshot_timing_caveat':attestation['index_snapshot_timing_caveat'],'no_index_restore':True},'checks':checks,'all_checks_closed':all(c['passed'] for c in checks),'unclosed_checks':[c for c in checks if not c['passed']],'evidence':[desc(path) for path in refs],'limitations':['Claims concern this supplied predeclared run. Once-only controller/meter/markers and retained ordered artifacts do not prove the absence of unrelated global process launches.','Exposure fields are bounded original-role attestations supported by control flow and retained evidence; no global operating-system access log or hostile-process isolation proof was supplied.','Full original target/profile and prepared-runtime executable, qualified stdlib, pinned distribution file rows, plugin identities were compared offline to receipts and current bytes. Retained implementation/version/base_prefix claims were checked for internal consistency without executing the target interpreters. Stdlib walks and package RECORD scopes retain their original documented bounds.','Nested setup/case/controller wall measurements are nonadditive. Native counters exclude metadata transport and runtime-preflight subprocesses. Historical qualification/profile preparation costs remain in their original receipts; full engineering/model/tool lifecycle cost is UNKNOWN.','The original screener captured only its active index around screening. This auditor independently captures common/current/all linked actual index bytes around its own reads. Root task-start all-index receipts cover the earlier initial Git-read interval at an older authorized HEAD, not an uninterrupted all-index proof through later intentional commits.','The controller uses unchanged PASS/FAIL eligibility; zero eligible cases means role finalization remains a screening shortfall. Passing this audit qualifies the retained negatives and does not qualify developmental G2 or predict admission after any missing scope condition changes.']}
write(B/'AUDIT.json',result)
summary=('Status: '+result['status']+'\n'
 'Six frozen cases screened once in fixed order; 0 eligible; 1 collection; 0 native executions.\n'
 'Controller wall: 85.05430250600057 s; nested case wall sum: 43.36143939899921 s.\n'
 'First actual obstruction: ModuleNotFoundError: No module named chardet._version, from original src/chardet/__init__.py:15 during collection.\n'
 'Hatch VCS generates ignored src/chardet/_version.py into the baseline build/wheel; the tracked-only execution world omits it and precedes the installed wheel. Missing scope condition: every required import-time generated artifact must be represented by the pre-existing qualified source-world operation.\n'
 '34 JUnit collection errors, pytest exit 2, zero native executions; all other metadata/profile refusals and helper negatives retained.\n'
 'Pool SHA256: '+result['pool_sha256']+'\nReports canonical SHA256: '+result['reports_sha256']+'\n'
 'Owned HEAD '+HEAD+' and all common/current/linked raw index bytes unchanged across independent audit; indexes never restored.\n'
 'Original screening exposure claims are bounded actor attestations; postexperiment diagnostics occurred after all cases were ineligible. G2-G6 remain UNKNOWN.\n')
(B/'SUMMARY.txt').write_text(summary)
print(json.dumps({'status':result['status'],'audit':desc(B/'AUDIT.json'),'summary':desc(B/'SUMMARY.txt'),'unclosed_checks':result['unclosed_checks'],'post_index_closed':index['all_actual_index_bytes_and_absences_unchanged'],'no_further_git_reads_by_auditor':True},indent=2))
