"""Offline audit of retained case runtime and full raw obstruction logs. No target imports/runs."""
from pathlib import Path
import hashlib, json, re, os, importlib.util, xml.etree.ElementTree as ET, zipfile
OUT=Path('/workspace/qualification/native-authority-v42-screening-audit/runtime-identity')
SEALED=Path('/workspace/qualification/native-authority-v42-screening-sealed')
REPO=Path('/workspace/udm-v54')
checks=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def load(p):return json.loads(Path(p).read_bytes())
def ref(p):
 p=Path(p);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':sha(d)}
def check(n,a,e=True):checks.append({'name':n,'verified':a==e,'actual':a,'expected':e})
def write(n,v):
 p=OUT/n;p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');return ref(p)
spec=importlib.util.spec_from_file_location('retained_filesystem_audit',OUT/'audit_runtime_filesystem.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
inv=load(SEALED/'case-000.RUNTIME_INVENTORY.json')
cat=load(REPO/'research/unified_consequence_runtime/archaeology/native-authority-v41/ENVIRONMENT_CATALOG.json')
profiles={p['id']:p for p in cat['profiles']}
raw=[];cases=[]
controller=Path('/workspace/qualification/native-authority-v42-screening-controller')
prep=Path('/workspace/qualification/native-authority-v41-profile-preparation')
check('controller original runtime paths equal original preparation',load(controller/'RUNTIMES.original.json'),load(prep/'RUNTIMES.json'))
for filename in ['PREPARATION.json','PREPARATION_INITIAL.json','INDEPENDENT_PACKAGE_EXTENSION_AUDIT.json','GIT_READBACK.json','INPUT_RUNTIMES.json']:
 check('controller original preparation receipt bytes: '+filename,(controller/'original-profile-preparation-receipts'/filename).read_bytes(),(prep/filename).read_bytes())
for i in range(6):
 case=SEALED/f'case-{i:03}'; j=load(case/'SCREENING_CASE.json'); adm=load(case/'source-environment/admission-v42.json'); sel=load(case/'source-environment/selection.json')
 # Read and hash all complete retained logs, receipt/config/environment JSON, requirements,
 # and relevant original metadata source/config; no target interpreter or source execution.
 for p in sorted(case.rglob('*')):
  if not p.is_file() or '/.git/' in str(p) or '/venv/' in str(p) or '/base-build/' in str(p):continue
  rel=p.relative_to(case)
  if p.suffix in {'.log','.json','.xml'} or p.name in {'pinned-requirements.txt','pyproject.toml','setup.py','setup.cfg','tox.ini','pytest.ini','requirements.txt','test-requirements.txt','test_requirements.txt'}:
   raw.append(ref(p))
 cases.append({'index':i,'repository':j['repository'],'status':j['status'],'reason':j.get('reason'),'setup_status':adm['status'],'setup_reason':adm.get('reason'),'selection_status':sel['status'],'selection_reason':sel['reason'],'constraints_reasons':sel['constraints']['reasons'],'candidates':sel['candidates'],'case_receipt':ref(case/'SCREENING_CASE.json'),'admission_receipt':ref(case/'source-environment/admission-v42.json'),'selection_receipt':ref(case/'source-environment/selection.json')})
 check(f'case-{i:03} ineligible',j['eligible'],False)
 check(f'case-{i:03} selection nested equals separate',adm['selection'],sel)
raw_ref=write('RAW_CONFIG_ENV_REFUSAL_LOG_MANIFEST.json',raw)
c=SEALED/'case-000'; n=c/'source-environment/native'; sel=load(c/'source-environment/selection.json'); profile=sel['selected_profile'];env=load(n/'environment.json')
expected_runtime=inv['runtimes'][profile['id']]
check('native environment executable bytes equal original runtime',mod.file_hash(env['executable']),expected_runtime['identity']['executable_sha256'])
check('native environment recorded executable bytes',env['executable_sha256'],expected_runtime['identity']['executable_sha256'])
check('native environment full runtime identity equals original',env['runtime_identity'],expected_runtime['identity'])
rows,diagnostics=mod.source_walk(env['runtime_import_roots'])
check('native runtime complete source-equivalent stdlib rows',rows,expected_runtime['stdlib_files'])
packages=mod.package_inventory(env['executable'],profile)
retained_packages=load(c/'source-environment/pinned-package-files.json')
check('native installed exact pinned versions',packages['found'],packages['expected'])
check('native pinned file authority problems',packages['problems'],[])
check('native current full pinned package rows vs source receipt',packages['rows'],retained_packages)
check('native pinned canonical manifest receipt',sha(canonical(retained_packages)),load(c/'source-environment/admission-v42.json')['pinned_packages_sha256'])
check('native installed names exactly pins plus original project',packages['all_found'],sorted([*map(list,packages['expected'].items()),['chardet','7.4.2.dev1+gea7e547aa']]))
plugins,builtin=mod.static_plugins(profile,packages)
checks.extend(mod.CHECKS)
check('native plugin complete source file identities',plugins,load(n/'plugin-identity.json'))
pkg_ref=write('NATIVE_HOST_PINNED_PACKAGE_FILES.json',packages['rows'])
stdlib_ref=write('NATIVE_HOST_STDLIB_FILES.json',rows)
report=load(c/'collection/report.json');checked=load(c/'collection/checked-report.json');junit=ET.fromstring((c/'collection/native.xml').read_bytes()); errors=junit.findall('.//error'); suites=junit.findall('testsuite')
check('actual native collection exit',report['exit_code'],2);check('actual collection process exit',checked['process_exit_code'],2);check('actual JUnit collection errors',len(errors),34);check('no executed call reports',report['reports'],[])
check('all JUnit errors are same absent generated version artifact',all("ModuleNotFoundError: No module named 'chardet._version'" in e.text for e in errors))
check('collection XML and checked report error counts',len(errors),len(checked['collection_errors']))
check('raw collection stderr retained empty',(c/'collection/stderr.log').read_bytes(),b'')
check('collection no source mutations',checked['source_mutations'],[]);check('collection no external project imports',checked['external_project_imports'],[]);check('collection no unexpected imports',checked['unexpected_imports'],[]);check('collection no plugin violations',checked['plugin_violations'],[]);check('collection no changed test code',checked['changed_test_code'],[])
version_path='src/chardet/_version.py'; source_missing=not(n/'source'/version_path).exists(); build=(n/'base-build'/version_path).read_bytes();installed=(n/'venv/lib/python3.12/site-packages/chardet/_version.py').read_bytes();wheel=load(n/'native-wheel.json')
check('original tracked source lacks generated version file',source_missing);check('build and installed generated version bytes equal',build,installed);check('retained native wheel bytes',sha(Path(wheel['path']).read_bytes()),wheel['sha256'])
with zipfile.ZipFile(wheel['path']) as z:
 wversion=z.read('chardet/_version.py');check('original baseline wheel generated version bytes equal installed',wversion,installed)
source_refs=[ref(REPO/'research/unified_consequence_runtime'/s) for s in ['native_environment_selection_v3.py','native_environment_selection_v41.py','native_environment_v41.py','native_environment_v42.py','native_execution_v2.py','native_admission_v2.py']]
first=errors[0].text
obstruction={
 'case_index':0,'repository':'chardet/chardet','stage':'original native pytest collection','status':'UNKNOWN_COLLECTION_ERROR','exact_exception':"ModuleNotFoundError: No module named 'chardet._version'",'first_junit_traceback':first,'all_junit_error_count':len(errors),'collected_test_count':len(report['collected_test_nodes']),'pytest_exit_code':report['exit_code'],'native_execution_calls':0,
 'necessary_diagnostic_reason':'The original package imports the backend-generated src/chardet/_version.py at import time. That untracked file is generated during the original baseline wheel build and exists in base-build and the installed wheel, but is absent from the tracked-source contract. The qualified runner materializes only contract tracked files into world and places world/src before installed packages, so imports resolve the source package whose generated version module is absent.',
 'missing_preexisting_scope_condition':'Source-world admission requires every import-time runtime file to be present among the tracked source contract, or otherwise represented by an already qualified generic generated-artifact operation. This case has an untracked Hatch VCS build-generated file; its generation is represented only in the baseline wheel build, not in the source-world materialization operation. No repair, retry, extra artifact projection, or changed method was performed.',
 'evidence':{'raw_stdout':ref(c/'collection/stdout.log'),'raw_stderr':ref(c/'collection/stderr.log'),'junit':ref(c/'collection/native.xml'),'raw_report':ref(c/'collection/report.json'),'checked_report':ref(c/'collection/checked-report.json'),'source_pyproject':ref(n/'source/pyproject.toml'),'source_init':ref(n/'source/src/chardet/__init__.py'),'source_gitignore':ref(n/'source/.gitignore'),'baseline_build_generated_version':ref(n/'base-build'/version_path),'installed_generated_version':ref(n/'venv/lib/python3.12/site-packages/chardet/_version.py'),'native_wheel':dict(wheel),'baseline_build_log':ref(n/'base-native-wheel.log'),'project_install_log':ref(n/'project.log')}}
negatives=[{'case_index':1,'exact_refusal':'UNKNOWN_DYNAMIC_METADATA: reimported setup authority binding','scope_condition':'The original setup.py has mutually exclusive setuptools.setup / distutils.core.setup imports under try/except. The frozen static AST grammar counts repeated setup authority imports without branch feasibility and refuses before extracting literal environment fields.','source':ref(SEALED/'case-001/source-environment/metadata-source/setup.py')},{'case_index':2,'exact_refusal':'UNKNOWN_NO_COMPATIBLE_PROFILE','scope_condition':'The legacy row lacks required pytest-cov; modern Python 3.12 is outside the finite declared classifier matrix. Neither frozen row satisfies the admitted constraints.'},{'case_index':3,'exact_refusal':'UNKNOWN_NO_COMPATIBLE_PROFILE','scope_condition':'Modern row lacks appdirs and more_itertools. Legacy row is below requires-python>=3.9 and also lacks requirements.'},{'case_index':4,'exact_refusal':'UNKNOWN_NO_COMPATIBLE_PROFILE','scope_condition':'Legacy row lacks mock and nose. Modern row is outside declared finite Python matrix and also lacks mock and nose.'},{'case_index':5,'exact_refusal':'UNKNOWN_DYNAMIC_METADATA: dynamic execution or namespace reflection in setup metadata scope','scope_condition':'The original setup.py reads tracked src/outcome/_version.py then execs its bytes into a dict. The frozen conservative AST operation rejects dynamic execution anywhere in setup metadata scope.','source':ref(SEALED/'case-005/source-environment/metadata-source/setup.py')},{'case_index':0,'classification':'additional frozen metadata/config scope limits, not the actual first exception','scope_condition':'The source uses [tool.pytest] TOML settings and dependency-groups.dev (including pytest>=9.0.2). The frozen config reader recognizes [tool.pytest.ini_options]; the environment operation recognizes only test/tests/testing dependency-group names. Thus the receipt contains empty ini_options and does not treat dev requirements as admission constraints. No claim is made that later collection would pass if the first exception were absent.'}]
# Bytes in expected/actual could be enormous and are captured separately: reduce successful equality values.
for ch in checks:
 if ch['verified']:
  for k in ['actual','expected']:
   v=ch[k]
   if isinstance(v,(bytes,list,dict)):
    ch[k]={'type':type(v).__name__,'length':len(v),'sha256':sha(v if isinstance(v,bytes) else canonical(v))}
 else:
  for k in ['actual','expected']:
   if isinstance(ch[k],bytes):ch[k]=repr(ch[k])
result={'schema':'V42_INDEPENDENT_OFFLINE_CASE_RUNTIME_AND_RAW_OBSTRUCTION_AUDIT_V1','status':'PASS_RETAINED_RUNTIME_AND_DIAGNOSTIC_EVIDENCE' if all(x['verified'] for x in checks) else 'UNKNOWN_RUNTIME_OR_DIAGNOSTIC_CHECK','checks_count':len(checks),'checks_verified':sum(x['verified'] for x in checks),'failed_checks':[x for x in checks if not x['verified']],'checks':checks,'cases':cases,'first_actual_collection_obstruction':obstruction,'other_retained_negative_findings':negatives,'runtime':{'selected_profile':profile['id'],'executable_sha256':env['executable_sha256'],'stdlib_file_count':len(rows),'pinned_packages':len(packages['rows']),'pinned_package_files':sum(len(x[2]) for x in packages['rows']),'plugins':plugins,'stdlib_manifest':stdlib_ref,'package_manifest':pkg_ref},'raw_log_and_config_manifest':raw_ref,'method_source_refs':source_refs,'audit_script':ref(Path(__file__)),'limitations':['No native collections/executions/retries, target-source imports, installs, Git operations, network requests, policy search, or method changes were performed.','Host filesystem identity verification uses exact executable/stdlib/package bytes and retained source receipts; implementation/version/base_prefix claims were compared for internal/catalog/source consistency, not independently queried by running target interpreters.','This audit qualifies screening negatives only; it supplies no developmental G2 evidence or evidence of future learner success.']}
r=write('CASE_RUNTIME_AND_OBSTRUCTION_AUDIT.json',result)
print(json.dumps({'report':r,'status':result['status'],'checks_count':len(checks),'checks_verified':result['checks_verified'],'failed_checks':result['failed_checks'],'raw_files_read_completely':len(raw),'first_obstruction':obstruction['exact_exception']}))
