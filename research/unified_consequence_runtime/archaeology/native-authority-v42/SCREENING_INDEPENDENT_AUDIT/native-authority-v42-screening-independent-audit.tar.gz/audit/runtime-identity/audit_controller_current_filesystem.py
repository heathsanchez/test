"""Bounded current controller filesystem capture only; no controller launch/import."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, re
OUT=Path('/workspace/qualification/native-authority-v42-screening-audit/runtime-identity')
VENV=Path('/workspace/qualification/native-authority-v42-controller')
START=Path('/workspace/qualification/native-authority-v42-start-20261021')
CONTROLLER=Path('/workspace/qualification/native-authority-v42-screening-controller')
def sha(d):return hashlib.sha256(d).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def ref(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(name,value):
 p=OUT/name;p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');return ref(p)
spec=importlib.util.spec_from_file_location('offline_filesystem_helpers',OUT/'audit_runtime_filesystem.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
checks=[]
def check(n,a,e=True):checks.append({'name':n,'verified':a==e,'actual':a,'expected':e})
cfg_raw=(VENV/'pyvenv.cfg').read_text();cfg=dict(line.split(' = ',1) for line in cfg_raw.splitlines() if ' = ' in line)
exe=VENV/'bin/python';chain=[];current=exe
while current.is_symlink():
 dest=os.readlink(current);chain.append({'path':str(current),'link_text':dest});current=(current.parent/dest).absolute() if not Path(dest).is_absolute() else Path(dest)
base=exe.resolve().parent.parent
roots=[VENV/'lib/python3.12',base/'lib/python3.12',base/'lib/python3.12/lib-dynload']
stdlib,root_diagnostics=mod.source_walk([str(p) for p in roots]);stdlib_ref=write('CONTROLLER_CURRENT_STDLIB_FILES.json',stdlib)
profile={'python_version':'3.12.14','packages':['pip==25.0.1','pytest==8.3.5','packaging==26.3','pluggy==1.7.0','iniconfig==2.3.1']}
pkgs=mod.package_inventory(exe,profile);package_ref=write('CONTROLLER_CURRENT_PINNED_PACKAGE_FILES.json',pkgs['rows'])
check('current exact controller package versions',pkgs['found'],pkgs['expected']);check('current distribution pairs exactly current declared set',pkgs['all_found'],sorted(map(list,pkgs['expected'].items())));check('current package file authority/readability',pkgs['problems'],[])
# Capture complete current venv filesystem, including files outside RECORD and symlink text.
all_files=[];walk_errors=[]
for folder,dirs,files in os.walk(VENV,onerror=lambda e:walk_errors.append(str(e)),followlinks=False):
 for d in list(dirs):
  p=Path(folder,d)
  if p.is_symlink():all_files.append({'path':str(p.relative_to(VENV)),'kind':'symlink-directory','link_text':os.readlink(p),'resolved':str(p.resolve())})
 for name in files:
  p=Path(folder,name);row={'path':str(p.relative_to(VENV)),'mode':oct(p.lstat().st_mode&0o777)}
  if p.is_symlink():row.update(kind='symlink-file',link_text=os.readlink(p),resolved=str(p.resolve()))
  else:row['kind']='file'
  if p.is_file():row.update(bytes=p.stat().st_size,sha256=mod.file_hash(p))
  all_files.append(row)
all_files.sort(key=lambda r:r['path']);full_ref=write('CONTROLLER_CURRENT_FULL_VENV_FILES.json',all_files);check('full current controller venv walk without errors',walk_errors,[])
log=START/'controller-install.log';log_text=log.read_text();success=[line for line in log_text.splitlines() if line.startswith('Successfully installed ')]
check('retained historical install success line count',len(success),1)
historical={}
if success:
 for token in success[0].removeprefix('Successfully installed ').split():
  name,version=token.rsplit('-',1);historical[mod.canonical_name(name)]=version
check('historical install packages match requested retained versions',historical,{'iniconfig':'2.3.1','packaging':'26.3','pluggy':'1.7.0','pytest':'8.3.5'})
check('current package versions agree with retained install log subset',{k:pkgs['found'].get(k) for k in historical},historical)
original_inv=json.loads(Path('/workspace/qualification/native-authority-v42-screening-sealed/case-000.RUNTIME_INVENTORY.json').read_bytes());modern=original_inv['runtimes']['cpython-3.12.14-pytest-8.4.1-linux-x86_64'];exe_sha=mod.file_hash(exe)
check('current controller executable SHA256 matches modern native profile',exe_sha,modern['identity']['executable_sha256'])
check('pyvenv metadata source executable matches resolved current executable',cfg['executable'],str(exe.resolve()))
check('pyvenv metadata version agrees with native modern version claim',cfg['version'],'.'.join(map(str,modern['identity']['version_info'][:3])))
# Compare per-relative-path byte identity separately from absolute-root provenance.
def relative_manifest(rows,root):
 root=Path(root).resolve();out=[]
 for p,h in rows:
  try:relative=str(Path(p).relative_to(root))
  except ValueError:continue
  out.append([relative,h])
 return sorted(out)
modern_root=Path(modern['identity']['base_prefix'])/'lib/python3.12';modern_relative=relative_manifest(modern['stdlib_files'],modern_root);controller_relative=relative_manifest(stdlib,base/'lib/python3.12')
comparison={'native_modern_stdlib_relative_file_count':len(modern_relative),'controller_base_stdlib_relative_file_count':len(controller_relative),'relative_manifests_equal':controller_relative==modern_relative,'native_modern_relative_manifest_sha256':sha(canon(modern_relative)),'controller_relative_manifest_sha256':sha(canon(controller_relative))}
# A difference is retained as current identity evidence, not hidden or retroactively changed.
if controller_relative!=modern_relative:
 m=dict(modern_relative);c=dict(controller_relative);comparison.update(missing_in_controller=sorted(set(m)-set(c)),extra_in_controller=sorted(set(c)-set(m)),changed=[p for p in sorted(set(m)&set(c)) if m[p]!=c[p]])
searched=[];prelaunch=[]
for root in [START,CONTROLLER,VENV]:
 names=sorted(p.name for p in root.iterdir());searched.append({'directory':str(root),'direct_children':names})
 if root!=VENV:
  prelaunch.extend(str(p) for p in root.iterdir() if p.is_file() and re.search(r'(controller.*(?:inventory|stdlib|package.*file)|(?:inventory|stdlib|package.*file).*controller)',p.name,re.I))
report={'schema':'V42_CONTROLLER_CURRENT_FILESYSTEM_IDENTITY_RECEIPT_V1','status':'PASS_BOUNDED_CURRENT_CONTROLLER_FILESYSTEM_RECEIPT' if all(c['verified'] for c in checks) else 'UNKNOWN_CONTROLLER_CURRENT_FILESYSTEM_CHECK','captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence_temporality':'POST_EXPERIMENT_CURRENT_FILESYSTEM_ONLY','controller_venv':str(VENV),'pyvenv_cfg':dict(ref(VENV/'pyvenv.cfg'),parsed=cfg),'executable':{'path':str(exe),'symlink_chain':chain,'resolved':str(exe.resolve()),'sha256':exe_sha,'modern_profile_interpreter':modern['interpreter'],'modern_profile_executable_sha256':modern['identity']['executable_sha256']},'stdlib':{'roots_inferred_from_current_pyvenv_and_standard_layout':[str(p) for p in roots],'root_diagnostics':root_diagnostics,'files':len(stdlib),'manifest':stdlib_ref,'manifest_canonical_sha256':sha(canon(stdlib)),'comparison_to_original_modern_profile_by_relative_path':comparison},'packages':{'current_declared_set':profile['packages'],'installed_name_version_pairs':pkgs['all_found'],'distribution_count':len(pkgs['rows']),'package_file_count':sum(len(r[2]) for r in pkgs['rows']),'full_package_file_manifest':package_ref,'package_file_manifest_canonical_sha256':sha(canon(pkgs['rows'])),'metadata_and_RECORD_included':True,'historical_install_log':ref(log),'historical_success_line':success[0] if success else None,'historically_logged_versions':historical,'pip_25_0_1_scope':'Current venv bootstrap package; controller-install.log does not attest its historical bytes or version.'},'full_current_venv_manifest':full_ref,'checks_count':len(checks),'checks_verified':sum(c['verified'] for c in checks),'failed_checks':[c for c in checks if not c['verified']],'checks':checks,'prelaunch_controller_file_inventory':{'status':'UNKNOWN_NOT_SUPPLIED_IN_BOUNDED_EVIDENCE','bounded_filename_search':searched,'matching_current_candidates':prelaunch,'limitation':'No full prelaunch controller executable/stdlib/pinned-package file inventory was found among direct retained controller/start evidence. The historical install log establishes recorded package versions and success, not historical file bytes. This current receipt cannot establish that every controller byte equalled its prelaunch byte.'},'actions':{'controller_or_native_runtime_launched':False,'target_source_or_packages_imported':False,'existing_runtime_checks_reexecuted':False,'native_collection_or_execution_rerun':False,'network_used':False,'production_or_evidence_modified':False},'limitations':['Current stdlib roots are inferred from pyvenv.cfg and conventional Python 3.12 layout; no controller launch or sysconfig/runtime import-resolution probe occurred.','Full current package rows read distribution metadata/RECORD without importing target packages. Full current venv manifest additionally captures unlisted files and symlink text.','This is a bounded postexperiment controller receipt; it does not upgrade the historical evidence to a full prelaunch controller-byte inventory.'],'audit_script':ref(Path(__file__))}
r=write('CONTROLLER_CURRENT_FILESYSTEM_IDENTITY.json',report)
print(json.dumps({'report':r,'status':report['status'],'checks_count':len(checks),'checks_verified':report['checks_verified'],'failed_checks':report['failed_checks'],'stdlib_files':len(stdlib),'package_files':sum(len(r[2]) for r in pkgs['rows']),'full_venv_entries':len(all_files),'stdlib_comparison':comparison}))
