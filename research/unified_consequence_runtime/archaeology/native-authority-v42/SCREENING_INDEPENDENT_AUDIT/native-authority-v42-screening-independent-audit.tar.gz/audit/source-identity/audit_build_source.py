"""Read-only consistency audit for original tracked build source and generated version artifact."""
from pathlib import Path
import os,stat,json,hashlib,zipfile,tomllib,ast
ROOT=Path('/workspace/qualification/native-authority-v42-screening-audit/source-identity')
NATIVE=Path('/workspace/qualification/native-authority-v42-screening-sealed/case-000/source-environment/native')
CHECKS=[];INPUTS={}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();INPUTS[str(p)]={'sha256':sha(b),'bytes':len(b)};return b
def check(name,cond):
 CHECKS.append({'check':name,'passed':bool(cond)})
 if not cond:raise AssertionError(name)
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
bound=json.loads(read(NATIVE/'source-boundaries.json'));manifest=bound['base_manifest'];base=NATIVE/'base-build'
for row in manifest:
 p=base/row['path'];s=p.lstat();body=read(p)
 check('tracked_base_build_exact:'+row['path'],stat.S_ISREG(s.st_mode) and ('100755' if s.st_mode&0o111 else '100644')==row['mode'] and sha(body)==row['sha256'] and oid(body)==row['blob'])
tracked={r['path'] for r in manifest};allfiles=[]
for p in base.rglob('*'):
 rel=p.relative_to(base)
 if '.git' in rel.parts:continue
 if p.is_file() or p.is_symlink():allfiles.append(rel.as_posix())
extras=sorted(set(allfiles)-tracked)
config=tomllib.loads(read(base/'pyproject.toml').decode());generated=config['tool']['hatch']['build']['hooks']['vcs']['version-file']
check('only_build_generated_file_extra',extras==[generated])
check('generated_version_gitignored',generated in read(base/'.gitignore').decode().splitlines())
body=read(base/generated)
check('generated_file_absent_raw_contract',not (NATIVE/'source'/generated).exists())
check('generated_file_absent_raw_metadata',not (NATIVE.parent/'metadata-source'/generated).exists())
imports=ast.parse(read(NATIVE/'source/src/chardet/__init__.py'))
check('original_source_requires_generated_module',any(isinstance(n,ast.ImportFrom) and n.module=='chardet._version' and any(a.name=='__version__' for a in n.names) for n in imports.body))
wheels=list((NATIVE/'wheels').glob('*.whl'));check('one_original_built_wheel',len(wheels)==1)
wheel=read(wheels[0]);version_name=generated.removeprefix('src/')
with zipfile.ZipFile(wheels[0]) as z:
 wheel_version=z.read(version_name)
 check('wheel_generated_version_matches_build',wheel_version==body)
result={'schema':'UDM_V42_BASE_BUILD_GENERATED_SOURCE_AUDIT_V1','status':'PASS','checks':CHECKS,'tracked_production_and_all_original_build_files_unchanged':True,'untracked_generated_build_files':extras,'generated_version':{'path':generated,'sha256':sha(body),'bytes':len(body),'declared_hatch_vcs_hook':True,'gitignored':True,'present_in_base_build':True,'present_in_built_wheel':True,'absent_raw_contract_source':True,'absent_raw_metadata_source':True},'wheel':{'path':str(wheels[0]),'sha256':sha(wheel),'bytes':len(wheel)},'inputs':INPUTS,'boundary':{'target_code_executed':False,'network_calls':0,'git_commands':0,'writes':'this audit directory only'},'interpretation':'Original base wheel build created the declared ignored chardet/_version.py artifact. The tracked-only contract source omits it while original package import requires it; collection evidence determines the actual import scope and earliest failure. No frozen-experiment change or repair was performed.'}
(ROOT/'BUILD_SOURCE_AUDIT.json').write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
print(json.dumps({'status':result['status'],'checks':len(CHECKS),'extras':extras,'generated_sha256':sha(body)}))
