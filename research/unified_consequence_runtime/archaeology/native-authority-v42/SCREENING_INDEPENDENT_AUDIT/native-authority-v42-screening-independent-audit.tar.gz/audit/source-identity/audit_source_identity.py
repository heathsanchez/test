"""Offline audit: read retained source and Git bytes, execute no retained code.

No subprocess, Git command, network call, import of source-under-audit, extraction,
or write outside this audit directory is used. Git objects are decoded as data.
"""
import ast
import base64
import configparser
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import sys
import tomllib
import zlib

# Use only the generic retained dependency, under this audit interpreter.
# Do not launch the controller interpreter or import any controller/project code.

ROOT = Path('/workspace/qualification/native-authority-v42-screening-audit/source-identity')
META = ROOT/'metadata-preaudit'
RAW = ROOT/'raw-audit'
SEALED = Path('/workspace/qualification/native-authority-v42-screening-sealed')
COMMIT = 'c56d29fae856cceaa0a00000b1c3b782ea1df346'
CODE = META/'source-binding/gate-files'/COMMIT/'research/unified_consequence_runtime'
CHECKS = []
INPUTS = {}

def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def fp(v): return sha(canonical(v).encode())
def oid(kind,b): return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def check(name,condition,detail=None):
    CHECKS.append({'check':name,'passed':bool(condition),**({'detail':detail} if detail is not None else {})})
    if not condition: raise AssertionError(name)
def read(p):
    p=Path(p);b=p.read_bytes();INPUTS[str(p)]={'sha256':sha(b),'bytes':len(b)};return b
def js(p): return json.loads(read(p))
def u32(b,i): return struct.unpack_from('>I',b,i)[0]

class Objects:
    """Read SHA-1 Git pack v2/3 and idx v2; validate every resolved object ID."""
    def __init__(self,git):
        self.git=git;self.locations={};self.packs={};self.cache={};self.offset_cache={};self.pack_records=[];self.duplicates=[]
        for idx in sorted((git/'objects/pack').glob('*.idx')):
            b=read(idx);check('idx_v2:'+str(idx),b[:8]==b'\xfftOc\0\0\0\2')
            check('idx_checksum:'+str(idx),hashlib.sha1(b[:-20]).digest()==b[-20:])
            n=u32(b,8+255*4);start=8+256*4;names=[b[start+20*i:start+20*(i+1)].hex() for i in range(n)]
            offsets_start=start+n*20+n*4;large_start=offsets_start+n*4
            pack=idx.with_suffix('.pack');data=read(pack)
            check('pack_header:'+str(pack),data[:4]==b'PACK' and u32(data,4) in (2,3) and u32(data,8)==n)
            check('pack_checksum:'+str(pack),hashlib.sha1(data[:-20]).digest()==data[-20:]==b[-40:-20])
            check('pack_name:'+str(pack),pack.stem=='pack-'+data[-20:].hex())
            self.packs[str(pack)]=data
            for i,name in enumerate(names):
                pos=u32(b,offsets_start+i*4)
                if pos&0x80000000:pos=struct.unpack_from('>Q',b,large_start+(pos&0x7fffffff)*8)[0]
                location=(str(pack),pos)
                if name in self.locations:self.duplicates.append((name,location))
                else:self.locations[name]=location
            self.pack_records.append({'pack':str(pack),'sha256':sha(data),'objects':n,'pack_sha1':data[-20:].hex()})
        for directory in (git/'objects').iterdir():
            if re.fullmatch('[0-9a-f]{2}',directory.name) and directory.is_dir():
                for p in directory.iterdir():
                    if re.fullmatch('[0-9a-f]{38}',p.name):
                        name=directory.name+p.name
                        if name in self.locations:self.duplicates.append((name,p))
                        else:self.locations[name]=p
    def get(self,name):
        if name in self.cache:return self.cache[name]
        loc=self.locations[name]
        if isinstance(loc,Path):
            raw=zlib.decompress(read(loc));header,body=raw.split(b'\0',1);kind,size=header.decode().split()
            check('loose_object_size:'+name,len(body)==int(size));answer=(kind,body)
        else:answer=self.at(*loc)
        check('object_sha1:'+name,oid(*answer)==name)
        self.cache[name]=answer;return answer
    def at(self,pack,offset):
        key=(pack,offset)
        if key in self.offset_cache:return self.offset_cache[key]
        b=self.packs[pack];pos=offset;c=b[pos];pos+=1;typ=(c>>4)&7;size=c&15;shift=4
        while c&128:
            c=b[pos];pos+=1;size|=(c&127)<<shift;shift+=7
        base=None
        if typ==6:
            c=b[pos];pos+=1;distance=c&127
            while c&128:
                c=b[pos];pos+=1;distance=((distance+1)<<7)+(c&127)
            base=self.at(pack,offset-distance)
        elif typ==7:
            name=b[pos:pos+20].hex();pos+=20;base=self.get(name)
        d=zlib.decompressobj();body=d.decompress(b[pos:]);check('packed_object_size:'+pack+':'+str(offset),d.eof and len(body)==size)
        if base is not None:
            q=0
            def varint():
                nonlocal q
                value=0;shift=0
                while True:
                    c=body[q];q+=1;value|=(c&127)<<shift
                    if not c&128:return value
                    shift+=7
            source_size=varint();target_size=varint();check('delta_base_size',source_size==len(base[1]));parts=[]
            while q<len(body):
                cmd=body[q];q+=1
                if cmd&128:
                    start=count=0
                    for bit in range(4):
                        if cmd&(1<<bit):start|=body[q]<<(8*bit);q+=1
                    for bit in range(3):
                        if cmd&(1<<(4+bit)):count|=body[q]<<(8*bit);q+=1
                    count=count or 0x10000;piece=base[1][start:start+count];check('delta_copy_bound',len(piece)==count);parts.append(piece)
                else:
                    check('delta_nonzero_insert',cmd!=0);parts.append(body[q:q+cmd]);q+=cmd
            answer=(base[0],b''.join(parts));check('delta_target_size',len(answer[1])==target_size)
        else:
            check('supported_pack_type',typ in (1,2,3,4));answer=({1:'commit',2:'tree',3:'blob',4:'tag'}[typ],body)
        self.offset_cache[key]=answer;return answer
    def tree(self,name,prefix=''):
        kind,b=self.get(name);check('tree_object:'+name,kind=='tree');out=[];pos=0
        while pos<len(b):
            end=b.index(b'\0',pos);mode,leaf=b[pos:end].split(b' ',1);child=b[end+1:end+21].hex();pos=end+21
            leaf=leaf.decode('utf-8');path=prefix+leaf
            check('canonical_tree_path:'+path,bool(path) and '\\' not in path and '..' not in PurePosixPath(path).parts and PurePosixPath(path).as_posix()==path)
            if mode==b'40000':out.extend(self.tree(child,path+'/'))
            else:out.append({'path':path,'mode':mode.decode(),'blob':child})
        return out

def parse_index(p):
    b=read(p);check('index_header:'+str(p),b[:4]==b'DIRC' and u32(b,4) in (2,3));check('index_checksum:'+str(p),hashlib.sha1(b[:-20]).digest()==b[-20:]);pos=12;rows=[]
    for i in range(u32(b,8)):
        start=pos;mode=u32(b,pos+24);name=b[pos+40:pos+60].hex();flags=struct.unpack_from('>H',b,pos+60)[0];pos+=62
        if flags&0x4000:pos+=2
        end=b.index(b'\0',pos);path=b[pos:end].decode();pos=start+((end+1-start+7)//8)*8
        rows.append({'path':path,'mode':format(mode,'o'),'blob':name})
    return rows

def fs_tree(root,gitlinks):
    rows=[]
    def walk(directory,prefix=''):
        entries=[]
        for p in directory.iterdir():
            if p.name=='.git' and directory==root:continue
            st=p.lstat();name=prefix+p.name
            if name in gitlinks:
                row=gitlinks[name]
                check('unmaterialized_gitlink_empty_directory:'+name,stat.S_ISDIR(st.st_mode) and not list(p.iterdir()))
                rows.append({**row,'sha256':None})
                entries.append((p.name,b'160000 '+os.fsencode(p.name)+b'\0'+bytes.fromhex(row['blob'])))
            elif stat.S_ISDIR(st.st_mode):
                tree=walk(p,name+'/');entries.append((p.name+'/',b'40000 '+os.fsencode(p.name)+b'\0'+bytes.fromhex(tree)))
            elif stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode):
                symlink=stat.S_ISLNK(st.st_mode);raw=os.fsencode(os.readlink(p)) if symlink else read(p)
                mode='120000' if symlink else ('100755' if st.st_mode&0o111 else '100644');blob=oid('blob',raw)
                rows.append({'path':name,'mode':mode,'blob':blob,'sha256':sha(raw)})
                entries.append((p.name,mode.encode()+b' '+os.fsencode(p.name)+b'\0'+bytes.fromhex(blob)))
            else:raise AssertionError('unsupported_filesystem_kind:'+name)
        return oid('tree',b''.join(value for _,value in sorted(entries,key=lambda x:os.fsencode(x[0]))))
    tree=walk(root);return tree,rows

import tarfile
import posixpath

def archive_check(path,expected):
    raw=read(path);rows=[]
    with tarfile.open(path,'r:gz') as t:
        members=t.getmembers()
        for m in members:
            check('archive_safe_supported:'+str(path)+':'+m.name,(m.isfile() or m.issym()) and m.name==PurePosixPath(m.name).as_posix() and not m.name.startswith('/') and '..' not in PurePosixPath(m.name).parts)
            body=os.fsencode(m.linkname) if m.issym() else t.extractfile(m).read();mode='120000' if m.issym() else ('100755' if m.mode&0o111 else '100644')
            rows.append({'path':m.name,'mode':mode,'blob':oid('blob',body),'sha256':sha(body)})
    check('archive_exact_tracked_bytes_modes_paths:'+str(path),rows==[{k:r[k] for k in ('path','mode','blob','sha256')} for r in expected])
    return {'path':str(path),'sha256':sha(raw),'bytes':len(raw),'entry_count':len(rows),'exact_expected_manifest':True}

def audit_tree(source,base,expect_identity=None,only_base=False,head=None):
    git=source/'.git';check('local_git_directory:'+str(source),git.is_dir() and not git.is_symlink())
    check('no_git_alternates:'+str(source),not (git/'objects/info/alternates').exists() and not (git/'objects/info/http-alternates').exists())
    objects=Objects(git);kind,body=objects.get(base);check('commit_type:'+base,kind=='commit')
    tree=body.splitlines()[0].decode().removeprefix('tree ');rows=objects.tree(tree)
    idx=parse_index(git/'index');check('index_exact_tree:'+str(source),idx==sorted(rows,key=lambda x:x['path'].encode()))
    check('detached_head:'+str(source),read(git/'HEAD').decode().strip()==base)
    gitlinks={r['path']:r for r in rows if r['mode']=='160000'}
    fstree,fsrows=fs_tree(source,gitlinks);check('filesystem_full_tree_exact:'+str(source),fstree==tree)
    fsmap={r['path']:r for r in fsrows};check('filesystem_paths_exact:'+str(source),set(fsmap)=={r['path'] for r in rows})
    manifest=[]
    for row in rows:
        check('regular_source_mode:'+str(source)+':'+row['path'],row['mode'] in ('100644','100755','120000'))
        kind,raw=objects.get(row['blob']);check('source_blob_type:'+row['blob'],kind=='blob')
        check('filesystem_exact_blob_mode:'+str(source)+':'+row['path'],{k:fsmap[row['path']][k] for k in ('path','mode','blob')}==row and sha(raw)==fsmap[row['path']]['sha256'])
        manifest.append({**row,'sha256':sha(raw)})
    for name in list(objects.locations):objects.get(name)
    for name,location in objects.duplicates:
        if isinstance(location,Path):
            raw=zlib.decompress(read(location));header,body=raw.split(b'\0',1);kind,size=header.decode().split();answer=(kind,body)
            check('duplicate_loose_size:'+name,len(body)==int(size))
        else:answer=objects.at(*location)
        check('duplicate_object_identity:'+name,oid(*answer)==name and answer==objects.get(name))
    commits=sorted(name for name,(kind,body) in objects.cache.items() if kind=='commit')
    if only_base:check('only_base_commit:'+str(source),commits==[base])
    if head:check('protected_head_commit_absent:'+str(source),head not in objects.locations)
    raw_manifest_sha256=fp(manifest)
    for row in manifest:
        if row['mode']=='120000':
            target=objects.get(row['blob'])[1].decode('utf-8')
            resolved=posixpath.normpath(posixpath.join(posixpath.dirname(row['path']),target))
            check('observed_link_safe_regular_target:'+str(source)+':'+row['path'],not target.startswith('/') and not resolved.startswith('../') and resolved in fsmap and fsmap[resolved]['mode'] in ('100644','100755') and (source/row['path']).resolve()==source/resolved)
            row.update(target=target,resolved_path=resolved,content_sha256=fsmap[resolved]['sha256'])
    identity={'git_tree':tree,'tracked_tree_sha256':fp(manifest),'file_count':len(manifest)}
    if expect_identity:check('source_identity_exact:'+str(source),identity==expect_identity)
    return {'source_path':str(source),'commit':base,'source_identity':identity,'filesystem_tree':fstree,'raw_manifest_sha256':raw_manifest_sha256,'full_filesystem_exact':True,'tracked_entry_count':len(rows),'mode_counts':{m:sum(r['mode']==m for r in rows) for m in sorted({r['mode'] for r in rows})},'git_objects':len(objects.locations),'duplicate_object_representations':len(objects.duplicates),'all_git_objects_hash_validated':True,'commit_objects':commits,'head_commit_absent':head not in objects.locations if head else None,'packs':objects.pack_records,'index_sha256':sha(read(git/'index'))},manifest,objects

def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    pool_path=Path('/workspace/udm-v54/research/unified_consequence_runtime/archaeology/native-authority-v42/FROZEN_POOL.json');pool=js(pool_path)['pool'];cases=[]
    for i,spec in enumerate(pool):
        case_root=SEALED/f'case-{i:03d}';sr=case_root/'source-environment';ad=js(sr/'admission-v42.json');base=spec['base_commit'];head=spec['head_commit']
        detail,manifest,objects=audit_tree(sr/'metadata-source',base,ad['source_metadata_identity'],True,head)
        detail.update(index=i,repository=spec['repo'],metadata_archive=archive_check(sr/'metadata-source.tar.gz',manifest))
        check('base_tree_matches_frozen_metadata:'+str(i),detail['source_identity']['git_tree']==spec['git_metadata_binding']['base']['tree_sha'])
        for path,expected in spec['git_metadata_binding']['base']['changed_paths'].items():
            row=next(r for r in manifest if r['path']==path)
            check('frozen_base_changed_path_binding:'+str(i)+':'+path,row['blob']==expected['sha'] and row['mode']==expected['mode'] and len(objects.get(row['blob'])[1])==expected['size'])
        for path,expected in spec['git_metadata_binding']['head']['changed_paths'].items():
            old=spec['git_metadata_binding']['base']['changed_paths'].get(path)
            if old is None or old['sha']!=expected['sha']:
                check('metadata_head_changed_blob_absent:'+str(i)+':'+path,expected['sha'] not in objects.locations)
        native=sr/'native'
        if native.exists():
            check('native_only_case000:'+str(i),i==0)
            bound=js(native/'source-boundaries.json')
            check('base_manifest_receipt_exact',bound['base_manifest']==manifest)
            native_detail,augmented,native_objects=audit_tree(native/'source',bound['augmented_commit'],bound['augmented_identity'],False,head)
            check('base_commit_in_native_objects',native_objects.get(base)==objects.get(base))
            check('base_identity_receipt_exact',bound['base_identity']==ad['source_metadata_identity'])
            check('augmented_manifest_receipt_exact',augmented==bound['augmented_manifest'])
            a_map={r['path']:r for r in augmented};b_map={r['path']:r for r in manifest}
            changed=[p for p in a_map if a_map[p]!=b_map.get(p)]
            test_paths=[t['path'] for t in bound['author_tests']]
            check('only_original_author_tests_overlay',sorted(changed)==sorted(test_paths) and set(a_map)==set(b_map))
            test_details=[]
            for test in bound['author_tests']:
                path=test['path'];raw=read(native/'source'/path);transport=read(test['transport_json']);record=json.loads(transport);decoded=base64.b64decode(record['content'])
                pin=spec['git_metadata_binding']['head']['changed_paths'][path]
                check('test_transport_original_exact:'+path,decoded==raw and record['sha']==test['git_blob']==oid('blob',raw)==pin['sha'] and sha(raw)==test['sha256'] and len(raw)==test['bytes']==pin['size'] and sha(transport)==test['transport_sha256'])
                check('test_transport_ref_exact:'+path,test['endpoint'].endswith('?ref='+head) and record['path']==path)
                test_details.append({'path':path,'head_commit':head,'blob':oid('blob',raw),'sha256':sha(raw),'bytes':len(raw),'transport_sha256':sha(transport),'frozen_head_blob_pin_exact':True})
            prod=[f['filename'] for f in spec['files'] if f['filename'].endswith('.py') and not f['filename'].startswith('tests/')]
            for path in prod:
                check('production_path_preserved_base:'+path,a_map[path]==b_map[path])
                changed_head=spec['git_metadata_binding']['head']['changed_paths'][path]['sha']
                check('head_changed_production_blob_absent:'+path,changed_head not in native_objects.locations)
            check('head_production_receipt_false',bound['head_production_fetched'] is False and bound['production_preserved'] is True)
            detail['native']={**native_detail,'base_archive':archive_check(native/'base-source.tar.gz',manifest),'contract_archive':archive_check(native/'contract-source.tar.gz',augmented),'original_author_tests':test_details,'only_test_paths_changed':changed,'production_paths_preserved':prod,'head_changed_production_blobs_absent':True}
        else:
            check('metadata_only_no_native:'+str(i),ad['setup'] is None and ad['runtime'] is None)
            detail['native_materialized']=False
        cases.append(detail)
        (ROOT/f'case-{i:03d}.json').write_text(canonical(detail)+'\n')
        if native.exists():del native_objects
    result={'schema':'UDM_V42_PURE_FILESYSTEM_SOURCE_IDENTITY_AUDIT_V1','status':'PASS','auditor_source_sha256':sha(Path(__file__).read_bytes()),'reused_generic_git_decoder_from':'/workspace/qualification/native-authority-v41-screening-audit/raw-audit/audit_source_identity.py','cases':cases,'checks':CHECKS,'check_count':len(CHECKS),'all_checks_passed':all(c['passed'] for c in CHECKS),'inputs':INPUTS,'boundary':{'git_commands':0,'network_calls':0,'native_calls':0,'target_source_executed':False,'original_selector_executed':False,'writes':'/workspace/qualification/native-authority-v42-screening-audit/source-identity only'},'limitations':['Raw Git object identity, pack/index checksums and worktree equality establish retained consistency, not remote authenticity independently of retained transport evidence.','Metadata-only refusals did not prepare test overlays or native environments, so no original author-test bytes were fetched or examined for those five cases.']}
    (ROOT/'SOURCE_IDENTITY_AUDIT.json').write_text(canonical(result)+'\n')
    print(canonical({'status':result['status'],'cases':len(cases),'checks':len(CHECKS),'case_summaries':[{'index':c['index'],'repository':c['repository'],'files':c['tracked_entry_count'],'objects':c['git_objects'],'native':bool(c.get('native'))} for c in cases]}))

if __name__=='__main__':main()
