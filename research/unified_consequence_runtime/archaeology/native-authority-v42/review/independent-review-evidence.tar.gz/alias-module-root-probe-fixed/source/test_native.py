import pluggy
def test_old(): assert True
def test_new(): assert pluggy.__name__ == "pluggy"
