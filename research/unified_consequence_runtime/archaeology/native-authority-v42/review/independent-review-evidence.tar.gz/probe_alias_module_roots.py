from pathlib import Path
import json,os,subprocess,sys,time
from research.unified_consequence_runtime import native_execution_v42 as w
out=Path('/workspace/qualification/native-authority-v42-independent-review/alias-module-root-probe');out.mkdir(exist_ok=False)
repo=out/'source';(repo/'src').mkdir(parents=True)
(repo/'target.py').write_text('VALUE = 42\n')
(repo/'src/pluggy.py').symlink_to('../target.py')
(repo/'test_native.py').write_text('def test_old(): assert True\n')
(repo/'pytest.ini').write_text('[pytest]\naddopts=--import-mode=importlib\n')
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(repo),*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),stderr=subprocess.PIPE).decode().strip()
def commit():
 git('add','.');git('-c','user.name=Review Fixture','-c','user.email=fixture@example.invalid','commit','-qm','source fixture');return git('rev-parse','HEAD')
git('init','-q');base=commit()
(repo/'test_native.py').write_text('import pluggy\ndef test_old(): assert True\ndef test_new(): assert pluggy.__name__ == "pluggy"\n');head=commit()
env=w.environment_identity(sys.executable)
contract={'schema':w.SCHEMA,'repository':'fixture/alias-root','repo_path':str(repo),'commit':head,**w.original.source_identity(repo,head),'interpreter':sys.executable,'environment_sha256':w.fingerprint(env),'protocol_binding':'a'*64,'horizon_seconds':15}
authority=w.admission.derive_suite_contract(repo,base,head,'a'*64,repository=contract['repository'])
policy={'schema':w.POLICY_SCHEMA,'collection_seconds':15,'execution_seconds':15,'pytest_version':env['pytest_version'],'plugins':[]}
context={'contract':contract,'authority':authority,'policy':policy,'file_roots':w._roots(w.original._snapshot(repo,head)[1])}
(out/'CONTEXT.json').write_text(w.canonical(context)+'\n')
try:
 cert=w.collect(contract,authority,out/'collection',policy=policy)
 result=w.verify(contract,{'replacements':[]},out/'verification',authority=authority,admission_certificate=cert,policy=policy)
 result={'status':result['status'],'junit':result['junit'],'external_project_imports':result['execution']['external_project_imports'],'import_manifest':result['execution']['import_manifest'],'collection_external':cert['collection']['external_project_imports']}
except Exception as e:result={'status':'REFUSED','error':repr(e)}
(out/'RESULT.json').write_text(w.canonical(result)+'\n');print(w.canonical(result))
