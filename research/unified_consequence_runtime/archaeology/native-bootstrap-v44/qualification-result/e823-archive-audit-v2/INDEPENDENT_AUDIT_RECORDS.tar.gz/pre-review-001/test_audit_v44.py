"""Independent source-free audit controls; hostile packets are data only."""
import base64
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile
import zipfile

import pytest


def auditor():
    path = Path(__file__).with_name('audit_v44.py')
    assert path.is_file(), 'independent V44 audit implementation missing'
    spec = importlib.util.spec_from_file_location('v44_independent_auditor', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def valid_report():
    nodes = ['tests/test_native.py::test_protected']
    data = dict(timeout=False, source_mutations=[], unexpected_imports=[], external_project_imports=[],
        changed_test_code=[], plugin_violations=[], collected_test_nodes=nodes, selected_test_nodes=nodes,
        plugin_manifest=[], test_items=[{'nodeid': nodes[0]}], deselected_test_nodes=[], collection_errors=[],
        process_exit_code=0, reports=[{'nodeid':nodes[0], 'when':phase,'outcome':'passed','wasxfail':''}
                                     for phase in ('setup','call','teardown')])
    collection={key:data[key] for key in ('collected_test_nodes','selected_test_nodes','plugin_manifest','test_items')}
    return data,dict(tests=1,passed=1,failures=0,errors=0,skipped=0),collection


def test_claimed_green_does_not_replace_actual_complete_required_assertion_execution():
    m=auditor();data,counts,collection=valid_report()
    assert m.native_status(data,counts,collection)=='PASS_NATIVE'
    data['status']='PASS_NATIVE';data['reports']=[]
    assert m.native_status(data,counts,collection)!='PASS_NATIVE'


@pytest.mark.parametrize('change',('skipped','xfail','deselected','collection','imports','assertion_phase','empty'))
def test_native_authority_bypass_packets_fail_closed(change):
    m=auditor();data,counts,collection=valid_report()
    if change=='skipped':data['reports'][1]['outcome']='skipped';counts.update(passed=0,skipped=1)
    elif change=='xfail':data['reports'][1]['wasxfail']='declared expected failure'
    elif change=='deselected':data['deselected_test_nodes']=collection['selected_test_nodes']
    elif change=='collection':data['selected_test_nodes']=[]
    elif change=='imports':data['unexpected_imports']=['unwarranted/pytest.py']
    elif change=='assertion_phase':data['reports'][1]['when']='setup'
    elif change=='empty':collection['selected_test_nodes']=[];data['selected_test_nodes']=[];data['reports']=[];counts.update(tests=0,passed=0)
    assert m.native_status(data,counts,collection)!='PASS_NATIVE'


def test_packet_requires_exact_nonempty_retained_hash_inventory():
    m=auditor();raw={'report.json':b'{}','checked-report.json':b'{"mode":"run"}'}
    value={'packet':{k:base64.b64encode(v).decode() for k,v in raw.items()},
           'packet_sha256':{k:m.sha(v) for k,v in raw.items()}}
    assert m.verify_packet(value)==raw
    wrong=copy.deepcopy(value);wrong['packet_sha256']['report.json']='0'*64
    with pytest.raises(ValueError):m.verify_packet(wrong)
    wrong=copy.deepcopy(value);del wrong['packet_sha256']['checked-report.json']
    with pytest.raises(ValueError):m.verify_packet(wrong)
    with pytest.raises(ValueError):m.verify_packet({'packet':{},'packet_sha256':{}})


def test_gate_files_are_literal_data_never_executed(tmp_path):
    m=auditor();bad=tmp_path/'must-not-exist'
    source=('TESTS=("test_one.py",)\nBOOTSTRAP_GATE_FILES=tuple(PREFIX+x for x in ("native_metadata_v44.py",*TESTS))+(".github/workflows/x.yml",)\n').encode()
    assert m.gate_files(source)==[m.PREFIX+'native_metadata_v44.py',m.PREFIX+'test_one.py','.github/workflows/x.yml']
    malicious=('BOOTSTRAP_GATE_FILES=__import__("pathlib").Path('+repr(str(bad))+').touch()\n').encode()
    with pytest.raises(ValueError):m.gate_files(malicious)
    assert not bad.exists()


@pytest.mark.parametrize('name',('../outside','/absolute','back\\slash','a/../b'))
def test_unsafe_archive_paths_never_become_host_paths(tmp_path,name):
    m=auditor();store=m.Store(tmp_path/'cache');member=tarfile.TarInfo(name);member.size=1
    with pytest.raises(ValueError):store.add(member,io.BytesIO(b'x'))


def test_duplicate_archive_path_and_symlink_cannot_be_read_as_regular_bytes(tmp_path):
    m=auditor();store=m.Store(tmp_path/'cache');member=tarfile.TarInfo('record.json');member.size=2
    store.add(member,io.BytesIO(b'{}'))
    with pytest.raises(ValueError):store.add(member,io.BytesIO(b'{}'))
    link=tarfile.TarInfo('link.json');link.type=tarfile.SYMTYPE;link.linkname='/etc/passwd';store.add(link)
    with pytest.raises(ValueError):store.raw('link.json')


def test_artifact_zip_digest_cannot_be_relabelled_as_green(tmp_path):
    m=auditor();path=tmp_path/'artifact.zip'
    with zipfile.ZipFile(path,'w') as z:z.writestr('native-result.json','{"status":"PASS_NATIVE"}')
    row={'size_in_bytes':path.stat().st_size,'digest':'sha256:'+m.sha(path.read_bytes())}
    assert m.verify_artifact_digest(path,row)==row['digest'][7:]
    row['digest']='sha256:'+'0'*64
    with pytest.raises(ValueError):m.verify_artifact_digest(path,row)


def test_exact_support_withdrawal_is_recomputed_from_causal_edges():
    m=auditor();rows=[{'id':'a','kind':'support','premises':[],'payload':{}},
      {'id':'b','kind':'capability','premises':['a'],'payload':{}},
      {'id':'u','kind':'support','premises':[],'payload':{}},
      {'id':'c','kind':'outcome','premises':['b'],'payload':{}},
      {'id':'r','kind':'revoke','premises':[],'payload':{'target':'a'}}]
    assert m.live_nodes(rows[:4])=={'a','b','u','c'}
    assert m.live_nodes(rows)=={'u'}
