"""Format-only readback of exposed local infrastructure evidence; never a gate."""
from pathlib import Path
import importlib.util,json,stat,tarfile,datetime

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('v44_audit',HERE/'audit_v44.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
repo=Path('/workspace/udm-v54');original=Path('/workspace/qualification/native-bootstrap-v44-supplement-engineering-probe-001/run')
out=HERE/'LOCAL_FORMAT_REHEARSAL_002';out.mkdir()
frozen=json.loads(Path('/workspace/qualification/native-bootstrap-v44-source-transport-fixed-local/FREEZE.json').read_text())
class FrozenSource:
    entries={name:{'kind':'file'} for name in frozen['files']}
    def raw(self,name):
        raw=(repo/name).read_bytes()
        if audit.sha(raw)!=frozen['files'][name]:raise ValueError('localsource differs from frozen source: '+name)
        return raw
    def js(self,name):return json.loads(self.raw(name))
source=FrozenSource();evidence=audit.Store(out/'raw-by-sha256');aliases={}
for path in sorted(original.rglob('*')):
    info=path.lstat()
    if stat.S_ISDIR(info.st_mode):continue
    name='run/native-supplement/'+path.relative_to(original).as_posix();member=tarfile.TarInfo(name);member.mode=stat.S_IMODE(info.st_mode)
    if stat.S_ISLNK(info.st_mode):member.type=tarfile.SYMTYPE;member.linkname=str(path.readlink());evidence.add(member)
    elif stat.S_ISREG(info.st_mode):
        member.size=info.st_size
        with path.open('rb') as stream:evidence.add(member,stream)
    else:raise ValueError('unsupported localinfra evidencekind')
    aliases[str(path.absolute())]=name
original_resolver=evidence.path_for_absolute
def resolve(path):
    if path in aliases:return aliases[path]
    return original_resolver(path)
evidence.path_for_absolute=resolve
check=audit.Checks();report={'schema':'UDM_V44_LOCAL_FORMAT_ONLY_REHEARSAL_V1','source_commit':frozen['source_commit'],'scope':'Data-only rehearsal of retained exposed infrastructure supplement; no CIartifact checked, no archival qualificationgate, no native/source execution, no new scientific task.'}
try:
    report['native']=audit.audit_native(source,evidence,frozen,check)
    causal=audit.audit_causal(source,evidence,frozen,report['native'],check)
    report['causal']={k:v for k,v in causal.items() if k!='ledgers'}
    report['native_context']=audit.audit_native_context(source,evidence,report['native'],causal,check)
except BaseException as error:report['obstruction']=type(error).__name__+': '+str(error)
report['checks']=check.rows;report['failures']=[r for r in check.rows if not r['pass']]
report['status']='PASS_LOCAL_FORMAT_ONLY' if not report.get('obstruction') and not report['failures'] else 'UNKNOWN_FORMAT_OR_EVIDENCE_OBSTRUCTION'
(out/'REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'checks':len(check.rows),'failures':report['failures'],'obstruction':report.get('obstruction')},sort_keys=True))
