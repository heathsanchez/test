# Read-only legacy environment recovery

Target: exposed wrapt PR 99, base `b2e4759d31b3e4815077f03aeefea9ceadc67530`. Exposed source HEAD `bf645c8db85500ca055f92067c04f70f17b12f61` is the frozen independent test overlay. Original base tar SHA-256: `042f5bf8b3065ea18b6b811a8fd23dd33aa293763faa36177324b63de9b760a6`. `source-pinned-metadata.json` proves tox/travis/setup/conftest and relevant original library files match this exact base byte for byte.

Original source constraints:

- `tox.ini:3` declares CPython 2.6, 2.7, 3.3, 3.4, 3.5, 3.6 with and without C extensions, plus PyPy without extensions. `tox.ini:9` declares unversioned `pytest`; no historical exact pytest/dependency lock exists in these original inputs.
- `.travis.yml:3` selects Python 3.5, installs tox/coveralls, then skips missing tox interpreters. `setup.py:38-45` classifiers name 2.6,2.7,3.3-3.6; setup uses distutils and has no install_requires or tests_require.
- `tests/conftest.py:7` requires `pytest.collect.File`; its old path-based collection hook excludes interpreter-specific test files. Original `src/wrapt/decorators.py:34` imports `inspect.formatargspec`; `arguments.py:6` imports `inspect.getargspec`; tests also call these legacy APIs. Modern Python 3.11+ removes them.

Prospective finite profile (an independently chosen supported profile, not an original source pin): Linux x86-64 CPython **3.6.15**, pytest **5.4.3**, with exact pins listed in `prospective-profile-pypi-metadata.json`: pip21.3.1, setuptools59.6.0, wheel0.37.1, pytest5.4.3, attrs22.2.0, more-itertools8.14.0, packaging21.3, pluggy0.13.1, py1.11.0, wcwidth0.2.13, importlib-metadata4.8.3, pyparsing3.0.9, zipp3.6.0, typing-extensions4.1.1. Public PyPI metadata validates Python compatibility and all 11 active Linux/Python3.6 dependency edges (no requested extras). Metadata and wheel SHA-256 values are retained. Published pytest5.4.3 wheel `_pytest/compat.py:359-367` creates `pytest.collect` including `File`; `_pytest/nodes.py` has `fspath`, not modern `item.path`. No packages were installed and no original tests were executed during recovery.

Minimum obstruction in current v2:

- `native_environment_v2.py:279` creates venv with host `sys.executable`, so a selected runtime cannot currently enter provisioning. The controller imports tomllib (Python3.11+) and should remain modern.
- `decisive_native_verify.py:90-110` executes identity code inside the selected interpreter and imports stdlib `importlib.metadata` (Python3.8+); Python3.6 needs the independently pinned importlib_metadata backport through a new versioned worker, without altering original verifier.
- `native_execution_v2.py:39` does the same in plugin identity code. Its embedded bootstrap uses `Path.is_relative_to` (Python3.9+, lines72,139), `co_posonlyargcount` (Python3.8+, line95), `co_linetable` (Python3.10+, line97), `co_qualname` and `co_exceptiontable` (Python3.11+, line97), and pytest `item.path` (pytest7+, line110). These are version floors, not Python3.12-exclusive constructs. Current worker therefore has no runtime/pytest compatibility intersection with this original supported profile.
- New versioned environment/worker code needs an explicit selected interpreter, backport-aware metadata, relative-path checks without is_relative_to, version-appropriate lossless code-object identity, and pytest fspath support. This is runner compatibility only; no source/test/shim or winning-operation changes were made.

Local runtime inventory and original historical helper/ref search are recorded separately in `local-runtime-helpers.txt`. Initial inventory contains only CPython3.12.14/3.13.5, no installed 2.6-3.6 interpreters; uv confirms this. Docker daemon is available but no cached images/containers. No runtime download/build/install, Git mutation, target execution, remote write, or new frontier/source inspection was performed.
