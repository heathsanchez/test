"""Read-only retained admission audit. Raw diagnostics are written only here."""
import ast
import base64
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
import time
import traceback
import zipfile

os.umask(0o077)
START = time.time()
R = Path('/workspace/udm-v54')
Q = Path('/workspace/qualification')
A = Q/'native-frontier-v3-independent-screening-audit'
S = Q/'native-frontier-v3-independent-screening'
O = Q/'native-frontier-v3-independent-screening-operator'
P = Q/'native-frontier-v3-runtime-preparation'
E = Q/'env-selection-v3-runtime'
D = Q/'env-selection-v3-prospective-design'
F = R/'research/unified_consequence_runtime/archaeology/native-environment-v3'
HEAD = '1064cd76eadda16438cbd0f4240142e4d516adcc'
ASHA = 'e91f8b231add3f4cf595e10c36359f7a5499cb2b11a61e40987f6361ed214a67'
CHECKS = []
INPUTS = {}
CASES = []
COMMANDS = []

def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(v): return json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False)
def fp(v): return sha(canonical(v).encode())
def write(p,v): p.write_text(canonical(v)+'\n')
def require(label, value, detail=None):
    CHECKS.append({'check':label, 'passed':bool(value), **({'detail':detail} if detail is not None else {})})
    if not value: raise ValueError(label)
def read(p):
    p=Path(p)
    require('canonical_bound_input:'+str(p),p.is_absolute() and p.resolve()==p and not p.is_symlink() and p.is_file())
    raw=p.read_bytes(); INPUTS[str(p)]={'sha256':sha(raw),'bytes':len(raw)}
    return raw
def js(p): return json.loads(read(p))
def git(repo,*args):
    argv=['git','--no-replace-objects','-C',str(repo),*args]
    x=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    COMMANDS.append({'argv':argv,'returncode':x.returncode,'stdout_sha256':sha(x.stdout),'stderr_sha256':sha(x.stderr)})
    if x.returncode: raise ValueError('read_only_git_inspection_failed')
    return x.stdout
def committed(desc,commit=HEAD,as_json=True):
    p=Path(desc['path']);p=p if p.is_absolute() else R/p
    raw=read(p);require('descriptor_digest:'+str(p),sha(raw)==desc['sha256'])
    require('committed_bytes:'+str(p)+':'+commit,git(R,'show',commit+':'+p.relative_to(R).as_posix())==raw)
    return json.loads(raw) if as_json else raw
def finite(v): return type(v) in (int,float) and math.isfinite(v) and v>=0
def counts(v):
    return isinstance(v,dict) and all(type(v.get(k)) is int and v[k]>=0 for k in ('native_calls','collection_calls','subprocess_attempts')) and v['subprocess_attempts']==v['native_calls']+v['collection_calls']
def path_ok(n):
    p=PurePosixPath(n)
    return isinstance(n,str) and bool(n) and '\\' not in n and '\x00' not in n and not p.is_absolute() and '..' not in p.parts and p.as_posix()==n
def is_test(n):
    p=PurePosixPath(n)
    return p.suffix=='.py' and (any(x in ('test','tests','testing') for x in p.parts) or p.name.startswith('test_') or p.name.endswith('_test.py') or p.name=='conftest.py')
def snapshot(repo,commit):
    require('source_repository_canonical:'+str(repo),repo.resolve()==repo and not repo.is_symlink())
    require('source_commit_exact:'+str(repo),git(repo,'rev-parse',commit+'^{commit}').decode().strip()==commit)
    files={};manifest=[]
    for row in filter(None,git(repo,'ls-tree','-rz','--full-tree',commit).split(b'\0')):
        meta,name=row.split(b'\t',1);mode,kind,blob=meta.decode().split();name=name.decode()
        require('regular_unique_source_path:'+str(repo)+':'+name,path_ok(name) and mode in ('100644','100755') and kind=='blob' and name not in files)
        raw=git(repo,'cat-file','blob',blob);files[name]=raw
        require('git_blob_digest:'+str(repo)+':'+name,hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob)
        manifest.append({'path':name,'mode':mode,'blob':blob,'sha256':sha(raw)})
    identity={'git_tree':git(repo,'rev-parse',commit+'^{tree}').decode().strip(),'tracked_tree_sha256':fp(manifest),'file_count':len(files)}
    return identity,files,manifest
def check_worktree(repo,files,manifest):
    for row in manifest:
        p=repo/row['path']
        require('unchanged_worktree_file:'+str(p),p.is_file() and not p.is_symlink() and p.read_bytes()==files[row['path']] and bool(p.stat().st_mode&0o111)==(row['mode']=='100755'))
    require('unchanged_worktree_tracked_status:'+str(repo),not git(repo,'status','--porcelain','--untracked-files=no').strip())
def archive(p,files,manifest,desc=None):
    raw=read(p)
    if desc is not None:require('archive_descriptor:'+str(p),desc=={'path':str(p),'sha256':sha(raw),'bytes':len(raw),'format':'RAW_TRACKED_BYTES_TAR_GZIP_V2','export_subst':False})
    actual={};modes={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
        for m in t.getmembers():
            require('safe_regular_archive_member:'+str(p)+':'+m.name,m.isfile() and path_ok(m.name) and m.name not in actual)
            actual[m.name]=t.extractfile(m).read();modes[m.name]=m.mode
    require('archive_exact_source_bytes:'+str(p),actual==files)
    require('archive_exact_modes:'+str(p),modes=={r['path']:int(r['mode'],8)&0o777 for r in manifest})
    return {'path':str(p),'sha256':sha(raw),'members':len(actual),'content_manifest_sha256':fp(manifest),'safe_read_without_extraction':True}
def log_costs(rows,scope):
    out=[]
    for i,row in enumerate(rows):
        require('setup_duration:'+scope+':'+str(i),finite(row['seconds']))
        require('setup_non_native_cost:'+scope+':'+str(i),type(row.get('native_calls',0)) is int and row.get('native_calls',0)==0)
        if 'log' in row:
            raw=read(Path(row['log']));require('setup_log_digest:'+scope+':'+str(i),sha(raw)==row['log_sha256'])
            require('setup_log_inside_case:'+scope+':'+str(i),Path(row['log']).is_relative_to(S))
        out.append(row)
    return out
def inventory(root):
    out=[]
    for p in sorted(root.rglob('*')):
        if p.is_symlink():out.append({'path':str(p),'kind':'symlink','target':os.readlink(p),'mode':oct(p.lstat().st_mode&0o777)})
        elif p.is_file():
            raw=p.read_bytes();out.append({'path':str(p),'kind':'regular','bytes':len(raw),'sha256':sha(raw),'mode':oct(p.stat().st_mode&0o777)})
    return out

def main():
    require('clean_pinned_repository',git(R,'rev-parse','HEAD').decode().strip()==HEAD and not git(R,'status','--porcelain').strip())
    ticket=js(F/'SCREENING_AUTHORITY.json');require('external_authority_sha256',INPUTS[str(F/'SCREENING_AUTHORITY.json')]['sha256']==ASHA)
    require('authority_type_operation_paths',ticket['schema']=='UDM_NATIVE_CLI_AUTHORITY_V3' and ticket['operation']=='screen' and ticket['repo']==str(R) and ticket['output_root']==str(S))
    committed({'path':str(F/'SCREENING_AUTHORITY.json'),'sha256':ASHA})
    protocol=js(F/'FRONTIER_PROTOCOL.json');pre=committed(ticket['prequery']);pool=committed(ticket['pool']);specs=pool['pool']
    require('actual_fixed_seven_pool',len(specs)==7 and pool['prequery_execution_sha256']==ticket['prequery']['sha256'])
    require('prequery_declarations',pre['state']=='PREQUERY_COMMITTED_BEFORE_QUERIES' and pre['target_query_count_before_receipt']==0 and type(pre['target_query_count_before_receipt']) is int and pre['environment_gate']==ticket['environment_gate']==protocol['environment_gate'])
    records={}
    for k in ('plan','code','gate_descriptor'):
        require('prequery_source_commit:'+k,pre[k]['source_commit']==pre['source_commit'])
        records[k]=committed(pre[k],pre['source_commit'],k!='code');committed(pre[k],HEAD,k!='code')
    plan=records['plan'];wrapper=records['gate_descriptor'];gate=ticket['environment_gate']
    require('gate_catalog_wrapper',set(wrapper)=={'environment_gate','catalog'} and wrapper['environment_gate']==gate and wrapper['catalog']==protocol['catalog'])
    require('prequery_plan_code_bound',plan['curation_code_sha256']==pre['code']['sha256'] and pre['repository_universe_fixed_before_github_queries']==plan['repository_universe_fixed_before_github_queries'])
    require('fixed_budget_and_role_count',pre['screening_budget']==pool['screening_budget']==plan['screening_budget'] and pre['requested_roles']==pool['requested_roles']==plan['requested_roles']==2)
    budget=pool['screening_budget'];require('declared_budget_valid',budget['maximum_native_executions_per_case']==2 and budget['collection_seconds_per_call']==60 and budget['execution_seconds_per_call']==600 and type(budget['maximum_cases']) is int and budget['maximum_cases']>=7 and finite(budget['total_screening_wall_seconds']) and budget['total_screening_wall_seconds']>0)
    curation=js(F/'METADATA_CURATION.json');require('curation_fixed_pool_binding',sha((F/'METADATA_CURATION.json').read_bytes())==pool['metadata_curation_sha256'] and curation['pool']==specs and curation['prequery_execution_sha256']==ticket['prequery']['sha256'] and curation['prequery_plan_sha256']==pre['plan']['sha256'])
    require('pool_repository_order_unique',len({x['repo'].lower() for x in specs})==7 and [x['repo'] for x in specs]==sorted(x['repo'] for x in specs) and all(x['repo'] in plan['repository_universe_fixed_before_github_queries'] for x in specs))
    catalog=committed(protocol['catalog']);result=js(R/gate['result_path']);require('qualification_result_digest',sha((R/gate['result_path']).read_bytes())==gate['qualification_result_sha256'])
    require('qualified_gate_exact_fields',set(gate)=={'status','source_commit','run_id','artifact_id','artifact_sha256','qualification_result_sha256','result_path'} and gate['status']=='ADMISSION_ONLY_QUALIFIED' and result['status']==gate['status'] and result['source_commit']==gate['source_commit'] and result['schema']=='UDM_NATIVE_ENVIRONMENT_QUALIFICATION_RESULT_V3' and result['freeze']['schema']=='UDM_NATIVE_ENVIRONMENT_QUALIFICATION_FREEZE_V3' and result['first_task_gate']['status']=='PASS' and all(result['verdicts'][k]=='UNKNOWN' for k in ('G2','G3','G4')))
    bridge=tuple('research/unified_consequence_runtime/'+n+'.py' for n in ('native_environment_selection_v3','native_environment_v3','native_execution_v3','native_runtime_v3','qualify_environment_selection_v3'))+('.github/workflows/udm-native-environment-selection-v3.yml','research/unified_consequence_runtime/archaeology/native-environment-v3/PROTOCOL.json','research/unified_consequence_runtime/archaeology/native-environment-v3/ENVIRONMENT_CATALOG.json','research/unified_consequence_runtime/archaeology/native-environment-v3/PACKAGE_METADATA.json')+tuple('research/unified_consequence_runtime/archaeology/native-environment-v3/bootstrap/'+n for n in ('prepare_runtimes.py','stdlib_cache.py','metadata_receipt.py','METADATA_RECEIPT.json','official-legacy-installer.json','legacy-pins.txt'))
    for name in bridge:
        raw=read(R/name);require('qualified_bridge_bytes:'+name,sha(raw)==result['freeze']['files'][name] and git(R,'show',gate['source_commit']+':'+name)==raw)
    require('qualified_exact_catalog',result['freeze']['files'][protocol['catalog']['path']]==protocol['catalog']['sha256'] and result['freeze']['catalog_sha256']==fp(catalog))
    artifact=js(E/'CI_38872399668_ARTIFACTS.json');run=js(E/'CI_38872399668_RUN.json');zipraw=read(E/'CI_38872399668_GREEN.zip')
    require('retained_ci_artifact_run_binding',sha(zipraw)==gate['artifact_sha256'] and run['id']==gate['run_id'] and run['head_sha']==gate['source_commit'] and run['status']=='completed' and run['conclusion']=='success' and any(x['id']==gate['artifact_id'] and x['digest']=='sha256:'+gate['artifact_sha256'] and x['workflow_run']['id']==gate['run_id'] and x['workflow_run']['head_sha']==gate['source_commit'] for x in artifact['artifacts']))
    zip_inventory=[]
    with zipfile.ZipFile(io.BytesIO(zipraw)) as z:
        for n in z.namelist():
            raw=z.read(n);zip_inventory.append({'path':n,'sha256':sha(raw),'bytes':len(raw)})
        require('artifact_source_commit',z.read('source-commit.txt').decode().strip()==gate['source_commit'])
        require('artifact_freeze_exact',json.loads(z.read('FREEZE.json'))==result['freeze'])
        payload=z.read('ENVIRONMENT_V3_EVIDENCE.tar.gz');matches=[]
        with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as t:
            for m in t.getmembers():
                if m.isfile() and m.size==len((R/gate['result_path']).read_bytes()):
                    b=t.extractfile(m).read()
                    if sha(b)==gate['qualification_result_sha256']:matches.append(m.name)
        require('artifact_contains_exact_qualified_result',len(matches)==1)
    provenance=js(O/'SEALED_EXECUTION_PROVENANCE.json');operator=read(O/'run_ordered_screening.py')
    require('operator_provenance_identity',provenance['schema']=='UDM_INDEPENDENT_ADMISSION_SCREENING_OPERATOR_PROVENANCE_V3' and provenance['source_commit']==HEAD and provenance['authority']=={'path':str(F/'SCREENING_AUTHORITY.json'),'sha256':ASHA} and provenance['operator_script_sha256']==sha(operator) and provenance['requested_indices']==list(range(7)) and len(provenance['cases'])==7 and provenance['state']=='ALL_SEVEN_COMPLETE_PENDING_INDEPENDENT_AUDIT' and provenance['repository_unchanged'] is True)
    for n,h in provenance['committed_source_files'].items():
        raw=read(R/n);require('operator_committed_source:'+n,sha(raw)==h and git(R,'show',HEAD+':'+n)==raw)
    runtimes=js(P/'RUNTIME_PATHS.json');inv=js(P/'RUNTIME_INVENTORY.json');require('operator_runtime_paths',provenance['runtime_paths']=={'path':str(P/'RUNTIME_PATHS.json'),'sha256':sha((P/'RUNTIME_PATHS.json').read_bytes())})
    require('runtime_inventory_catalog_binding',inv['schema']=='UDM_NATIVE_FRONTIER_RUNTIME_INVENTORY_V3' and inv['catalog_sha256']==fp(catalog) and inv['runtime_paths_sha256']==fp(runtimes) and set(inv['runtimes'])==set(runtimes))
    profiles={x['id']:x for x in catalog['profiles']}
    for ident,rec in inv['runtimes'].items():
        require('runtime_record_binding:'+ident,rec['interpreter']==runtimes[ident] and set(rec)=={'interpreter','identity','import_roots','stdlib_files'} and sha(Path(rec['interpreter']).read_bytes())==rec['identity']['executable_sha256'] and fp(rec['stdlib_files'])==rec['identity']['stdlib_manifest_sha256'])
        require('runtime_profile_binding:'+ident,'.'.join(map(str,rec['identity']['version_info'][:3]))==profiles[ident]['python_version'] and rec['identity']['implementation'].lower()==profiles[ident]['python_implementation'].lower())
        for p,h in rec['stdlib_files']:require('retained_runtime_stdlib_file:'+p,Path(p).is_file() and sha(Path(p).read_bytes())==h)
    meter=js(S/'SCREENING_METER.json');require('complete_ordered_meter',meter['schema']=='UDM_ORDERED_SCREENING_METER_V3' and meter['authority_sha256']==ASHA and meter['source_commit']==HEAD and meter['runtime_inventory_sha256']==fp(inv) and meter['pending'] is None and meter['accounting_complete'] is True and len(meter['cases'])==7 and not (S/'SCREENING_METER.lock').exists())
    sys.path.insert(0,str(R))
    from research.unified_consequence_runtime import native_execution_v3 as worker
    from research.unified_consequence_runtime import native_environment_selection_v3 as selector
    before=worker.attempt_snapshot();require('canonical_fingerprint_contract',worker.fingerprint({'a':[1,False,None]})==fp({'a':[1,False,None]}))
    envelopes=[];private_totals={'native_calls':0,'collection_calls':0,'subprocess_attempts':0};setup_wall=0.;case_wall=0.;phase_seconds=0.;previous_end=None
    for i,spec in enumerate(specs):
        c=S/f'case-{i:03d}';j=js(c/'SCREENING_CASE.json');en=js(c/'SCREENING_ENVELOPE.json');mc=meter['cases'][i];op=provenance['cases'][i];request=Q/'native-frontier-v3-screen-requests'/f'request-{i:03d}.json';req=js(request)
        require('exact_ordered_request:'+str(i),req=={'pool_index':i,'protocol_binding':ASHA,'spec':spec} and provenance['requests'][i]=={'index':i,'sha256':sha(request.read_bytes())})
        expected_argv=[provenance['controller_python'],'-B','-m','research.unified_consequence_runtime.qualify_native_frontier_v3','--screen-spec',str(request),'--authority',str(F/'SCREENING_AUTHORITY.json'),'--authority-sha256',ASHA,'--runtimes',str(P/'RUNTIME_PATHS.json'),'--out',str(c)]
        require('real_cli_order_and_completed:'+str(i),op['index']==i and op['argv']==expected_argv and op['returncode']==0 and op['state']=='COMPLETE' and op['started_at_unix']<=op['finished_at_unix'] and (previous_end is None or previous_end<=op['started_at_unix']))
        previous_end=op['finished_at_unix']
        for stream in ('stdout','stderr'):
            raw=read(O/f'case-{i:03d}.{stream}.log');require('operator_cli_log_digest:'+str(i)+':'+stream,sha(raw)==op[stream+'_sha256'])
        require('operator_envelope_digest:'+str(i),sha((c/'SCREENING_ENVELOPE.json').read_bytes())==op['envelope_sha256'])
        require('case_exact_identity_mode:'+str(i),j['schema']=='UDM_ADMISSION_ONLY_CASE_V3' and j['repository']==spec['repo'] and j['spec_sha256']==fp(spec) and j['screening_mode']=='ADMISSION_ONLY_NO_CATALOG_OR_CANDIDATE_SEARCH' and j['retained_raw_directory']==str(c) and j['accounting_complete'] is True and counts(j['controller_attempts']) and finite(j['total_wall_seconds']))
        require('no_search_information:'+str(i),not ({'candidate_catalog','orders','selected_policy','winner','profiles','candidate','candidate_outcomes'}&set(j)))
        require('case_meter_identity:'+str(i),mc=={'index':i,'spec_sha256':fp(spec),'report':{'path':str(c/'SCREENING_CASE.json'),'sha256':sha((c/'SCREENING_CASE.json').read_bytes())},'costs':j['controller_attempts'],'accounting_complete':True})
        for k in private_totals:private_totals[k]+=j['controller_attempts'][k]
        require('case_native_ceiling:'+str(i),j['controller_attempts']['native_calls']<=2)
        require('all_case_runtime_inventory_exact:'+str(i),(S/f'case-{i:03d}.RUNTIME_INVENTORY.json').read_bytes()==(P/'RUNTIME_INVENTORY.json').read_bytes())
        actual_partials=[]
        for p in sorted(c.rglob('checked-report.json')):
            raw=p.read_bytes()
            try:
                x=json.loads(raw);co=x.get('costs',{});valid=isinstance(x,dict) and isinstance(co,dict) and all(type(co.get(k,0)) is int and co.get(k,0)>=0 for k in ('native_calls','collection_calls','subprocess_attempts'))
            except (ValueError,TypeError,AttributeError):co={};valid=False
            actual_partials.append({'path':str(p),'sha256':sha(raw),'costs':co if valid else {},'valid':valid})
        require('every_partial_report_retained:'+str(i),actual_partials==j['partial_native_reports'])
        derived={k:max(sum(x['costs'].get(k,0) for x in actual_partials),j['controller_attempts'][k]) for k in ('native_calls','collection_calls')}
        require('recovered_counts_do_not_exceed_private:'+str(i),all(sum(x['costs'].get(k,0) for x in actual_partials)<=j['controller_attempts'][k] for k in derived))
        expected_en={'schema':'UDM_SEALED_ADMISSION_ENVELOPE_V3','repository':spec['repo'],'spec_sha256':fp(spec),'status':'ADMITTED_NATIVE' if j['eligible'] else 'UNKNOWN_ADMISSION_SCREENING','eligible':j['eligible'],'screening_mode':j['screening_mode'],'sealed_report':mc['report'],'costs':derived,'total_wall_seconds':j['total_wall_seconds']}
        require('envelope_exact_reconstruction:'+str(i),en==expected_en)
        setup=j['setup'];sr=c/'source-environment';require('retained_setup_exact:'+str(i),js(sr/'admission-v3.json')==setup and js(sr/'selection.json')==setup['selection'] and setup['schema']=='UDM_SOURCE_ENVIRONMENT_ADMISSION_V3' and finite(setup['total_wall_seconds']))
        identity,files,manifest=snapshot(sr/'metadata-source',spec['base_commit']);require('metadata_source_identity:'+str(i),identity==setup['source_metadata_identity']);check_worktree(sr/'metadata-source',files,manifest)
        archives=[archive(sr/'metadata-source.tar.gz',files,manifest)]
        selector.validate_selection(files,catalog,setup['selection']);require('selection_reconstructed_without_task_execution:'+str(i),True)
        log_costs(setup['costs'],str(i));setup_wall+=setup['total_wall_seconds'];phase_seconds+=sum(x['seconds'] for x in setup['costs']);case_wall+=j['total_wall_seconds']
        require('setup_initial_phases:'+str(i),[x['phase'] for x in setup['costs'][:5]]==['external-runtime-preflight','metadata-init','metadata-fetch','metadata-checkout','independent-metadata-selection'])
        require('metadata_transport_exact_base_only:'+str(i),setup['costs'][2]['argv']==['git','-C',str(sr/'metadata-source'),'fetch','--depth=1','--no-tags','https://github.com/'+spec['repo']+'.git',spec['base_commit']])
        detail={'index':i,'repository':spec['repo'],'spec_sha256':fp(spec),'raw_status':j['status'],'raw_setup_reason':setup.get('reason'),'private_costs':j['controller_attempts'],'setup_costs':setup['costs'],'total_wall_seconds':j['total_wall_seconds'],'archives':archives,'source_identity':identity,'selection':setup['selection'],'native_receipts_present':False}
        inner=setup.get('setup')
        if inner is None:
            require('faithful_metadata_refusal:'+str(i),setup['selection']['status']!='CANDIDATE_SOURCE_ENVIRONMENT' and setup['status']=='UNKNOWN_ENVIRONMENT_SELECTION' and setup['reason']==setup['selection']['reason'] and setup['runtime'] is None and not (sr/'native').exists())
        else:
            nr=sr/'native';require('retained_inner_setup_exact:'+str(i),js(nr/'admission.json')==inner and js(nr/'source-boundaries.json')==inner['source_boundaries'])
            b=inner['source_boundaries'];bi,bf,bm=snapshot(nr/'source',spec['base_commit']);ai,af,am=snapshot(nr/'source',b['augmented_commit'])
            require('full_base_augmented_identity:'+str(i),bi==identity==b['base_identity'] and bm==b['base_manifest'] and ai==b['augmented_identity'] and am==b['augmented_manifest'] and b['repository']==spec['repo'] and b['base_commit']==spec['base_commit'] and b['author_test_head_commit']==spec['head_commit'] and b['production_preserved'] is True and b['head_production_fetched'] is False)
            check_worktree(nr/'source',af,am)
            detail['archives'] += [archive(nr/'base-source.tar.gz',bf,bm,b['base_source_archive']),archive(nr/'contract-source.tar.gz',af,am,b['contract_source_archive'])]
            tests=sorted(x['filename'] for x in spec['files'] if is_test(x['filename']));overlay={}
            require('exact_author_test_scope:'+str(i),[x['path'] for x in b['author_tests']]==tests and len(tests)==len(set(tests)))
            for k,t in enumerate(b['author_tests']):
                p=Path(t['transport_json']);raw=read(p);response=json.loads(raw);decoded=base64.b64decode(re.sub(r'\s','',response['content']),validate=True);blob=hashlib.sha1(b'blob '+str(len(decoded)).encode()+b'\0'+decoded).hexdigest();endpoint='repos/'+spec['repo']+'/contents/'+t['path']+'?ref='+spec['head_commit']
                require('author_transport_exact:'+str(i)+':'+str(k),p==nr/f'author-test-{k}.log' and sha(raw)==t['transport_sha256'] and t['endpoint']==endpoint and response['path']==t['path'] and response['type']=='file' and response['encoding']=='base64' and response['sha']==blob==t['git_blob'] and response['size']==len(decoded)==t['bytes'] and sha(decoded)==t['sha256'])
                overlay[t['path']]=decoded
            require('only_author_tests_overlay:'+str(i),af=={**bf,**overlay} and all(next(x['mode'] for x in am if x['path']==p)==next(x['mode'] for x in bm if x['path']==p) for p in bf if p not in overlay))
            profile=setup['selection']['selected_profile'];require('selected_runtime_and_policy:'+str(i),setup['runtime']==inv['runtimes'][profile['id']] and inner['policy']=={'schema':'UDM_NATIVE_EXECUTION_POLICY_V3','collection_seconds':60,'execution_seconds':600,'pytest_version':profile['pytest_version'],'plugins':profile['plugins']})
            expected_requirements=''.join(pin+' --hash=sha256:'+profile['package_artifacts'][selector.canonicalize_name(selector.Requirement(pin).name)]['sha256']+'\n' for pin in profile['packages'])
            require('exact_pinned_requirements:'+str(i),(sr/'pinned-requirements.txt').read_text()==expected_requirements)
            try:
                worker.admission.derive_suite_contract(nr/'source',spec['base_commit'],b['augmented_commit'],ASHA,repository=spec['repo'])
                static_reason=None
            except ValueError as ex:static_reason=str(ex)
            require('static_contract_refusal_reproduced:'+str(i),static_reason is not None and inner['status']=='UNKNOWN_CONTRACT' and inner['reason']==static_reason and inner['authority'] is None and inner['native_suite_authority'] is None and inner['contract'] is None)
            require('outer_inner_refusal_exact:'+str(i),setup['status']==inner['status'] and setup['reason']==inner['reason'] and j['status']==setup['status'])
            require('inner_stage_costs_retained_once:'+str(i),setup['costs'][-len(inner['costs']):]==inner['costs'] and inner['costs'][-1]['phase']=='native-suite-authority' and inner['costs'][-1]['status']=='UNKNOWN_CONTRACT')
            detail.update(raw_inner_setup=inner,static_refusal_reproduced=static_reason,production_scope=[x['filename'] for x in spec['files'] if x['filename'].endswith('.py') and not is_test(x['filename'])],author_tests=b['author_tests'])
        require('truthful_ineligible_refusal:'+str(i),j['eligible'] is False and j['status']==setup['status'] and not j['costs'] and not actual_partials and j['controller_attempts']=={'native_calls':0,'collection_calls':0,'subprocess_attempts':0})
        require('no_success_only_worker_artifacts:'+str(i),not any((c/n).exists() for n in ('collection','independent-collection','baseline','independent-baseline')) and 'baseline' not in j and 'certificate' not in j)
        require('within_wall_budget_at_completion:'+str(i),op['finished_at_unix']-meter['started_at_unix']<=budget['total_screening_wall_seconds'])
        CASES.append(detail);envelopes.append(en)
    after=worker.attempt_snapshot();require('zero_audit_worker_launch_delta',before==after=={'native_calls':0,'collection_calls':0,'subprocess_attempts':0})
    require('aggregate_meter_reconciles',all(meter[k]==private_totals[k] for k in ('native_calls','collection_calls')))
    require('operator_wall_reconciles',finite(provenance['total_operator_wall_seconds']) and abs((provenance['finished_at_unix']-provenance['cases'][0]['started_at_unix'])-provenance['total_operator_wall_seconds'])<2 and abs(sum(x['finished_at_unix']-x['started_at_unix'] for x in provenance['cases'])-provenance['total_operator_wall_seconds'])<2)
    require('repository_still_clean_pinned',git(R,'rev-parse','HEAD').decode().strip()==HEAD and not git(R,'status','--porcelain').strip())
    inv_records=inventory(S)+inventory(O)
    write(A/'SEALED_HASH_INVENTORY.json',{'schema':'UDM_RETAINED_SCREENING_HASH_INVENTORY_V3','files':inv_records,'bound_inputs':INPUTS,'ci_archive_members':zip_inventory})
    aggregate={'native_calls':private_totals['native_calls'],'collection_calls':private_totals['collection_calls'],'subprocess_attempts':private_totals['subprocess_attempts'],'screening_operator_wall_seconds':provenance['total_operator_wall_seconds'],'screening_case_wall_seconds_sum':case_wall,'setup_wall_seconds_sum':setup_wall,'setup_phase_seconds_sum_nonadditive':phase_seconds,'total_lifecycle_cost':'UNKNOWN','metadata_identity_provisioning_build_install_model_tool_and_engineering_costs':'PARTIALLY_RETAINED_NOT_EXHAUSTIVELY_MEASURED','wall_intervals':'NESTED_NONADDITIVE'}
    return {'pool_sha256':ticket['pool']['sha256'],'reports_sha256':worker.fingerprint(envelopes),'aggregate_costs':aggregate,'audit_worker_attempts_before':before,'audit_worker_attempts_after':after,'eligible_count':sum(x['eligible'] for x in envelopes),'requested_roles':2,'shortfall':2-sum(x['eligible'] for x in envelopes),'hash_inventory':{'path':str(A/'SEALED_HASH_INVENTORY.json'),'sha256':sha((A/'SEALED_HASH_INVENTORY.json').read_bytes())},'all_screened_cases_and_costs_retained':True}

try:
    result=main();error=None
except Exception as ex:
    result={};error={'type':type(ex).__name__,'message':str(ex),'traceback':traceback.format_exc()}
write(A/'SEALED_CHECK_RESULTS.json',{'checks':CHECKS,'cases':CASES,'result':result,'error':error,'read_only_git_commands':COMMANDS,'started_at_unix':START,'finished_at_unix':time.time(),'audit_python':sys.executable})
print(canonical({'audit_checks_complete':error is None,'check_count':len(CHECKS),'failed_check_count':sum(not x['passed'] for x in CHECKS),'sealed_check_record':str(A/'SEALED_CHECK_RESULTS.json')}))
