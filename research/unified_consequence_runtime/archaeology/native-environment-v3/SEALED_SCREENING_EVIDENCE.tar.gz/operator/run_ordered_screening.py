"""Authorized ordered real CLI screen; all raw output stays in this sealed tree."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO=Path('/workspace/udm-v54')
HEAD='1064cd76eadda16438cbd0f4240142e4d516adcc'
AUTHORITY=REPO/'research/unified_consequence_runtime/archaeology/native-environment-v3/SCREENING_AUTHORITY.json'
EXPECTED='e91f8b231add3f4cf595e10c36359f7a5499cb2b11a61e40987f6361ed214a67'
PYTHON=Path('/workspace/qualification/native-frontier-v3-runtime-preparation/controller/bin/python')
RUNTIMES=Path('/workspace/qualification/native-frontier-v3-runtime-preparation/RUNTIME_PATHS.json')
REQUESTS=Path('/workspace/qualification/native-frontier-v3-screen-requests')
OUTPUT=Path('/workspace/qualification/native-frontier-v3-independent-screening')
OPERATOR=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n')
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),*args],stderr=subprocess.PIPE).decode().strip()
def unchanged():
    if git('rev-parse','HEAD')!=HEAD or git('status','--porcelain'):
        raise RuntimeError('COMMITTED_SCREENING_SOURCE_CHANGED')

def main():
    os.umask(0o077);OPERATOR.mkdir(parents=True,exist_ok=True);OPERATOR.chmod(0o700)
    unchanged()
    if sha(AUTHORITY)!=EXPECTED:raise RuntimeError('EXTERNAL_AUTHORITY_SHA_DIFFERS')
    ticket=json.loads(AUTHORITY.read_text())
    if ticket['output_root']!=str(OUTPUT) or ticket['repo']!=str(REPO):raise RuntimeError('CANONICAL_AUTHORITY_PATH_DIFFERS')
    if OUTPUT.exists() and any(OUTPUT.iterdir()):raise RuntimeError('NEW_ONCE_ONLY_SCREENING_OUTPUT_REQUIRED')
    for index in range(7):
        if not (REQUESTS/('request-'+format(index,'03d')+'.json')).is_file():raise RuntimeError('REQUEST_MISSING')
    provenance={'schema':'UDM_INDEPENDENT_ADMISSION_SCREENING_OPERATOR_PROVENANCE_V3',
        'source_commit':HEAD,'authority':{'path':str(AUTHORITY),'sha256':EXPECTED},
        'controller_python':str(PYTHON),'runtime_paths':{'path':str(RUNTIMES),'sha256':sha(RUNTIMES)},
        'operator_script_sha256':sha(__file__),'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'requested_indices':list(range(7)),'requests':[{'index':i,'sha256':sha(REQUESTS/('request-'+format(i,'03d')+'.json'))} for i in range(7)],
        'independence':{'source_access_authorized_by_parent':True,'candidate_catalog_or_policy_outcomes_accessed':False,
            'learner_access_to_raw_screening_source_or_outcomes':False,'boundary':'Separate agent contexts and controlled output; shared-UID filesystem is not a sandbox'},
        'cases':[],'state':'RUNNING','cost_scope':'Every real CLI call, raw output, negative, launch meter and setup retained; model/tool engineering lifecycle overhead not fully measured'}
    source_files=git('ls-tree','-r','--name-only',HEAD,'--','research/unified_consequence_runtime','.github/workflows').splitlines()
    provenance['committed_source_files']={name:sha(REPO/name) for name in source_files}
    write(OPERATOR/'SEALED_EXECUTION_PROVENANCE.json',provenance)
    started=time.monotonic()
    for index in range(7):
        unchanged();name='case-'+format(index,'03d');request=REQUESTS/('request-'+format(index,'03d')+'.json')
        argv=[str(PYTHON),'-B','-m','research.unified_consequence_runtime.qualify_native_frontier_v3',
            '--screen-spec',str(request),'--authority',str(AUTHORITY),'--authority-sha256',EXPECTED,
            '--runtimes',str(RUNTIMES),'--out',str(OUTPUT/name)]
        row={'index':index,'argv':argv,'started_at_unix':time.time(),'state':'LAUNCHED'}
        provenance['cases'].append(row);write(OPERATOR/'SEALED_EXECUTION_PROVENANCE.json',provenance)
        with (OPERATOR/(name+'.stdout.log')).open('wb') as stdout,(OPERATOR/(name+'.stderr.log')).open('wb') as stderr:
            process=subprocess.run(argv,cwd=REPO,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        row.update(returncode=process.returncode,finished_at_unix=time.time(),
            stdout_sha256=sha(OPERATOR/(name+'.stdout.log')),stderr_sha256=sha(OPERATOR/(name+'.stderr.log')))
        unchanged()
        if process.returncode:
            row['state']='UNKNOWN_CLI_OBSTRUCTION';provenance['state']='STOPPED_RETAINED_OBSTRUCTION'
            write(OPERATOR/'SEALED_EXECUTION_PROVENANCE.json',provenance)
            print(json.dumps({'completed_cases':index,'stopped_index':index,'status':'UNKNOWN_CLI_OBSTRUCTION','raw_evidence_sealed':True}),flush=True)
            return 1
        envelope=json.loads((OUTPUT/name/'SCREENING_ENVELOPE.json').read_text())
        if envelope['status'] not in ('ADMITTED_NATIVE','UNKNOWN_ADMISSION_SCREENING'):raise RuntimeError('UNMASKED_PUBLIC_STATUS')
        row.update(state='COMPLETE',envelope_sha256=sha(OUTPUT/name/'SCREENING_ENVELOPE.json'))
        write(OPERATOR/'SEALED_EXECUTION_PROVENANCE.json',provenance)
        meter=json.loads((OUTPUT/'SCREENING_METER.json').read_text())
        public={'completed_cases':index+1,'declared_cases':7,'latest_status':envelope['status'],
            'native_calls':meter['native_calls'],'collection_calls':meter['collection_calls'],
            'elapsed_wall_seconds':time.monotonic()-started,'raw_evidence_sealed':True}
        write(OPERATOR/'PUBLIC_PROGRESS.json',public);print(json.dumps(public,sort_keys=True),flush=True)
    provenance.update(state='ALL_SEVEN_COMPLETE_PENDING_INDEPENDENT_AUDIT',finished_at_unix=time.time(),
        total_operator_wall_seconds=time.monotonic()-started,repository_unchanged=True)
    write(OPERATOR/'SEALED_EXECUTION_PROVENANCE.json',provenance)
    print(json.dumps({'status':provenance['state'],'raw_evidence_sealed':True}),flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
