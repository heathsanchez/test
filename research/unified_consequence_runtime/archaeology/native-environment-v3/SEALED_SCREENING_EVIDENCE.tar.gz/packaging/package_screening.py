"""Opaque evidence packaging; reads bytes/hashes, never imports task code."""
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile
import time

BASE=Path('/workspace/qualification')
REPO=Path('/workspace/udm-v54')
COMMIT='1064cd76eadda16438cbd0f4240142e4d516adcc'
ARCHIVE=BASE/'native-frontier-v3-SEALED_SCREENING_EVIDENCE.tar.gz'
MANIFEST=BASE/'native-frontier-v3-SEALED_SCREENING_EVIDENCE.manifest.json'
ROOTS={
 'screening':BASE/'native-frontier-v3-independent-screening',
 'operator':BASE/'native-frontier-v3-independent-screening-operator',
 'independent-audit':BASE/'native-frontier-v3-independent-screening-audit',
 'public-handoff':BASE/'native-frontier-v3-public-screening-handoff',
 'runtime-preparation':BASE/'native-frontier-v3-runtime-preparation',
}

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def filehash(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda:source.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),stderr=subprocess.PIPE)

def main():
    os.umask(0o077)
    if ARCHIVE.exists() or MANIFEST.exists():raise ValueError('new immutable evidence output required')
    if git('rev-parse','HEAD').decode().strip()!=COMMIT:raise ValueError('screening commit changed')
    entries={};excluded=[];indices=[];generated={}
    def addfile(member,path):
        if member in entries:raise ValueError('duplicate member')
        entries[member]={'path':str(path),'bytes':path.stat().st_size,'sha256':filehash(path),'kind':'retained_file'}
    def addbytes(member,raw,kind):
        if member in entries:raise ValueError('duplicate member')
        generated[member]=raw;entries[member]={'bytes':len(raw),'sha256':digest(raw),'kind':kind}
    def exclusion_tree(path,alias,reason):
        rows=[]
        if path.is_dir() and not path.is_symlink():
            iterator=path.rglob('*')
        else:iterator=[path]
        for p in sorted(iterator):
            if p.is_symlink():rows.append({'path':str(p),'kind':'symlink','target':os.readlink(p)})
            elif p.is_file():rows.append({'path':str(p),'kind':'file','bytes':p.stat().st_size,'sha256':filehash(p)})
        excluded.append({'root':str(path),'archive_namespace':alias,'reason':reason,
                         'file_count':sum(r['kind']=='file' for r in rows),
                         'bytes':sum(r.get('bytes',0) for r in rows),'entries':rows})
        if path.name=='.git' and path.is_dir():
            index=path/'index'
            if index.is_file():indices.append(index)
    def walk(alias,root):
        for folder,dirs,files in os.walk(root,followlinks=False):
            folder=Path(folder)
            for name in list(dirs):
                p=folder/name;rel=p.relative_to(root).as_posix();reason=None
                if p.is_symlink():reason='SYMLINK_NOT_FOLLOWED'
                elif name=='.git':reason='EXCLUDED_GENERATED_GIT_WORKING_STORE'
                elif name in ('site-packages','dist-packages','__pycache__'):
                    reason='EXCLUDED_GENERATED_PACKAGE_OR_BYTECODE_STORE'
                elif name in ('venv','.venv','miniconda-base','wheels') or (p/'pyvenv.cfg').is_file():
                    reason='EXCLUDED_GENERATED_ENVIRONMENT_OR_WHEEL_BULK'
                elif alias=='runtime-preparation' and rel in ('controller','modern-base',
                        'catalog-runtimes/cpython-3.6.5-pytest-5.4.3-linux-x86_64'):
                    reason='EXCLUDED_GENERATED_RUNTIME_ENVIRONMENT'
                if reason:
                    dirs.remove(name);exclusion_tree(p,alias+'/'+rel,reason)
            for name in sorted(files):
                p=folder/name;rel=p.relative_to(root).as_posix()
                if p.is_symlink():exclusion_tree(p,alias+'/'+rel,'SYMLINK_NOT_FOLLOWED')
                elif alias=='runtime-preparation' and (name.endswith(('.whl','.sh','.tar.bz2','.conda'))):
                    exclusion_tree(p,alias+'/'+rel,'EXCLUDED_RUNTIME_INSTALLER_OR_PACKAGE_BULK')
                elif p.is_file():addfile(alias+'/'+rel,p)
                else:exclusion_tree(p,alias+'/'+rel,'NONREGULAR_FILE_NOT_ARCHIVED')
    for alias,root in ROOTS.items():walk(alias,root)

    # Reproducible immutable source references cover all frozen source files;
    # source bytes include controller modules, workflows and the v3 record tree.
    listing=git('ls-tree','-r','-l',COMMIT,'--','research/unified_consequence_runtime','.github/workflows').decode().splitlines()
    source_rows=[];record_prefix='research/unified_consequence_runtime/archaeology/native-environment-v3/'
    for line in listing:
        header,name=line.split('\t',1);mode,kind,blob,length=header.split()
        raw=git('show',COMMIT+':'+name)
        row={'path':name,'mode':mode,'git_blob':blob,'bytes':len(raw),'sha256':digest(raw)}
        chosen=(name.startswith('.github/workflows/') or
            (name.startswith('research/unified_consequence_runtime/') and name.count('/')==2 and name.endswith('.py')) or
            (name.startswith(record_prefix) and Path(name).suffix in ('.py','.json','.md','.txt','.log','.yml','.yaml')))
        row['source_bytes_in_this_archive']=chosen
        if chosen:addbytes('committed-source/'+name,raw,'exact_committed_git_blob')
        source_rows.append(row)
    addbytes('provenance/COMMITTED_SOURCE_DESCRIPTORS.json',canonical({
        'schema':'UDM_SEALED_SCREENING_COMMITTED_SOURCE_DESCRIPTORS_V3','source_commit':COMMIT,
        'all_frozen_source_paths':source_rows,
        'omitted_source_bytes':'Historical versioned evidence/binary archives outside selected source set are not duplicated; exact Git commit/blob/SHA/size descriptors retained. This is not an omission of newly screened case source archives.'}), 'source_reference')

    index_path=Path(git('rev-parse','--git-path','index').decode().strip())
    if not index_path.is_absolute():index_path=REPO/index_path
    if index_path.is_file():indices.append(index_path.resolve())
    index_rows=[]
    for index,path in enumerate(sorted(set(indices),key=str)):
        member='audit-post-state/git-indices/index-'+format(index,'03d')+'.bin'
        raw=path.read_bytes();addbytes(member,raw,'bounded_current_post_audit_git_index')
        index_rows.append({'original_path':str(path),'member':member,'bytes':len(raw),'sha256':digest(raw)})
    addbytes('audit-post-state/CURRENT_INDICES_DISCLOSURE.json',canonical({
        'schema':'UDM_BOUNDED_POST_AUDIT_GIT_INDEX_CAPTURE_V3','capture_time_unix':time.time(),
        'current_indices':index_rows,'old_pre_audit_index_bytes_captured':False,
        'disclosure':'Independent audit git status refreshed eight index cache files. Original source/worktree/archives/manifests/reports/logs stayed unchanged. These are current post-audit bytes only; before-state hashes are in sealed audit detail/inventory and no recovery is claimed.'}), 'audit_mutation_disclosure')

    addfile('packaging/package_screening.py',Path(__file__).resolve())
    notes={
      'schema':'UDM_OPAQUE_SEALED_SCREENING_EVIDENCE_PACKAGE_V3','source_commit':COMMIT,
      'screened_cases':7,'eligible_count':0,'native_calls':0,'collection_calls':0,
      'terminal_state':'FIXED_POOL_SHORTFALL_NO_RESCREENING_NO_ROLE_FREEZE_NO_AGENT_ARM',
      'raw_source_or_native_outcomes_released_to_learner':False,
      'audit_status':'UNKNOWN_AUDIT_OBSTRUCTION',
      'audit_disclosures':['Eight Git index cache refreshes; bounded post-state only, old bytes not captured.',
        'A parsing traceback appeared only in authorized audit-agent tool context after redirection failure; no raw source text forwarded to root/learner/public JSON.'],
      'source_bound_omissions':[
        'Generated Git working stores excluded; all available newly screened source metadata/native archives and source worktree files outside excluded stores retained.',
        'Generated runtime/env/site-packages/installer/wheel bytes excluded. Exact runtime identities/inventories, package artifact hashes, bootstrap receipts and exclusion hashes retained; executable replay requires separately obtained qualified runtime/package artifacts.',
        'No prospective frontier FREEZE or acquired policy/agent context exists because zero tasks qualified; no missing artifact is manufactured.',
        'Versioned source omitted from committed-source/ is fully enumerated by exact Git commit/blob/byte/SHA descriptors, rather than duplicating historical evidence bulk.',
        'No authenticated copy of pre-audit Git index bytes is available.'],
      'cost_boundary':'Native/collection counts zero. Setup/operator/audit wall intervals nested/nonadditive; total model/tool/engineering lifecycle cost remains UNKNOWN.',
      'root_mappings':{key:str(value) for key,value in ROOTS.items()},
      'archive_paths':'Relative regular-file members only; no extraction or task-code execution performed.',
      'exclusions':excluded,
    }
    payload={**notes,'members':{name:{k:v for k,v in row.items() if k!='path'} for name,row in sorted(entries.items())}}
    addbytes('PAYLOAD_MANIFEST.json',canonical(payload),'embedded_payload_manifest_without_self_or_archive_hash')
    with tarfile.open(ARCHIVE,'w:gz',compresslevel=9) as archive:
        for name,row in sorted(entries.items()):
            info=tarfile.TarInfo(name);info.size=row['bytes'];info.mode=0o600;info.mtime=0;info.uid=0;info.gid=0
            if name in generated:archive.addfile(info,io.BytesIO(generated[name]))
            else:
                path=Path(row['path'])
                if path.stat().st_size!=row['bytes'] or filehash(path)!=row['sha256']:raise ValueError('input changed during packaging')
                with path.open('rb') as source:archive.addfile(info,source)
    # Stream readback verifies exact membership, regular types, size and SHA256.
    seen=set()
    with tarfile.open(ARCHIVE,'r:gz') as archive:
        for member in archive:
            if member.name in seen or not member.isfile() or member.name.startswith('/') or '..' in Path(member.name).parts:
                raise ValueError('unsafe or duplicate archive member')
            seen.add(member.name);h=hashlib.sha256();count=0
            with archive.extractfile(member) as source:
                for chunk in iter(lambda:source.read(1024*1024),b''):h.update(chunk);count+=len(chunk)
            expected=entries[member.name]
            if count!=expected['bytes'] or member.size!=count or h.hexdigest()!=expected['sha256']:
                raise ValueError('archive member readback differs')
    if seen!=set(entries):raise ValueError('archive membership differs')
    result={**notes,'archive':{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':filehash(ARCHIVE)},
      'members':{name:{k:v for k,v in row.items() if k!='path'} for name,row in sorted(entries.items())},
      'member_count':len(entries),'uncompressed_member_bytes':sum(row['bytes'] for row in entries.values()),
      'verification':{'status':'PASS_EXACT_STREAMING_READBACK','members_verified':len(seen),
        'all_member_sizes_and_sha256_equal':True,'archive_sha256_verified':True,'source_or_native_execution':False},
      'embedded_manifest_boundary':'PAYLOAD_MANIFEST.json omits its own and whole-archive hash to avoid circularity. This outer manifest binds every actual archive member including embedded manifest and whole archive.'}
    MANIFEST.write_bytes(canonical(result))
    print(json.dumps({'status':result['verification']['status'],'archive':result['archive'],
      'manifest':{'path':str(MANIFEST),'bytes':MANIFEST.stat().st_size,'sha256':filehash(MANIFEST)},
      'member_count':len(entries),'excluded_roots':len(excluded),'post_audit_indices':len(indices),
      'over_50MB':ARCHIVE.stat().st_size>=50_000_000},sort_keys=True),flush=True)

if __name__=='__main__':main()
