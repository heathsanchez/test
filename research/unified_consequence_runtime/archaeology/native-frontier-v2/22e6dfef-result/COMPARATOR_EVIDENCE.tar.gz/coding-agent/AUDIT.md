# Coding-agent arm evidence audit

This audit inspected only this arm's artifacts and the committed bridge interfaces at `22e6dfef6601e8f6c6a804ec05baab9f06b028b3`, with a byte comparison against the corresponding live interface files. It performed no native execution, source transport, or inspection of another arm, another qualification directory, target head production, PR body/patch/CI, or GitHub outcomes. This audit writes only this file.

## Finding

The executed attempt reached **native collection/admission refusal**. It was not a provisioning refusal: `training/admission.json` and `provision_return` both say `PREPARED`. Collection then exited 4 because the original `tests/conftest.py` refers to `pytest.collect.File`, unavailable under the fixed pytest 8.4.1 policy. The bridge raised `ValueError: UNKNOWN_COLLECTION_ERROR`. The final `RESULT.json` correctly narrows the original runner's generic `EXECUTED_ADMISSION_REFUSAL_OR_ERROR` to `EXECUTED_NATIVE_COLLECTION_REFUSAL`; the original action history remains intact.

Zero native test execution is supported by the retained raw evidence, rather than inferred from a preparation status. Both collection reports have empty `collected_test_nodes`, `selected_test_nodes`, and `reports`. The checked report records mode `collect`, process/pytest exit 4, and `timeout: false`.

| Quantity | Independently checked value |
| --- | ---: |
| Provisioning attempts | 1, returned `PREPARED` |
| Collection invocations | 1 |
| Native run invocations | 0 |
| Collected test nodes | 0 |
| Executed test call-phase reports | 0 |
| Independent certificate checks/recollections | 0 |
| Independent receipt checks/reexecutions | 0 |
| Candidate proposals | 0 |

The sole `checked-report.json` is under `training/collection`; it charges one collection call and zero native calls. Its raw producer report equals the checked report after removing the five controller-added fields. No admission certificate exists, so no certificate/receipt validation was reached. The original runner's `actual_native_tests` formula counts every pytest report phase, which would overcount executed tests in a nonzero run. That general counting defect does not change this run's zero. Finalization independently derives `collection_refusal.executed_test_calls` using `when == 'call'`; its top-level zero totals are constants consistent with the retained reports, not a general-purpose recount implementation.

## Measured costs and reporting boundary

| Measurement | Value | Meaning |
| --- | ---: | --- |
| Provision total wall | 13.712183253 s | Retained admission elapsed time |
| Sum of 15 setup phase durations | 13.157706826 s | Nested setup detail, not an additional charge above provision wall |
| Collection process wall | 0.371439844 s | Checked report elapsed time; excludes collection context preparation |
| Runner acquisition interval | 15.105840964 s | From recorded acquisition timer start to its finalization snapshot |
| Original freeze-check-start through stop event | 15.221355 s | UTC event span; excludes earlier import/process startup |
| Broader charged wall snapshot | 209.310028767 s | From acquisition timer start through finalization's stopwatch sample |
| Runner storage snapshot | 154,547,904 bytes | Pre-final-RESULT and pre-stop-log snapshot |
| Later regular-file logical bytes | 61,957,552 bytes | Excludes symlinks; before final report writes and audit completion |
| Later allocated bytes | 75,227,136 bytes | `du -s -B1` at that later snapshot |

The setup ledger has 15 phases, 12 with explicit external `argv` records. These are not a measured total count of all subprocesses or tool actions: bridge snapshot/context helpers perform further work. Provision, phase, collection, and acquisition elapsed times overlap and must not be added as disjoint lifecycle totals.

The original acquisition timer starts after imports, freeze checking, and metadata/policy/package reads; it stops before the original final byte scan, result save, and stop-event write. Final `RESULT.json` preserves this as `initial_attempt_acquisition_wall_seconds` and charges the broader 209.310028767-second snapshot as `total_acquisition_wall_seconds`. The broader interval includes the elapsed diagnosis/reporting/audit-wait period up to that sample, but its stopwatch is read before the later storage scan, COSTS/RESULT/REPORT writes, and audit completion. Final artifacts now label this boundary explicitly as **through the finalization snapshot**, not complete finalization or audit lifecycle. Earlier controller work and complete engineering/lifecycle costs remain unknown. Model tokens, model dollars, and tool dollars correctly remain `UNKNOWN`.

`persistent_bytes_at_result` is correctly a snapshot label, not a claim about finalized retained bytes. Its computation includes the earlier small RESULT file, then the script overwrites RESULT with the larger final object and appends the last action to both action/stdout logs. It also sums `stat().st_size` for paths satisfying `is_file()`, including file symlinks' target sizes. The later `COSTS.json` logical-byte snapshot explicitly excludes symlinks, so the two logical-byte figures have different counting bases and do not establish a drop in retained content. Later evidence, report, and audit writes further increase retention. The final artifacts correctly identify the storage snapshot as preceding their final writes and audit completion.

## Boundary compliance

`freeze_check_pass` precedes `provision_start`; the runner checks the supplied freeze digest and calls the original `check_freeze` before invoking provisioning. This supports freeze-before-first-target-source access for the recorded arm path. The flag's phrase “first source access” should be understood as target task source: bridge Python modules are imported before that check. This audit did not reread the freeze file because it is outside the authorized directory.

The final `FINAL_FREEZE_CHECK.json` at `06:01:52.602982+00:00` records another exact expected freeze-digest comparison followed by the original `check_freeze`. The finalizer was corrected during audit to add that explicit digest comparison and clarify the wall snapshot boundary. That correction reran finalization only; it did not rerun provisioning, collection, or tests. Both maintenance freeze checks are retained in the action log; their summed measured duration is 0.127780985 seconds. No outstanding mismatch remains between the final freeze/wall wording and the finalizer implementation.

The live `qualify_native_frontier_v2.py`, `native_environment_v2.py`, and `native_execution_v2.py` bytes equal their committed versions. The runner directly calls the unchanged provisioner and collection verifier with the saved policy and 38 package pins. Saved policy/package hashes match the hashes declared in the protocol. Contract, authority, policy, and source-boundary sidecars equal the corresponding admission fields. A manifest-only comparison shows exactly one base-to-augmented tracked entry changed: the declared independently authored `tests/test_monkey_patching.py`. No production manifest entry changed. The admission boundary records `head_production_fetched: false` and `production_preserved: true`.

The action history stops native activity immediately after the collection exception. There is no compatibility shim, policy change, alternate dependency selection, fallback collection, candidate test, or future-source operation in the executed path. The later recorded minimal inspection concerns the original training base conftest. Futures remain unopened in the recorded arm, with no proposal or policy choice. The logs support this arm-local ordering; they are not a universal proof about unrecorded external history.

All G2–G6 verdicts properly remain `UNKNOWN`. This attempt establishes an observed refusal at the frozen native interface. It does not establish a complete failing native residual, a failed repair search, constructor-language inadequacy, a future outcome, or coding-agent/other-system superiority.
