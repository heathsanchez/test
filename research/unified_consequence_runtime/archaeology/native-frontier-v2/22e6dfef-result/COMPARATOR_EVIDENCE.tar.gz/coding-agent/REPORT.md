# Executed coding-agent comparator

**Verdict: executed native collection refusal; 0 native tests.** Training preparation succeeded, but the unchanged qualified v2 worker refused admission before any test was collected or executed.

The exact supplied freeze SHA256 `a74d3c0811dd919dcdf59427aa49b710c46a7ab2af58ed441a3a25bd22f3ebac` passed original `check_freeze` before first task-source access and again at finalization. Only training `grahamdumpleton/wrapt` PR 99 was opened. Original `provision` fetched exact base production and the metadata-authorized author test blob, preserved production, built its native wheel, installed the frozen 38-package closure, and returned `PREPARED` in 13.712183 seconds.

The first real native collection exited **4** with `UNKNOWN_COLLECTION_ERROR`. Its complete stderr identifies original `tests/conftest.py:7`: `class DummyCollector(pytest.collect.File)`. Frozen pytest **8.4.1** has no `pytest.collect` attribute. The exact original base file was confirmed from commit `b2e4759d31b3e4815077f03aeefea9ceadc67530`, blob `7d3b2fa1fe3d33674e3bc8f7b06c969a2dc88070`. No source, dependency, plugin, skip/xfail, verifier, or protected-assertion authority was changed.

Measured execution: **1 collection invocation, 0 native run calls, 0 collected/selected/executed test calls**. No certificate existed, so independent certificate checking, native execution, and independent receipt reexecution were unreachable. No candidate/catalog/policy search was run, no policy was chosen, and both protected futures remain unopened.

The initial source-preparation-through-refusal acquisition interval was **15.105841 s**. The charged interval from first source preparation through this finalization snapshot, including diagnosis/reporting and audit wait so far, was **209.310029 s**. It excludes the subsequent storage scan/final writes and remaining audit time. Collection worker time was **0.371440 s** within its 60 s horizon. Detailed setup/build/transport/source-derivation costs and storage snapshots are in `COSTS.json`; nested wall times are nonadditive. Model tokens/dollars, tool dollars, earlier controller/interface-reading totals, engineering time, and future maintenance remain **UNKNOWN**.

This is an actually executed coding-agent admission refusal. It establishes no measured protected-outcome tie, G4 advantage, policy-development success, or complete language inadequacy. G2–G6 remain UNKNOWN.

Primary evidence: `RESULT.json`, `actions.jsonl`, `TOOL_ACTION_LOG.md`, `stdout.log`, `stderr.log`, `training/admission.json`, `training/collection/stderr.log`, `training/collection/checked-report.json`, `OBSTRUCTION_SOURCE.json`, and `AUDIT.md`.
