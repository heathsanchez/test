"""Summarize retained measurements without changing the experiment or rerunning it."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path('/workspace/qualification/native-frontier-v2-coding-agent')
REPO = Path('/workspace/udm-v54')
sys.path.insert(0, str(REPO))
from research.unified_consequence_runtime.qualify_native_frontier_v2 import check_freeze

def save(name, value):
    (OUT/name).write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')

result = json.loads((OUT/'RESULT.json').read_text())
setup = json.loads((OUT/'training/admission.json').read_text())
report = json.loads((OUT/'training/collection/checked-report.json').read_text())
freeze_started = time.monotonic()
freeze_digest = hashlib.sha256(Path('/workspace/qualification/native-frontier-v2-freeze/FREEZE.json').read_bytes()).hexdigest()
if freeze_digest != result['freeze_sha256']:
    raise ValueError('Exact supplied freeze SHA256 changed before finalization')
frozen = check_freeze(REPO, '/workspace/qualification/native-frontier-v2-freeze/FREEZE.json')
freeze_seconds = time.monotonic()-freeze_started
freeze_end = {'status':'PASS', 'source_commit':frozen['source_commit'], 'seconds':freeze_seconds,
              'at_utc':dt.datetime.now(dt.timezone.utc).isoformat(), 'freeze_sha256':freeze_digest,
              'expected_freeze_sha256_matched':True}
save('FINAL_FREEZE_CHECK.json', freeze_end)
with (OUT/'actions.jsonl').open('a') as stream:
    stream.write(json.dumps({'action':'final_freeze_check', **freeze_end}, sort_keys=True)+'\n')

result['status'] = 'EXECUTED_NATIVE_COLLECTION_REFUSAL'
result['preparation_status'] = setup['status']
result['smallest_obstruction'] = 'UNKNOWN_COLLECTION_ERROR: original tests/conftest.py:7 subclasses pytest.collect.File; frozen pytest 8.4.1 has no pytest.collect attribute.'
result['collection_refusal'] = {'worker_error':'UNKNOWN_COLLECTION_ERROR', 'process_exit_code':report['process_exit_code'],
    'collected_nodes':len(report['collected_test_nodes']), 'selected_nodes':len(report['selected_test_nodes']),
    'executed_test_calls':len([row for row in report.get('reports',[]) if row.get('when')=='call']),
    'raw_stderr':'training/collection/stderr.log', 'raw_report':'training/collection/checked-report.json'}
result['actual_native_tests'] = 0
result['actual_native_calls'] = 0
result['actual_collection_calls'] = 1
result['independent_certificate_check'] = 'NOT_REACHED_NO_ADMISSION_CERTIFICATE'
result['independent_native_receipt_check'] = 'NOT_REACHED_NO_NATIVE_RECEIPT'
result['catalog_and_original_orders'] = 'NOT_REACHED_NO_COMPLETE_NATIVE_FAILING_OBLIGATION'
result['policy_choice'] = None
result['policy_choice_frozen'] = False
result['futures_remain_unopened'] = True
result['no_maintenance_interventions_or_restoration_tests'] = True
result['verdict_limit'] = 'Executed admission refusal with 0 native tests; this does not measure a protected-outcome tie, a G4 advantage, or complete language inadequacy.'
result['final_frozen_source_check'] = freeze_end

diagnosis = json.loads((OUT/'OBSTRUCTION_SOURCE.json').read_text())
initial_interval = result.get('initial_attempt_acquisition_wall_seconds', result['total_acquisition_wall_seconds'])
charged = time.monotonic()-result['acquisition_started_monotonic']
snapshot_at = dt.datetime.now(dt.timezone.utc).isoformat()
regular = [p for p in OUT.rglob('*') if p.is_file() and not p.is_symlink()]
regular_bytes = sum(p.stat().st_size for p in regular)
allocated = int(subprocess.check_output(['du','-s','-B1',str(OUT)],text=True).split()[0])
costs = {
    'schema':'UDM_EXECUTED_CODING_AGENT_COSTS_V2',
    'initial_attempt_acquisition_wall_seconds':initial_interval,
    'initial_attempt_interval':'Recorded monotonic start immediately before source preparation through refusal accounting; excludes earlier controller imports/interface reading and later reporting.',
    'charged_wall_seconds_from_first_source_preparation_to_finalization_snapshot':charged,
    'provision_wall_seconds':setup['total_wall_seconds'],
    'provision_phases':setup['costs'],
    'collection_worker_costs':report['costs'],
    'collection_context_and_refusal_overhead':'Included in initial attempt acquisition wall; no separate stopwatch retained.',
    'diagnosis_source_read_seconds':diagnosis['seconds'],
    'final_freeze_check_seconds':freeze_seconds,
    'actual_collection_calls':1, 'actual_native_calls':0, 'actual_native_test_calls':0,
    'independent_recollection_calls':0, 'independent_native_reexecution_calls':0,
    'proposals':0, 'catalog_calls':0, 'policy_order_searches':0,
    'storage_snapshot':{'at_utc':snapshot_at, 'regular_file_count':len(regular), 'logical_regular_file_bytes':regular_bytes,
        'allocated_bytes_du':allocated, 'boundary':'Includes environment/build/source/raw evidence and comparator code; taken before this final COSTS/RESULT/REPORT write and audit completion.'},
    'maintenance_and_reclosure':{'frozen_source_revalidation_seconds':sum(json.loads(line).get('seconds',0) for line in (OUT/'actions.jsonl').read_text().splitlines() if json.loads(line).get('action')=='final_freeze_check'), 'causal_interventions':0,
        'prospective_storage_duration':'UNKNOWN', 'future_maintenance_cost':'UNKNOWN'},
    'cost_nesting':'Provision phases, collection worker time, and source inspection are components of broader wall intervals. Do not sum nested wall values.',
    'model_tokens':'UNKNOWN', 'model_dollars':'UNKNOWN', 'tool_dollars':'UNKNOWN', 'engineering_time':'UNKNOWN',
    'pre_source_controller_interface_read_setup_tool_wall_total':'UNKNOWN',
}
save('COSTS.json', costs)
result['cost_summary_path'] = str(OUT/'COSTS.json')
result['initial_attempt_acquisition_wall_seconds'] = initial_interval
result['total_acquisition_wall_seconds'] = charged
result['wall_boundary'] = 'Inclusive measured wall from immediately before first source preparation through the finalization snapshot, including diagnosis/reporting/audit wait so far. Excludes subsequent storage scan/final writes and any remaining audit time. Earlier interface-reading/controller/model/tool totals remain UNKNOWN.'
if not isinstance(result['persistent_bytes_at_result'], dict):
    result['persistent_bytes_at_result'] = {'value':result['persistent_bytes_at_result'], 'boundary':'Initial script snapshot before its final RESULT write and action log append; follows file symlinks. See COSTS.json for later regular-file storage snapshot.'}
save('RESULT.json', result)

text = f'''# Executed coding-agent comparator

**Verdict: executed native collection refusal; 0 native tests.** Training preparation succeeded, but the unchanged qualified v2 worker refused admission before any test was collected or executed.

The exact supplied freeze SHA256 `{result['freeze_sha256']}` passed original `check_freeze` before first task-source access and again at finalization. Only training `grahamdumpleton/wrapt` PR 99 was opened. Original `provision` fetched exact base production and the metadata-authorized author test blob, preserved production, built its native wheel, installed the frozen 38-package closure, and returned `PREPARED` in {setup['total_wall_seconds']:.6f} seconds.

The first real native collection exited **4** with `UNKNOWN_COLLECTION_ERROR`. Its complete stderr identifies original `tests/conftest.py:7`: `class DummyCollector(pytest.collect.File)`. Frozen pytest **8.4.1** has no `pytest.collect` attribute. The exact original base file was confirmed from commit `b2e4759d31b3e4815077f03aeefea9ceadc67530`, blob `{diagnosis['git_blob']}`. No source, dependency, plugin, skip/xfail, verifier, or protected-assertion authority was changed.

Measured execution: **1 collection invocation, 0 native run calls, 0 collected/selected/executed test calls**. No certificate existed, so independent certificate checking, native execution, and independent receipt reexecution were unreachable. No candidate/catalog/policy search was run, no policy was chosen, and both protected futures remain unopened.

The initial source-preparation-through-refusal acquisition interval was **{initial_interval:.6f} s**. The charged interval from first source preparation through this finalization snapshot, including diagnosis/reporting and audit wait so far, was **{charged:.6f} s**. It excludes the subsequent storage scan/final writes and remaining audit time. Collection worker time was **{report['costs']['seconds']:.6f} s** within its 60 s horizon. Detailed setup/build/transport/source-derivation costs and storage snapshots are in `COSTS.json`; nested wall times are nonadditive. Model tokens/dollars, tool dollars, earlier controller/interface-reading totals, engineering time, and future maintenance remain **UNKNOWN**.

This is an actually executed coding-agent admission refusal. It establishes no measured protected-outcome tie, G4 advantage, policy-development success, or complete language inadequacy. G2–G6 remain UNKNOWN.

Primary evidence: `RESULT.json`, `actions.jsonl`, `TOOL_ACTION_LOG.md`, `stdout.log`, `stderr.log`, `training/admission.json`, `training/collection/stderr.log`, `training/collection/checked-report.json`, `OBSTRUCTION_SOURCE.json`, and `AUDIT.md`.
'''
(OUT/'REPORT.md').write_text(text)
print(json.dumps({'status':result['status'], 'actual_native_calls':0, 'actual_collection_calls':1,
                  'charged_wall_seconds':charged, 'output':str(OUT)},sort_keys=True))
