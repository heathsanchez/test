"""Independent coding-agent arm; immutable original v2 preparation and verifier."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import pathlib
import sys
import time
import traceback

REPO = pathlib.Path('/workspace/udm-v54')
OUT = pathlib.Path('/workspace/qualification/native-frontier-v2-coding-agent')
FREEZE = pathlib.Path('/workspace/qualification/native-frontier-v2-freeze/FREEZE.json')
EXPECTED_FREEZE = 'a74d3c0811dd919dcdf59427aa49b710c46a7ab2af58ed441a3a25bd22f3ebac'
EXPECTED_COMMIT = '22e6dfef6601e8f6c6a804ec05baab9f06b028b3'
sys.path.insert(0, str(REPO))
from research.unified_consequence_runtime import qualify_native_frontier_v2 as frontier
from research.unified_consequence_runtime import native_environment_v2 as environment
from research.unified_consequence_runtime import native_execution_v2 as worker

def save(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def log(action, **details):
    row = {'at_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'action': action, **details}
    with (OUT / 'actions.jsonl').open('a') as stream:
        stream.write(json.dumps(row, sort_keys=True) + '\n')
    print(json.dumps(row, sort_keys=True), flush=True)

result = {
    'schema': 'UDM_EXECUTED_CODING_AGENT_NATIVE_RESULT_V2',
    'source_commit': EXPECTED_COMMIT,
    'freeze_sha256': EXPECTED_FREEZE,
    'status': 'INITIALIZING',
    'independence': 'No other live arm results inspected; no target head production or PR body/patch/CI inspected.',
    'futures_remain_unopened': True,
    'proposals': [],
    'policy_choice': None,
    'verdicts': {'G2': 'UNKNOWN', 'G3': 'UNKNOWN', 'G4': 'UNKNOWN', 'G5': 'UNKNOWN', 'G6': 'UNKNOWN'},
}
started = None
try:
    log('freeze_check_start', path=str(FREEZE), expected_sha256=EXPECTED_FREEZE)
    raw = FREEZE.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != EXPECTED_FREEZE:
        raise ValueError('Exact supplied freeze SHA256 differs')
    frozen = frontier.check_freeze(REPO, FREEZE)
    if frozen['source_commit'] != EXPECTED_COMMIT:
        raise ValueError('Exact supplied frozen commit differs')
    save('FREEZE_CHECK.json', {'status': 'PASS', 'sha256': actual, 'source_commit': frozen['source_commit'],
                               'checked_before_first_source_access': True})
    log('freeze_check_pass', sha256=actual, source_commit=frozen['source_commit'])
    protocol = frontier.protocol()
    metadata = json.loads(frontier.METADATA.read_text())
    policy = json.loads((REPO / protocol['policy']['path']).read_text())
    packages = json.loads((REPO / protocol['packages']['path']).read_text())
    save('PROTOCOL.json', protocol)
    save('TRAINING_SPEC.json', metadata['selected'][0])
    save('POLICY.json', policy)
    save('PACKAGES.json', packages)
    spec = metadata['selected'][0]
    if spec['role'] != 'TRAINING':
        raise ValueError('First frozen task must be training')
    result['training'] = {'repository': spec['repo'], 'pr': spec['pr'], 'base_commit': spec['base_commit'],
                          'source_opened': False}
    result['limits'] = {'total_native_calls': 128, 'total_acquisition_wall_seconds': 1200,
                        'proposals_per_search': 8, 'future_horizon': 8}
    started = time.monotonic()
    result['acquisition_started_at_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    result['acquisition_started_monotonic'] = started
    result['training']['source_opened'] = True
    result['status'] = 'PREPARING_TRAINING'
    save('RESULT.json', result)
    log('provision_start', repository=spec['repo'], pr=spec['pr'], binding=actual,
        original_function='native_environment_v2.provision', packages=len(packages))
    setup = environment.provision(spec, OUT/'training', protocol_binding=actual, policy=policy, packages=packages)
    result['training']['setup'] = setup
    log('provision_return', status=setup['status'], reason=setup.get('reason'),
        total_wall_seconds=setup['total_wall_seconds'])
    if setup['status'] != 'PREPARED':
        result['status'] = 'EXECUTED_PREPARATION_REFUSAL'
        result['smallest_obstruction'] = setup.get('reason', setup['status'])
    else:
        def check_budget():
            if time.monotonic() - started >= 1200:
                raise ValueError('UNKNOWN_ACQUISITION_BUDGET: 1200s inclusive wall ceiling')
        check_budget()
        log('native_collection_start')
        certificate = worker.collect(setup['contract'], setup['authority'], OUT/'training'/'collection', policy=policy)
        result['training']['certificate'] = certificate
        log('native_collection_return', status=certificate['status'], costs=certificate['costs'])
        check_budget()
        log('independent_certificate_check_start')
        checked = worker.validate_certificate(setup['contract'], setup['authority'], certificate, policy=policy,
                                              output_dir=OUT/'training'/'independent-collection')
        save('INDEPENDENT_CERTIFICATE_CHECK.json', checked)
        log('independent_certificate_check_return', costs=checked['independent_recollection']['costs'])
        check_budget()
        log('native_baseline_start')
        candidate = {'replacements': []}
        receipt = worker.verify(setup['contract'], candidate, OUT/'training'/'baseline', authority=setup['authority'],
                                admission_certificate=certificate, policy=policy)
        result['training']['baseline'] = receipt
        log('native_baseline_return', status=receipt['status'], junit=receipt['junit'], costs=receipt['costs'])
        check_budget()
        log('independent_baseline_receipt_check_start')
        checked_receipt = worker.validate_receipt(setup['contract'], candidate, setup['authority'], certificate,
            receipt, policy=policy, output_dir=OUT/'training'/'independent-baseline', independent=True)
        save('INDEPENDENT_BASELINE_CHECK.json', checked_receipt)
        log('independent_baseline_receipt_check_return', status=checked_receipt['status'],
            costs=checked_receipt['independent_reexecution']['costs'])
        result['status'] = 'COMPLETE_NATIVE_TRAINING_RESIDUAL' if receipt['status'] == 'FAIL_NATIVE' else 'NO_COMPLETE_FAILING_NATIVE_TRAINING_RESIDUAL'
        result['smallest_obstruction'] = None if receipt['status'] == 'FAIL_NATIVE' else receipt['status']
except BaseException as error:
    result['status'] = 'EXECUTED_ADMISSION_REFUSAL_OR_ERROR'
    result['smallest_obstruction'] = type(error).__name__ + ': ' + str(error)
    save('ERROR.json', {'type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()})
    log('exception', type=type(error).__name__, error=str(error))
    traceback.print_exc()
finally:
    native = []
    collections = []
    for path in sorted((OUT/'training').rglob('checked-report.json')) if (OUT/'training').exists() else []:
        report = json.loads(path.read_text())
        entry = {'path': str(path), 'mode': report.get('mode'), 'costs': report.get('costs', {}),
                 'exit_code': report.get('process_exit_code'), 'timeout': report.get('timeout')}
        (native if report.get('mode') == 'run' else collections).append(entry)
    result['actual_native_calls'] = sum(row['costs'].get('native_calls', 0) for row in native)
    result['actual_collection_calls'] = sum(row['costs'].get('collection_calls', 0) for row in collections)
    result['actual_native_tests'] = sum(json.loads(pathlib.Path(row['path']).read_text()).get('reports', []).__len__()
                                        for row in native)
    result['raw_native_invocations'] = native
    result['raw_collection_invocations'] = collections
    result['total_acquisition_wall_seconds'] = time.monotonic() - started if started is not None else 0
    result['model_tokens'] = 'UNKNOWN'
    result['model_dollars'] = 'UNKNOWN'
    result['tool_cost_dollars'] = 'UNKNOWN'
    result['persistent_bytes_at_result'] = sum(path.stat().st_size for path in OUT.rglob('*') if path.is_file())
    save('RESULT.json', result)
    log('preparation_arm_stopped', status=result['status'], native_calls=result['actual_native_calls'],
        collection_calls=result['actual_collection_calls'], total_acquisition_wall_seconds=result['total_acquisition_wall_seconds'])
