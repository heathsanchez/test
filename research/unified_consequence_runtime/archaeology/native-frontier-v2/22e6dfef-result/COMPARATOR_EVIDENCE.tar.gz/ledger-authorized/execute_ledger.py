"""Comparator instrumentation only: invoke exact frozen admission APIs unchanged."""
import datetime,hashlib,json,pathlib,sys,time,traceback
ROOT=pathlib.Path('/workspace/qualification/native-frontier-v2-ledger-authorized')
REPO=pathlib.Path('/workspace/udm-v54');sys.path.insert(0,str(REPO))
FREEZE=pathlib.Path('/workspace/qualification/native-frontier-v2-freeze/FREEZE.json')
EXPECTED='a74d3c0811dd919dcdf59427aa49b710c46a7ab2af58ed441a3a25bd22f3ebac'
rows=[];phase='freeze'
def audit(event,args):
 if event=='subprocess.Popen':
  row={'phase':phase,'monotonic':time.monotonic(),'argv':[str(x) for x in args[1]],'cwd':str(args[2])};rows.append(row)
  with (ROOT/'SUBPROCESS_INVOCATIONS.jsonl').open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n')
sys.addaudithook(audit)
def write(name,value):(ROOT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
started=time.monotonic()
r={'schema':'UDM_ACTUAL_INFORMED_LEDGER_ADMISSION_V2','status':'RUNNING','arm':'fully_informed_executable_ledger','source_commit':'22e6dfef6601e8f6c6a804ec05baab9f06b028b3','freeze_sha256':EXPECTED,'native_calls':0,'collection_calls':0,'candidate_proposals':0,'futures_remain_unopened':True,'comparison':'UNKNOWN','prior_credential_failure_preserved':'../native-frontier-v2-ledger-execution/RESULT.json','authority_note':'Same existing authorized root tool environment; no credentials, endpoints, permissions, protocol or source were changed. Prior per-agent credential failure is retained.','model_token_dollar_and_engineering_cost':'UNKNOWN'}
try:
 from research.unified_consequence_runtime.qualify_native_frontier_v2 import check_freeze,protocol,METADATA
 from research.unified_consequence_runtime.native_environment_v2 import provision
 from research.unified_consequence_runtime import native_execution_v2 as worker
 assert hashlib.sha256(FREEZE.read_bytes()).hexdigest()==EXPECTED
 frozen=check_freeze(REPO,FREEZE);write('FREEZE_CHECK.json',{'status':'PASS','freeze':frozen})
 value=protocol();policy=json.loads((REPO/value['policy']['path']).read_text());packages=json.loads((REPO/value['packages']['path']).read_text())
 spec=dict(json.loads(METADATA.read_text())['selected'][0],role='TRAINING');write('INPUTS.json',{'spec':spec,'policy':policy,'packages':packages,'protocol_sha256':frozen['protocol_sha256']})
 r['first_source_preparation_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();phase='provision'
 setup=provision(spec,ROOT/'task-0',EXPECTED,policy=policy,packages=packages);r['setup_status']=setup['status'];r['setup_wall_seconds']=setup['total_wall_seconds']
 r['setup_receipt_sha256']=hashlib.sha256((ROOT/'task-0/admission.json').read_bytes()).hexdigest()
 if setup['status']!='PREPARED':r.update(status='UNKNOWN_SETUP',reason=setup.get('reason'))
 else:
  assert time.monotonic()-started<1200
  phase='collection';cert=worker.collect(setup['contract'],setup['authority'],ROOT/'collection',policy=policy)
  phase='independent_collection';worker.validate_certificate(setup['contract'],setup['authority'],cert,policy=policy,output_dir=ROOT/'independent-collection')
  assert time.monotonic()-started<1200
  phase='native';receipt=worker.verify(setup['contract'],{'replacements':[]},ROOT/'native',authority=setup['authority'],admission_certificate=cert,policy=policy)
  r.update(status=receipt['status'],native_receipt=receipt)
except BaseException as error:
 r.update(status='UNKNOWN_NATIVE_ADMISSION',reason=str(error),error_type=type(error).__name__);write('ERROR.json',{'error':str(error),'type':type(error).__name__,'traceback':traceback.format_exc()})
finally:
 costs=[]
 for p in ROOT.rglob('checked-report.json'):
  if any(x in {'venv','.git','source','base-build'} for x in p.relative_to(ROOT).parts):continue
  v=json.loads(p.read_text());costs.append({'path':str(p.relative_to(ROOT)),'mode':v.get('mode'),'costs':v.get('costs',{}),'process_exit_code':v.get('process_exit_code')})
 r.update(wall_seconds=time.monotonic()-started,raw_subprocess_costs=costs,native_calls=sum(x['costs'].get('native_calls',0) for x in costs),collection_calls=sum(x['costs'].get('collection_calls',0) for x in costs),subprocess_invocations=len(rows),python_executable=sys.executable)
 r['verdicts']={k:'UNKNOWN' for k in ['G2','G3','G4','G5','G6']};write('RESULT.json',r);check_freeze(REPO,FREEZE)
 print(json.dumps({k:r[k] for k in ['status','reason','wall_seconds','native_calls','collection_calls','candidate_proposals','comparison']},sort_keys=True))
