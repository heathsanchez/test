# Actual executable-ledger arm

The actual deterministic fully informed executable-ledger comparator stopped on the unchanged first training-task admission refusal. Its comparison is **UNKNOWN**, with **0 native calls, 0 collection calls and 0 candidate proposals**. No tie or superiority claim is licensed.

The existing `check_freeze` passed for commit `22e6dfef6601e8f6c6a804ec05baab9f06b028b3`, all 442 frozen files, protocol and the exact qualified `f8c0b06d` admission gate. The FREEZE byte SHA-256 was `a74d3c0811dd919dcdf59427aa49b710c46a7ab2af58ed441a3a25bd22f3ebac` and was passed as the unchanged `native_environment_v2.provision` binding. The frozen execution policy and all 38 package pins were supplied unchanged.

Only the first selected metadata task, `grahamdumpleton/wrapt` PR 99, was provisioned. The exact base `b2e4759d31b3e4815077f03aeefea9ceadc67530` was fetched, checked out, fingerprinted and archived. Its 71 tracked files have Git tree `ffcd89743964417eb5aab35f025c1321464a1837` and tracked-tree SHA-256 `fe5d5d28e9f4d8187816c669cb083f0ee1104d0e5219f31aba22d81bee7ec454`.

The original author-test transport was actually invoked:

```
gh api repos/grahamdumpleton/wrapt/contents/tests/test_monkey_patching.py?ref=33148ea028b7a915bb0294c6c49773d4168e96d8
```

It exited 1 with HTTP 401, `Bad credentials`. The unchanged provisioner retained `UNKNOWN_SETUP` with reason `UNKNOWN_SETUP:author-test-0` in `task-0/admission.json`. That exact receipt and the original raw `task-0/author-test-0.log` are preserved. No fallback, credential alteration, retargeting or retry was attempted.

The invocation audit began before `check_freeze` and contains 79 subprocess launches, exclusively `git` and `gh`; no native runner or Python subprocess launched. The provisioner stopped before environment creation, package installation, builds, collection, certificate validation or native verification. Its `production_preserved=false` field records that author-test-overlay validation was not reached. The fetched base remains the exact source in `base-source.tar.gz`; repaired head production was not fetched. Future task source remains unopened.

The first preparation consumed 1.5122684159941855 measured seconds; the wrapper total, original phase costs, raw phase logs, source archive/identity and subprocess timestamps are retained in `COSTS.json`, `TOOL_LOG.json`, `SUBPROCESS_INVOCATIONS.jsonl` and `task-0/`. Nested wall times are nonadditive. Model tokens, dollar cost and uninstrumented preflight/report engineering time remain UNKNOWN. Original phase logging combines stdout/stderr; wrapper stdout and stderr are separate files. No source, Git history, protocol or external application was changed.

The 128 native-call, eight-proposal-per-search and 1200-second ceilings were not consumed by a search. Admission refusal licenses neither a protected-future opening nor a policy choice, native outcome, tie or developmental superiority claim.

A follow-up credential-origin check found a present, nonempty inherited `GH_TOKEN`, no `GITHUB_TOKEN` or gh config override, and no stored gh configuration files. Token values and credential file contents were not read or printed. The wrapper made no environment changes and supplied no `env=` override. No arm-introduced credential problem was found to correct; no additional network request, retry or alternate transport route was used. This diagnostic is retained in `CREDENTIAL_CONFIGURATION_CHECK.json`.

An independent read-only subagent audit passed admission provenance: all four raw log hashes, 79 invocations, the exact training task and frozen pins, and all 71 base blobs/archive identities agree. Its finding is saved in `INDEPENDENT_ADMISSION_AUDIT.json`. This verifies admission provenance only; native receipt validation was not reached.
