"""Audit wrapper; calls the frozen preparation implementation without changes."""
import contextlib
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path('/workspace/qualification/native-frontier-v2-ledger-execution')
REPO = Path('/workspace/udm-v54')
FREEZE = Path('/workspace/qualification/native-frontier-v2-freeze/FREEZE.json')
EXPECTED = 'a74d3c0811dd919dcdf59427aa49b710c46a7ab2af58ed441a3a25bd22f3ebac'
sys.path.insert(0, str(REPO))
audit = (ROOT / 'SUBPROCESS_INVOCATIONS.jsonl').open('a', buffering=1)
phase = 'startup'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def log_audit(event, args):
    if event == 'subprocess.Popen':
        executable, argv, cwd, env = args
        # Environment values may contain credentials and are deliberately omitted.
        row = {'event': event, 'phase': phase, 'utc': utc(),
               'monotonic': time.monotonic(), 'executable': os.fsdecode(executable),
               'argv': [os.fsdecode(x) for x in argv] if isinstance(argv, (list, tuple)) else os.fsdecode(argv),
               'cwd': None if cwd is None else os.fsdecode(cwd)}
        audit.write(json.dumps(row, sort_keys=True) + '\n')

sys.addaudithook(log_audit)

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

started = time.monotonic()
actions = []
result = {'schema': 'ACTUAL_FULLY_INFORMED_EXECUTABLE_LEDGER_ARM_V1',
          'arm': 'fully_informed_executable_ledger',
          'status': 'RUNNING_ADMISSION', 'source_commit': '22e6dfef6601e8f6c6a804ec05baab9f06b028b3',
          'freeze_sha256': EXPECTED, 'native_calls': None,
          'futures_remain_unopened': True,
          'verdicts': {'G2': 'UNKNOWN', 'G3': 'UNKNOWN', 'G4': 'UNKNOWN', 'G5': 'UNKNOWN', 'G6': 'UNKNOWN'},
          'comparison': 'UNKNOWN', 'candidate_proposals': 0,
          'budget': {'native_calls_including_verification': 128, 'wall_seconds_from_first_preparation': 1200,
                     'proposals_per_declared_search': 8},
          'external_actions': 'NONE; acquisition grants no external permission',
          'cost_boundary': 'Nested wall times are nonadditive. Model token/dollar/engineering costs UNKNOWN unless measured.'}
with (ROOT / 'admission.stdout.log').open('w') as stdout, (ROOT / 'admission.stderr.log').open('w') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            phase = 'check_freeze'
            before = time.monotonic()
            from research.unified_consequence_runtime.qualify_native_frontier_v2 import check_freeze, protocol, METADATA
            actual_digest = sha(FREEZE.read_bytes())
            if actual_digest != EXPECTED:
                raise ValueError('supplied freeze file digest differs')
            frozen = check_freeze(REPO, FREEZE)
            write('FREEZE_CHECK.json', {'status': 'PASS', 'source_commit': frozen['source_commit'],
                                       'freeze_sha256': actual_digest, 'files_checked': len(frozen['files']),
                                       'admission_gate': frozen['admission_gate']})
            actions.append({'phase': phase, 'status': 'PASS', 'seconds': time.monotonic()-before,
                            'function': 'qualify_native_frontier_v2.check_freeze', 'arguments': [str(REPO), str(FREEZE)]})
            value = protocol()
            # Only the first selected metadata task is provided to provisioning.
            task = dict(json.loads(METADATA.read_text())['selected'][0], role='TRAINING')
            policy_path = REPO / value['policy']['path']
            packages_path = REPO / value['packages']['path']
            policy = json.loads(policy_path.read_text())
            packages = json.loads(packages_path.read_text())
            if len(packages) != 38:
                raise ValueError('expected unchanged 38 pinned packages')
            write('INPUTS.json', {'training_task': task, 'protocol_sha256': frozen['protocol_sha256'],
                                 'freeze_sha256': actual_digest, 'policy': policy, 'packages': packages,
                                 'policy_sha256': sha(policy_path.read_bytes()),
                                 'packages_sha256': sha(packages_path.read_bytes()),
                                 'interpreter': sys.executable})
            from research.unified_consequence_runtime.native_environment_v2 import provision
            phase = 'native_environment_v2.provision'
            preparation_started = time.monotonic()
            write('CLOCK.json', {'first_preparation_utc': utc(), 'first_preparation_monotonic': preparation_started,
                                'first_preparation_epoch_seconds': time.time(), 'deadline_monotonic': preparation_started + 1200})
            admission = provision(task, ROOT / 'task-0', actual_digest, policy=policy, packages=packages)
            actions.append({'phase': phase, 'status': admission['status'], 'seconds': time.monotonic()-preparation_started,
                            'function': 'native_environment_v2.provision', 'arguments': {'spec': 'INPUTS.json:training_task',
                            'root': str(ROOT/'task-0'), 'protocol_binding': actual_digest, 'policy': 'INPUTS.json:policy',
                            'packages': 'INPUTS.json:packages'}})
            result['admission_receipt_path'] = str(ROOT/'task-0/admission.json')
            result['admission_status'] = admission['status']
            result['admission_receipt_sha256'] = sha((ROOT/'task-0/admission.json').read_bytes())
            result['reason'] = admission.get('reason')
            result['setup_costs'] = admission['costs']
            result['source_boundaries'] = admission['source_boundaries']
            result['first_preparation_wall_seconds'] = time.monotonic()-preparation_started
            result['status'] = ('PREPARED_AWAITING_ORIGINAL_COLLECTION_AND_VERIFICATION' if admission['status']=='PREPARED'
                                else 'UNKNOWN_ADMISSION_REFUSAL')
            result['stopped_on_admission_refusal'] = admission['status'] != 'PREPARED'
        except BaseException as error:
            result.update(status='UNKNOWN_EXECUTION_ERROR', reason=repr(error))
            traceback.print_exc()
        finally:
            phase = 'saving'
            result['audit_wrapper_wall_seconds'] = time.monotonic()-started
            audit.flush()
            rows = [json.loads(line) for line in (ROOT/'SUBPROCESS_INVOCATIONS.jsonl').read_text().splitlines()]
            native_rows = [row for row in rows if any('native_execution_v2' in str(arg) or 'native_pytest_v2' in str(arg)
                                                        for arg in row['argv'])]
            result['native_subprocess_invocations_observed'] = native_rows
            # Zero is warranted only when preparation stopped, and the actual invocation audit contains no native runner.
            if result.get('stopped_on_admission_refusal') and not native_rows:
                result['native_calls'] = 0
                result['native_call_evidence'] = 'Complete current-process subprocess audit plus all unchanged provisioning phase receipts: no native runner invocation; provision does not collect or run tests.'
            write('RESULT.json', result)
            write('TOOL_LOG.json', {'actual_execution': True, 'interpreter': sys.executable, 'source_modified': False,
                                   'actions': actions, 'subprocess_invocations': rows,
                                   'raw_stdout': str(ROOT/'admission.stdout.log'), 'raw_stderr': str(ROOT/'admission.stderr.log'),
                                   'provision_raw_logs': [row.get('log') for row in result.get('setup_costs', []) if row.get('log')],
                                   'prior_preflight': 'Read-only checkout/protocol/network inspection retained in root tool transcript; no native execution during preflight.'})
            write('COSTS.json', {'audit_wrapper_wall_seconds': result['audit_wrapper_wall_seconds'],
                                'first_preparation_wall_seconds': result.get('first_preparation_wall_seconds'),
                                'setup_costs': result.get('setup_costs', []), 'native_calls': result['native_calls'],
                                'candidate_proposals': 0, 'model_tokens': 'UNKNOWN', 'model_dollars': 'UNKNOWN',
                                'engineering_seconds': 'UNKNOWN', 'nested_wall_times_nonadditive': True})
print(json.dumps({key: result.get(key) for key in ('status','admission_status','reason','native_calls','first_preparation_wall_seconds')}, sort_keys=True))
