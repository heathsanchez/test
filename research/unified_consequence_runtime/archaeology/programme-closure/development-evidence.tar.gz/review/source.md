# Independent early programme-closure source review

Reviewer: `/root/integration_review`. Read-only review of sources and tests in
`/workspace/udm-v54`; no original scientific experiment was rerun and no source
implementation was edited by the reviewer. Review base HEAD:
`cd89ed004223763672a485cc34b466995cfd1680`.

This is an **early under-construction review**, not final qualification. Owners
are actively changing the working tree. Root was notified of the consequential
findings before this report. A later follow-up must record corrected hashes,
regression evidence and the actual whole-stack qualifier/archived packet.

## Reviewed source snapshot

Relative to `research/unified_consequence_runtime/`:

| File | SHA-256 at review snapshot |
|---|---|
| native_observation.py | `1b1ae2efb9fe95d863a191f32cd72bc51168719391b6a8cf4634fede6598b7d1` |
| native_constructor.py | `fa43cd3bc7c46ca4b13340177c8459b3361f974ccedf5ea829ac7a9c638d34db` |
| cross_frontier.py | `3c91535b4a6c9f93f8decad4f152549eaebdd8b6b82f09cf65cc6d4302f945fa` |
| developmental_choice.py | `47e356c5742fc7ccfdb4a0c7488faa1c314e531e2793da847ba7f27d7b20ca48` |
| developmental_machine.py | `6b4fd586c3ffe9e8247e6a0ab915e5e34aadd231919c3a47bc5727b60d588420` |

Also read PROGRAMME_CLOSURE_PROTOCOL.md, PROGRAMME_CLOSURE_PLAN.md,
prepare_native_observation.py, relevant new contract tests, the unchanged source
objects for original native observation and constructor algorithms, and the
existing selector hook. Line references below apply to this snapshot.

## Findings requiring closure

### R1 — HIGH: authenticated Python text does not exclude cached bytecode

`native_observation.py:55–68` hashes and writes original source, then executes it
through `SourceFileLoader.exec_module`. `native_constructor.py:76–86` does the
same. Neither loader excludes existing cached bytecode for these source modules.
The original observation producer also dynamically imports its solver. A hash
of the `.py` file alone therefore is not a complete binding to the actually
executed source-module code when a valid cached module already exists. `-B` and
PYTHONDONTWRITEBYTECODE disable writes, not reads. The fresh child observation
pycache prefix at `native_observation.py:194` does not protect the parent producer
or solver loading. Actual generated producer pycache exists in earlier local
qualification output; no malicious cache was planted or executed by this review.

Required closure: execute authenticated raw source bytes, or exclude cached
bytecode for every original-source load (including the nested solver import).
Add a source-loader bookkeeping regression demonstrating bytecode cannot
substitute executed code while the `.py` digest remains unchanged. No scientific
acquisition rerun is needed to exercise this loader contract.

### R2 — HIGH: constructor preparation effects precede authority/path guards

`native_constructor.py:216–221` creates the worlds directory and can invoke
`_call(name, "prepare")` before `_scope` checks live source/authority and canonical
native roots. The original prepare phase creates worktrees and performs native
repository reads. A revoked adapter authority, or a redirected previously
initialized root, can therefore trigger preparation effects before rejection.
The existing withdrawal/root tests exercise `_scope` directly, not `prepare()`.

Required closure: check authority/source liveness, canonical ancestors and
output/source scope before the first mkdir/native prepare call. A missing
world may be intentionally created only after those preconditions. Add red tests
that withdrawn authority and redirected roots produce no preparation call or
out-of-scope mutation.

### R3 — HIGH: constructor native worlds are not fully source authenticated

`native_constructor.py:191–208` checks HEAD and tracked changes but does not
reject untracked or ignored import-affecting files. `_probe_worker` records an
import manifest (`123–146`) but does not compare every imported file to the
pinned Git tree; the retained receipt validation checks the subject entry only
(`413–427`). `_git` (`63–64`) also permits Git replacement objects, unlike the
observation source authenticator. Consequently tracked source checks alone do
not establish that all executed native package bytes match the declared commit.

The observation checker is stronger because it checks tracked blobs, but its
`git ls-files --others --exclude-standard` at `native_observation.py:112` also
excludes ignored untracked files. Its native child controls cache lookup, but the
claim that all executable import files are pinned should remain bounded unless
unexpected ignored imports are excluded too.

Required closure: authenticate native import-relevant bytes against the real Git
objects, use `--no-replace-objects`, and reject unqualified untracked/ignored
Python inputs (or execute from a clean authenticated copy). Add altered-import
and ignored-file controls; preserve native candidate-patch exception only inside
the independently checked temporary patch transaction.

### R4 — MEDIUM: retained frontier validator hash is not checked against current code

`cross_frontier.py:112–115` checks only the format of
validator_source_sha256. Neither reclose_frontiers nor _publication_binding
compares it to the current validator's bytes. `require_frontier_route:262–277`
permits a READY result with validate=None. Thus a persisted route can still be
reported READY after its native adapter code changes, even though that adapter
would reject its own stale receipt if explicitly invoked. This is distinct from
an external reference-monitor claim: it concerns the scientific meaning of
retained executable readiness.

Required closure: invalidate stale source-bound validator readiness on rebuild,
or require the correct current native validator before any READY route can be
returned for activation. Do not rely on a caller remembering an optional check.
Test stale validator code separately from object corruption.

## Confirmed design properties and scientific boundaries

- Sources pin original executable algorithms rather than storing historical
  headlines. The TOML adapter calls original acquire/transfer implementations
  and original independent receiver semantics. The collection adapter performs
  actual source-native observation, synthesis, candidate execution, original
  native tests and physical-removal controls.
- State remains in the existing Machine/Metatron log. The new frontier cache is a
  reconstructible projection of that log into original FLASH, not a new warrant
  database. The Machine hook at developmental_machine.py:166–169 recomputes it.
- Publication binds capability, program, receipt, exact contract/profile and
  causal parents; support agreement is checked between canonical Metatron and
  the additional original FLASH view. Wrong contracts, ambiguous routes and
  absent routes remain explicit UNKNOWNs.
- The original selection adapter skips unrelated typed capability scopes before
  the E/D applicability guard; new capabilities need not break existing E/D
  selection merely by being present.
- Developmental choice authenticates and executes only the original dominates
  and choose definitions, validates the entire declared rectangular profile
  carrier and retains candidates when choice is unresolved. Its digest binding
  explicitly does not claim independent authority or semantic completeness.
- Observation acquisition freezes the A-only program, then independently tests
  B/C applicability before admission. Those exposed scopes do not establish
  prospective unfamiliar-source generalization. The channels and operation
  grammar remain supplied.
- Constructor discovery intentionally reads changed source lines between base
  and author head, then instantiates two human-authored grammars. This is
  source-derived historical repair reuse, not blind defect discovery, new
  observation-language invention or autonomous constructor-grammar acquisition.
- The reviewed collection constructor profiles have already been made
  target-specific, preventing cachetools receipt readiness from directly
  resolving boltons profiles merely because their generic role names match.
- Existing APIs are ordinary Python. Public append and caller callbacks are not
  hostile-code security boundaries. Non-bypassable external action enforcement
  remains UNKNOWN as the protocol correctly states.

## Whole-stack qualifier conditions still to review

Root described the proposed causal path as: native A observations and primitive
collisions -> original minimal-basis constructor -> actual frozen A program ->
independent B/C applicability -> publication to both preexisting active frontiers
-> original Pareto choice from complete native profiles -> selected native future
execution -> selective withdrawal/restoration -> separate-process restart.

This can warrant bounded changed observation/selection if the qualifier actually
uses the returned choice to gate execution and retains primitive ambiguous
alternatives. It must not treat a deliberately restricted active channel as
complete old-language inadequacy. Collection repair construction is a separate
native path unless a real independently verified dependency joins it. Retained
V54 replay may preserve its already qualified O1-to-O2 result without rerunning
its original search, but cannot by itself prove a new constructor/observation
causes new operation discoverability in this continuation.

Final source, end-to-end execution, cost equivalence, archive contents, external
workflow and full source-coverage claims are not qualified by this early review.

## Follow-up: original-loader and constructor guard repairs inspected

The observation owner reproduced both producer and solver cached-bytecode
substitution as red tests, then supplied direct compilation/private solver-cache
fixes. Independently inspected `/workspace/qualification/native-observation-scope/pyc-before.txt`
(two errors from the substituted cached modules) and `pyc-after.txt` (17 tests OK).
The producer and nested solver loader fixes address R1 for observation within the
declared sequential process model. An additional ignored-import red test and
stronger world check are now being added; final source/hash confirmation pending.

The constructor owner supplied three red tests and then 12 passing contracts.
Independently inspected `/workspace/native-constructor-review-red.log` and
`/workspace/native-constructor-review-green.log`. Direct authenticated source
compilation, pre-prepare authority/root checks, rejection of untracked/ignored
import files and imported-project-file hash comparison address its loader,
preparation and import gaps. The reviewer separately requested disabling Git
replacement objects throughout constructor Git calls; owner reports that change
and a real local Git replacement regression now passes, pending final inspection.

## Qualifier draft review

Draft qualify_programme_closure.py SHA-256: `be0a03dec13ce4530bee4cee0712914c103ad2f317e4094fd70dbfbcbdf1413d`.
Read all 316 lines. The draft invokes the original choice function on complete
native profiles, retains both primitive candidates, and gates actual selected-head
native execution on the selector's returned ID. It separately qualifies collection
construction rather than fabricating a TOML-to-collection causal dependency.

Two remaining scope/chronology points were sent to root:

- **R5 — MEDIUM:** `_choice:35–86` constructs the primitive UNKNOWN_CHOICE
  result after acquisition and native B/C execution (`188–207`). This is a valid
  counterfactual observation ablation but not yet a live persisted obstruction
  that caused acquisition. If the report claims the entire constitutional
  transition, record an actual initial unresolved native choice/residual before
  acquisition and preserve its evidence/dependency lineage.
- **R6 — MEDIUM/report scope:** `_baseline:89–108` compares actual classifier
  outcomes with the same supplied policy/source/verification access. It does not
  execute original developmental choice or fresh construction. The baseline
  verdict must stay within that measured scope unless those shared decisions are
  also executed and compared. Record actual resource access and measured phases;
  no inferred comparative advantage is licensed.

The draft restart executes new observation/choice and collection patches. It does
not itself replay E/D/V54; root was reminded to retain native E/D/V54 replay in the
same workflow and separately preserve the prior acquisition/search qualification.

## Independent guard regression result and current technical resolutions

The reviewer independently ran only admission/bookkeeping tests, not original
scientific acquisition experiments:

```
/workspace/udm-venv/bin/python -m unittest \
  research.unified_consequence_runtime.test_native_constructor \
  research.unified_consequence_runtime.test_native_observation.NativeObservationContracts \
  research.unified_consequence_runtime.test_cross_frontier \
  research.unified_consequence_runtime.test_developmental_choice -v
```

Result: **51 tests PASS in 2.345 seconds**. Exact output:
`/workspace/qualification/programme-review-contracts.log`.

Subsequent source inspection confirms:

| Finding | Technical resolution at this review stage |
|---|---|
| R1 cached original-source bytecode | CLOSED: both adapters compile authenticated source directly; observation nested original solver executes with fresh private bytecode prefix. |
| R2 pre-prepare liveness/path guard | CLOSED: constructor prepare checks live authority/source and canonical roots before mkdir or original prepare invocation. |
| R3 native import/source authenticity | CLOSED within declared local sequential scope: constructor rejects untracked/ignored import-affecting files and checks imported project files; `_git` disables replacement objects and subprocess environment disables them inside unchanged original code. Observation rejects all untracked files regardless ignore rules. |
| R4 stale retained frontier validator | CLOSED: explicit typed validator source mapping; retained publication compares actual current validator bytes; independent stale-code contract passes. |
| R5 live obstruction chronology | OPEN in the initially reviewed qualifier; root notified. |
| R6 baseline comparison scope | OPEN/report-scope in the initially reviewed qualifier; root notified. |

The stale validator fix fails closed if any historical validator publication no
longer matches source bytes, including revoked history. It currently prevents
loading that incompatible retained log rather than selectively migrating it.
General adapter-upgrade portability is therefore not established by the fix.

Current reviewed implementation hashes after these guard fixes:

| File | SHA-256 |
|---|---|
| native_observation.py | `f5293ec8b2baf6b46b5e8f45f3e359eb2e59c32e0d133e82b7250a6d20f7062d` |
| native_constructor.py | `8c02fbe8b34f70c66c0d0327da694069d950a3f224d411f74d1e79051b7c41fb` |
| cross_frontier.py | `bb5a87018045096a56751be63f0cccc6852f180248471eb2bb0e0b967fe31d64` |
| developmental_choice.py | `47e356c5742fc7ccfdb4a0c7488faa1c314e531e2793da847ba7f27d7b20ca48` |
| developmental_machine.py | `6b4fd586c3ffe9e8247e6a0ab915e5e34aadd231919c3a47bc5727b60d588420` |

Source may continue changing; final qualification must pin and archive its own exact source.

## Final qualifier and workflow source review

Read the actual final qualifier (403 lines) and workflow (318 lines), not just an
owner description. Source hashes at this review point:

| Source | SHA-256 |
|---|---|
| research/unified_consequence_runtime/qualify_programme_closure.py | `4d69f0ef7007731f100e5f9f057f399eb3dfb39bcbcbb3ee40eb5cd5d2dc36fd` |
| .github/workflows/universal-developmental-runtime.yml | `7556a9eae6beaea557b4afddd80c40e1ccce4061c674d1bb5c9385e4ea041ecd` |

- **R5 CLOSED:** qualifier lines 35–76 execute actual source-A native observations,
  construct an original MSI PairResidual from a primitive collision with
  independently checked unequal consequences, route original FLASH
  UNKNOWN_IDENTITY to SPLIT, retain both original-choice candidates, and persist
  the event before acquisition at lines 247–249. The later combined observation
  is checked as a strict refinement on the unchanged 80-case carrier (253–262).
  This establishes runtime finite relation checks, not a new concrete Lean proof.
- **R6 CLOSED WITH EXPLICIT SCOPE:** baseline lines 133–164 execute fresh native
  observations/verification and the original choice selector. Lines 306–318 also
  invoke the same original supplied constructor and independently verify its
  actual identical source output. Shared acquisition knowledge is explicitly
  declared. This measures an informed execution/selection/construction tie; it
  does not establish lower whole-lifecycle cost or a live-agent comparison.
- Acquiring again must return the same active independently warranted capability
  in both new adapters (qualifier 250 and 298–299); unresolved alternatives retain
  UNKNOWN. Collection construction remains an independently qualified path in
  the same authority rather than an invented dependency on TOML observations.
- Workflow 88–138 authenticates the original E/D archive, exact 101-record ledger,
  objects and native qualification. Workflow 161–203 authenticates original V54
  evidence and replays persisted O1/O2 behavior without acquisition or discovery
  search. Exact native worlds and original source components remain pinned.
- Workflow 242–249 recompiles the frozen bounded V54 Lean packet. It does not
  assert that the Python adapters or new runtime transitions have been formally
  refined to Lean. External enforcement, prospective unfamiliar-source growth,
  strict comparative advantage and Python refinement remain separate verdicts.
- Workflow 285–305 binds the new result/restart and retained evidence to actual
  GITHUB_SHA/RUN_ID. Artifact upload runs even on failure and includes original
  archives, qualification evidence, workflow and source.

**R7 — MEDIUM, discovered during final review:** workflow lines 224–226 use
`unittest discover -s research/unified_consequence_runtime` without a project
top-level argument, while the two new native test modules use relative imports.
These modules are then discovered as top-level modules and cannot import their
package context. The concurrent local all-contracts log already contains two
module errors. Root was notified to add the correct discovery top-level or use
absolute test imports, preserve the failed log and rerun the contract gate. This
is a test runner issue, not evidence against the completed native stages.

Native local packet `/workspace/qualification/programme-native-reviewed/RESULT.json`
is currently RUNNING; eight stages PASS, separate-process restart pending. No
native result is promoted here until the final packet has been independently
inspected. The reviewer has not rerun scientific native acquisition.

Reviewer receipt correction: the first packet-review human-readable gate label incorrectly said B8/C2. Actual independently audited counts and assertions were B8/C4. The receipt now explicitly records B 8 repaired/detected and C 4 repaired/detected, both zero false warrants. Scientific packet/source unchanged.

## Completed native packet inspection

Independent read-only review receipt:
`/workspace/qualification/programme-review-packet.json`.

All nine native stages and separate-process restart PASS. Independently checked
all 214 node IDs and prerequisite order, all 62 content-addressed objects, exact
original 101-record prefix, ledger digest, old/new generation liveness and the
negative/unrelated frontier snapshots. Executed only original independent
receiver semantics against retained observation tables, not native acquisition.
The observed source-A minimum is exactly the coherence channel. B has 8/8 and C
4/4 repaired witnesses detected, with zero false warrants. Both original choices
select author head after primitive UNKNOWN_CHOICE; the informed baseline ties.
Actual collection candidates pass original 89-test cachetools and 9-test boltons
suites; original source and physically removed candidates fail their protected
observers. Cold restart repeats the native outcomes and selected future choices.

| Evidence | SHA-256 |
|---|---|
| RESULT.json | `479fd936785897720c7efe8f6c4a165072992aea8a4d6acc79a4ec14e3f8092f` |
| cold-restart.json | `5c3f7a1d65b0ee70e442132fdf4790db9346aea6c0614bb9ffccb15d8c1463eb` |
| final ledger | `5037f63a7ed17521b574e5767e752de73e06c9a04acaf38271fda7de31c72f56` |

The small Machine.select_and_execute_frontier method, added after the local
main process imported source, was separately source-reviewed. It accepts no
caller capability ID, uses the current unique FLASH route and native validator,
checks request family/subject against typed verified scope, executes the selected
existing capability and returns UNKNOWN without construction fallback. The five
API guard tests in programme-native-frontier-activation.log PASS; final exact-source
Actions must qualify this latest helper invocation.

R7 source fix inspected: both previously failing test modules now use absolute
package imports under the actual discovery mode. The failed 121-test log remains
preserved; completed full-suite rerun evidence is still required before claiming
that entire contract gate passed.

One additional metadata correction was requested: reused V54 Journal populated
top-level claim_boundary with token-emission constructor / one-new-rewrite
language. Those are retained V54 boundaries, not the new observation/collection
experiment. Root agreed to replace the programme-level metadata with its actual
supplied grammars; the successful local packet remains unchanged.

## Remaining whole-programme claim boundaries

No source-level blocker remains for the bounded native observation/choice/repair
integration reviewed here, provided the final workflow passes on exact committed
source and preserves failed evidence. The broader mission must retain UNKNOWN
for the following independent obligations:

- Exhaustive full-programme recovery outside the frozen actually inspected
  accessible source universe.
- Newly invented primitive observation vocabulary or constructor grammar.
- A new observation/constructor causally enabling discovery of a later new
  executable operation in this continuation. It demonstrates changed protected
  distinction/selection; retained V54 remains the separate qualified bounded
  O1-to-O2 discoverability result.
- Fully autonomous cross-domain constructor or developmental-policy discovery.
- Prospective unfamiliar-source development on the still-frozen urllib3 frontier.
- General executable behavioural equivalence and IKKF neural/cross-model transport.
- Python-to-Lean runtime refinement or universal native correctness.
- Non-bypassable all-effects external enforcement, concurrency safety and arbitrary
  adapter upgrades across stale historical receipt hashes.

Measured informed ledger comparisons tie. No strict advantage or live-agent
comparison follows. Global closure evidence concerns finite typed route readiness;
each actual native consequence remains independently verified in its own domain.
